// ── CLOUDINARY UPLOAD ──
       // ══════════════════════════════════════════
        // CLOUDINARY UPLOAD (CRASH & FETCH ERROR SAFE)
        // ══════════════════════════════════════════
        async function uploadToCloudinary(file) {
            if (!file) throw new Error('No image file selected');
            if (!CLOUDINARY_CLOUD || CLOUDINARY_CLOUD === 'YOUR_CLOUD_NAME') {
                throw new Error('Cloudinary credentials not configured properly');
            }

            const fd = new FormData();
            fd.append('file', file);
            fd.append('upload_preset', CLOUDINARY_PRESET);

            try {
                const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/image/upload`, {
                    method: 'POST',
                    body: fd
                });
                
                if (!res.ok) {
                    const errorData = await res.json().catch(() => ({}));
                    throw new Error(errorData.error?.message || `Cloudinary upload failed with status ${res.status}`);
                }
                
                const data = await res.json();
                return data.secure_url;
            } catch (networkErr) {
                console.error('[Cloudinary Network Error]:', networkErr);
                throw new Error('Image upload failed: Please check internet connection or image size.');
            }
        }



