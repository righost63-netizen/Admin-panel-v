// Reserved for shared Firestore query/CRUD helpers.
// The original source calls collection()/doc()/getDocs()/onSnapshot() etc.
// directly inside each scripts/screens/*.js file (via the globals exposed by
// firebase-init.js). Nothing was centralized here in the source, so this
// file is currently empty — a place to extract common query patterns into
// later if you want (e.g. a generic paginated-list helper).
