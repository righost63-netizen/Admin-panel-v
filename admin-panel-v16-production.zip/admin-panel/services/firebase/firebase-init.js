// Firebase app / auth / Firestore bootstrap.
// This is the ONLY module (type="module") script in the project — it needs
// native ES `import` to load the Firebase SDK from the CDN. Every other
// script in this project is a plain classic script, so this file exposes
// everything it sets up on `window`, letting the rest of the app keep using
// bare names like `db`, `collection(...)`, `onSnapshot(...)` etc. exactly
// like the original single-file version did.
//
// ✅ FIX (2026-10-03): multi-tab persistence.
// আগে persistentLocalCache() single-tab exclusive মোডে চলতো — একই origin-এ
// (যেমন localhost:3000) অ্যাডমিন প্যানেল দুটো ট্যাবে খুললেই দ্বিতীয় ট্যাব
// "Failed to obtain exclusive access to the persistence layer" এরর দিতো।
// এখন persistentMultipleTabManager() ব্যবহার করা হচ্ছে, তাই যত ট্যাব খুশি
// খোলো — সবাই IndexedDB ক্যাশ শেয়ার করে চলবে।

import { firebaseConfig } from '../../config/firebase-config.js';

import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
    getAuth,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
    initializeFirestore,
    persistentLocalCache,
    persistentMultipleTabManager,
    collection,
    doc,
    getDoc,
    getDocs,
    addDoc,
    setDoc,
    updateDoc,
    deleteDoc,
    onSnapshot,
    query,
    where,
    orderBy,
    limit,
    increment,
    serverTimestamp,
    Timestamp,
    writeBatch,
    runTransaction,
    startAfter,
    arrayUnion,
    arrayRemove,
    getCountFromServer,
    getAggregateFromServer,
    sum
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
    getFunctions,
    httpsCallable
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-functions.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = initializeFirestore(app, {
    localCache: persistentLocalCache({
        tabManager: persistentMultipleTabManager()
    })
});

window.app = app;
window.auth = auth;
window.db = db;

window.signInWithEmailAndPassword = signInWithEmailAndPassword;
window.signOut = signOut;
window.onAuthStateChanged = onAuthStateChanged;
window.sendPasswordResetEmail = sendPasswordResetEmail;

window.collection = collection;
window.doc = doc;
window.getDoc = getDoc;
window.getDocs = getDocs;
window.addDoc = addDoc;
window.setDoc = setDoc;
window.updateDoc = updateDoc;
window.deleteDoc = deleteDoc;
window.onSnapshot = onSnapshot;
window.query = query;
window.where = where;
window.orderBy = orderBy;
window.limit = limit;
window.increment = increment;
window.serverTimestamp = serverTimestamp;
window.Timestamp = Timestamp;
window.writeBatch = writeBatch;
window.runTransaction = runTransaction;
window.startAfter = startAfter;
window.arrayUnion = arrayUnion;
window.arrayRemove = arrayRemove;
window.getCountFromServer = getCountFromServer;
window.getAggregateFromServer = getAggregateFromServer;
window.sum = sum;

window.getFunctions = getFunctions;
window.httpsCallable = httpsCallable;
