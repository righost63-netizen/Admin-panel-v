// Thin wrapper around the Firebase Auth functions exposed by
// services/firebase/firebase-init.js (signInWithEmailAndPassword, signOut,
// onAuthStateChanged). The original source called these directly inside
// scripts/core/auth.js and scripts/core/navigation.js — kept that way here
// too, so this file is currently just a reserved spot if you want to
// centralize auth calls later. No behaviour lives here yet.
