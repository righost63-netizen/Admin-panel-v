// ── STEP 6 FIX: ONESIGNAL PUSH ──
        // ══════════════════════════════════════════════════════════════
        // ✅ STEP 6 FIX: HARDENED ONESIGNAL PUSH NOTIFICATION SENDER
        // Handles sanitized userIds, prevents 400 Bad Request & gracefully fails
        // ══════════════════════════════════════════════════════════════
        // FIX (BUILD 16): this function NEVER throws (main flows must not break),
        // but it now RETURNS an honest result object so callers stop showing a
        // fake "sent!" toast when the push actually failed / was skipped:
        //   { ok:true, id } | { ok:false, skipped:'app_id'|'rest_key'|'no_targets' } | { ok:false, error }
        const NOTIF_EMOJI = {
            info: 'ℹ️',
            success: '✅',
            warning: '⚠️',
            prize: '🏆'
        };

        async function sendOneSignalPush(title, message, type = 'info', userIds = null) {
            if (!ONESIGNAL_APP_ID || ONESIGNAL_APP_ID === 'YOUR_ONESIGNAL_APP_ID') {
                console.warn('[OneSignal] App ID not configured.');
                return { ok: false, skipped: 'app_id' };
            }

            // 🛡️ যদি মেমরিতে কি না থাকে, সিকিউর ডাটাবেজ থেকে লোড করা
            if (!ONESIGNAL_REST_API_KEY) {
                try {
                    const snap = await getDoc(doc(db, 'settings', 'notifications'));
                    if (snap.exists() && snap.data().restApiKey) {
                        ONESIGNAL_REST_API_KEY = snap.data().restApiKey;
                    }
                } catch (e) {}
            }

            if (!ONESIGNAL_REST_API_KEY) {
                console.warn('[OneSignal] REST API Key is missing in Settings. Skipping push.');
                return { ok: false, skipped: 'rest_key' };
            }

            const finalTitle = `${NOTIF_EMOJI[type] || 'ℹ️'} ${title}`;
            const payload = {
                app_id: ONESIGNAL_APP_ID,
                headings: {
                    en: finalTitle
                },
                contents: {
                    en: message
                }
            };

            // নির্দিষ্ট ইউজারদের টার্গেট করার সময় খালি বা নাল আইডি স্বয়ংক্রিয়ভাবে ফিল্টার করা
            if (Array.isArray(userIds)) {
                const sanitizedIds = userIds.filter(id => id && typeof id === 'string' && id.trim().length > 0);
                if (sanitizedIds.length === 0) {
                    console.log('[OneSignal] No valid subscriber IDs to target, skipping push.');
                    return { ok: false, skipped: 'no_targets' };
                }
                payload.include_aliases = {
                    external_id: sanitizedIds
                };
                payload.target_channel = 'push';
            } else {
                // সব প্লেয়ারের কাছে ব্রডকাস্ট পাঠানো
                payload.included_segments = ['Total Subscriptions'];
            }

            try {
                const res = await fetch('https://api.onesignal.com/notifications', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json; charset=utf-8',
                        'Authorization': `Key ${ONESIGNAL_REST_API_KEY}`
                    },
                    body: JSON.stringify(payload)
                });

                const data = await res.json().catch(() => ({}));
                if (!res.ok || data.errors) {
                    const errMsg = (data && data.errors && data.errors.join('; ')) || ('HTTP ' + res.status);
                    console.warn('[OneSignal Warning] Push failed:', data);
                    return { ok: false, error: errMsg };
                }
                return { ok: true, id: data.id || null };
            } catch (err) {
                console.warn('[OneSignal Network Error]:', err.message);
                // পুশ ফেইল করলেও অ্যাপের ভেতরের মূল কাজ (যেমন রেজাল্ট সেভ বা পেমেন্ট অ্যাপ্রুভ) কখনো আটকাবে না
                return { ok: false, error: err.message || 'network_error' };
            }
        }
        window.sendOneSignalPush = sendOneSignalPush;

        // ── FIX (BUILD 16): honest push-result toast ──
        // Main action (room publish, reminder save…) already succeeded — this only
        // reports the push leg truthfully instead of a fake "sent!".
        window.pushToast = function(res, okMsg) {
            if (!res) return;
            if (res.ok) { showToast(okMsg || 'Push sent! 📲', 'success'); return; }
            if (res.skipped === 'app_id' || res.skipped === 'rest_key') {
                showToast('Saved ✅ — push NOT sent: OneSignal ' + (res.skipped === 'app_id' ? 'App ID' : 'REST API key') + ' missing in Settings ⚠️', 'warning');
            } else if (res.skipped === 'no_targets') {
                showToast('Saved ✅ — no push targets', 'warning');
            } else {
                showToast('Saved ✅ — but push FAILED: ' + (res.error || 'unknown error') + ' ⚠️', 'error');
            }
        };



