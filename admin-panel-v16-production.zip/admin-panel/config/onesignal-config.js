// OneSignal push notification configuration.
//
// SECURITY FIX: REST API key আর এখানে hardcode করা নেই। আগে plain text-এ
// ছিল — page source দেখলেই যে কেউ সব user-কে push পাঠাতে পারত।
// Key এখন Firestore-এ নিরাপদে থাকে:
//   → Admin Panel → OneSignal Settings থেকে key সেভ করো
//     (settings/notifications ডকুমেন্টের restApiKey ফিল্ডে যাবে),
//   → push-service.js সেখান থেকে লোড করে নেবে।
// ⚠️ push কাজ করবে না যতক্ষণ না key টা সেখানে বসাচ্ছো।
// ⚠️ আগের key টা যেহেতু কোডে public ছিল, OneSignal Dashboard থেকে
//    নতুন REST API key generate করে সেটাই বসাও (পুরনোটা revoke করে দাও)।
window.ONESIGNAL_APP_ID = "c829b190-a98f-4bb0-ade7-86a4939c4625";
window.ONESIGNAL_REST_API_KEY = "";
