// Cloudinary upload configuration.
window.CLOUDINARY_CLOUD = "dzgjcsysj";
window.CLOUDINARY_PRESET = "profile_anik";
