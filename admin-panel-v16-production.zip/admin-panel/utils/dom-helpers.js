        function esc(str) {
            return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        }

        // Firestore Timestamp / Date / string / number — যেকোনো ফরম্যাট থেকে সঠিক JS Date বানানো (Invalid Date বাগ ফিক্স)
        function tsToDate(val) {
            if (!val) return null;
            if (typeof val.toDate === 'function') return val.toDate();
            if (val instanceof Date) return isNaN(val) ? null : val;
            if (typeof val === 'object' && typeof val.seconds === 'number') return new Date(val.seconds * 1000);
            if (typeof val === 'string' || typeof val === 'number') {
                const d = new Date(val);
                return isNaN(d) ? null : d;
            }
            return null;
        }

        // "14:30" (24h) -> "2:30 PM". Already-formatted/invalid input is returned as-is.
        function formatTimeTo12h(t) {
            const m = /^(\d{1,2}):(\d{2})/.exec(String(t || '').trim());
            if (!m) return String(t || '');
            let h = parseInt(m[1], 10);
            const ap = h >= 12 ? 'PM' : 'AM';
            h = h % 12 || 12;
            return h + ':' + m[2] + ' ' + ap;
        }
        window.formatTimeTo12h = formatTimeTo12h;

        function formatTime(d) {
            const now = new Date();
            const diff = Math.floor((now - d) / 1000);
            if (diff < 60) return 'Just now';
            if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
            if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
            return d.toLocaleDateString('en-IN', {
                day: '2-digit',
                month: 'short'
            });
        }

        function formatDate(d) {
            return d.toLocaleDateString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }




