// Network online/offline status banner.
        // নেটওয়ার্ক স্টেট মনিটরিং ফাংশন
        function initNetworkMonitoring() {
            const banner = document.createElement('div');
            banner.id = 'networkStatusBanner';
            document.body.appendChild(banner);

            function updateStatus() {
                if (navigator.onLine) {
                    if (banner.classList.contains('net-offline')) {
                        banner.className = 'net-online visible';
                        banner.innerHTML = '🟢 Back Online';
                        setTimeout(() => {
                            banner.classList.remove('visible');
                        }, 3000);
                    }
                } else {
                    banner.className = 'net-offline visible';
                    banner.innerHTML = '🔴 You\'re offline';
                }
            }

            window.addEventListener('online', updateStatus);
            window.addEventListener('offline', updateStatus);

            // অ্যাপ লোড হওয়ার সময় অফলাইন থাকলে চেক করবে
            if (!navigator.onLine) {
                updateStatus();
            }
        }

        // নেটওয়ার্ক মনিটর চালু করা
        initNetworkMonitoring();

