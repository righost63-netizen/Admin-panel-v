// Universal lastUpdated cache-bust system.
// appConfig/lastUpdated holds one timestamp field per data type; the user
// panel reads this single small doc to know if its localStorage cache is
// stale, instead of re-downloading full collections.
async function touchCache(type) {
    try {
        await setDoc(doc(db, 'appConfig', 'lastUpdated'), {
            [type]: serverTimestamp()
        }, { merge: true });
    } catch (e) {
        console.error('touchCache(' + type + ') failed:', e);
    }
}
window.touchCache = touchCache;
