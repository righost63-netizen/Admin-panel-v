// ══════════════════════════════════════════
// APP BOOTSTRAP — সবার শেষে লোড হয় (Index.html এর scriptFiles তালিকার শেষ ফাইল)
// লগইন সফল হলে navigation.js এর showApp() এই ফাংশনটা ডাকে।
// ══════════════════════════════════════════
function loadAllScreens() {
    // FIX: fresh login-এ doLogin→showApp() আর onAuthStateChanged→showApp() দুবার
    // চলত, ফলে Dashboard-এর onSnapshot ডাবল হতো। এই গার্ড দ্বিতীয়বার আটকায়।
    if (loadedScreens.dashboard) return;
    // শুধু প্রথম-visible screen (dashboard) লোড হবে।
    // বাকি সব screen তাদের নিজ নিজ tab-এ প্রথমবার গেলে switchTab() থেকে লোড হবে (দেখুন navigation.js)
    loadDashboard();
    loadedScreens.dashboard = true;
}
