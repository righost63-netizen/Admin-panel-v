        window.showActionSheet = function(title, subtitle, actions) {
            document.getElementById('asTitle').textContent = title;
            document.getElementById('asSubtitle').textContent = subtitle;
            document.getElementById('asActions').innerHTML = actions.map(a =>
                `<button class="action-btn ${a.style==='destructive'?'action-btn-destructive':''}" onclick="handleActionBtn(${actions.indexOf(a)})">${a.label}</button>`
            ).join('');
            window._actionCallbacks = actions.map(a => a.action);
            document.getElementById('actionSheet').classList.add('visible');
        };

        window.handleActionBtn = function(idx) {
            closeActionSheet();
            setTimeout(() => window._actionCallbacks[idx]?.(), 100);
        };

        window.closeActionSheet = function() {
            document.getElementById('actionSheet').classList.remove('visible');
        };

        window.toggleField = function(id, btn) {
            const inp = document.getElementById(id);
            if (inp.type === 'password') {
                inp.type = 'text';
                btn.textContent = '🙈';
            } else {
                inp.type = 'password';
                btn.textContent = '👁';
            }
        };



