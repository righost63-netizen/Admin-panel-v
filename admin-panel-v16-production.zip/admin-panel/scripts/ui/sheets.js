        // ── Overlay manager ──
        // একবারে শুধু একটা overlay layer খোলা থাকবে — নতুন শিট/মডাল খুললে আগেরটা
        // বন্ধ হয়ে যাবে। স্ক্রিন বদলালেও সব বন্ধ হয় (navigation.js থেকে কল হয়),
        // যাতে ভুল স্ক্রিনের উপর শিট ভেসে না থাকে বা dashboard shift হয়ে আটকে না থাকে.
        //
        // _overlayGen: show অ্যানিমেশন double-rAF দিয়ে হয় — দুই ফ্রেমের মধ্যে অন্য
        // overlay খুললে পুরনো pending অ্যানিমেশন বাতিল হয়ে যায়, ফলে আধা-খোলা/
        // ডাবল layer হওয়ার race window থাকে না।
        window._overlayGen = window._overlayGen || 0;

        window.closeAllOverlays = function() {
            window._overlayGen++;
            document.querySelectorAll('.bottom-sheet.visible').forEach(s => s.classList.remove('visible'));
            document.querySelectorAll('.sheet-overlay.visible, .sheet-backdrop.visible').forEach(o => o.classList.remove('visible'));
            if (window.closeActionSheet) window.closeActionSheet();
            document.querySelectorAll('.full-modal.visible').forEach(m => {
                m.classList.remove('visible');
                m.style.display = 'none';
            });
            const root = document.querySelector('.app-root');
            if (root) root.classList.remove('modal-pushed');
            // transient iOS pickers (self-cleaning, but may survive a screen switch)
            document.getElementById('iosPickerContainer')?.remove();
            document.getElementById('iosTimePickerContainer')?.remove();
        };

        function showSheet(sheetId, overlayId) {
            // নতুন শিট খোলার আগে: অন্য সব শিট/ওভারলে + ফুল মডাল বন্ধ (একটাই layer থাকবে),
            // তারপর শুধু চাওয়া জোড়াটা দেখাও।
            const gen = ++window._overlayGen;
            document.querySelectorAll('.bottom-sheet.visible').forEach(s => s.classList.remove('visible'));
            document.querySelectorAll('.sheet-overlay.visible, .sheet-backdrop.visible').forEach(o => o.classList.remove('visible'));
            document.querySelectorAll('.full-modal.visible').forEach(m => {
                m.classList.remove('visible');
                m.style.display = 'none';
            });
            const root = document.querySelector('.app-root');
            if (root) root.classList.remove('modal-pushed');

            const overlay = overlayId && document.getElementById(overlayId);
            if (overlay) overlay.classList.add('visible');
            const sheet = document.getElementById(sheetId);
            if (!sheet) return;
            requestAnimationFrame(() => requestAnimationFrame(() => {
                if (gen !== window._overlayGen) return; // এর মধ্যে নতুন overlay খুলেছে — এটা আর দেখিও না
                sheet.classList.add('visible');
            }));
        }

        function hideSheet(sheetId, overlayId) {
            const sheet = document.getElementById(sheetId);
            if (sheet) sheet.classList.remove('visible');
            const overlay = overlayId && document.getElementById(overlayId);
            if (overlay) overlay.classList.remove('visible');
        }

        // ══════════════════════════════════════════
        // Sheet accessibility: ESC to close + initial focus + simple focus trap
        // ══════════════════════════════════════════
        // Call after showSheet(sheetId, overlayId). Safe to call multiple times.
        window.sheetA11y = function(sheetId, overlayId, focusId) {
            const sheet = document.getElementById(sheetId);
            if (!sheet) return;
            if (sheet.dataset.a11yBound === '1') {
                if (focusId) setTimeout(() => document.getElementById(focusId)?.focus(), 350);
                return;
            }
            sheet.dataset.a11yBound = '1';
            sheet.setAttribute('role', 'dialog');
            sheet.setAttribute('aria-modal', 'true');
            sheet.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    const ov = overlayId && document.getElementById(overlayId);
                    if (ov && typeof ov.onclick === 'function') ov.onclick();
                    else sheet.classList.remove('visible');
                    if (ov) ov.classList.remove('visible');
                }
                if (e.key === 'Tab') {
                    const f = sheet.querySelectorAll('button, input, textarea, select, [tabindex]');
                    const vis = Array.from(f).filter(el => !el.disabled && el.offsetParent !== null);
                    if (!vis.length) return;
                    const first = vis[0], last = vis[vis.length - 1];
                    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
                }
            });
            if (focusId) setTimeout(() => document.getElementById(focusId)?.focus(), 350);
        };
