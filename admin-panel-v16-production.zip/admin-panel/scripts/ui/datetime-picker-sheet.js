        // ════════════════════════════════════════════════════════════════════
        // DateTimePickerSheet — reusable iOS-style Date & Time bottom-sheet picker.
        // Plain JS/CSS, no libraries. Always Asia/Kolkata (IST).
        //
        //   DateTimePickerSheet.open({
        //     date: 'YYYY-MM-DD' | '',   // existing value (edit mode) or '' = IST today
        //     time: 'HH:MM'       | '',  // 24h existing value or '' = IST now
        //     tab:  'date' | 'time',     // which segment opens first
        //     onSet: ({ date, time }) => {} // 'YYYY-MM-DD' + 'HH:MM' (24h) — same format as before
        //   });
        //   DateTimePickerSheet.close();
        // ════════════════════════════════════════════════════════════════════
        (function () {
            'use strict';

            var ITEM_H = 40;              // user spec: 40px highlight band
            var VISIBLE = 5;
            var WHEEL_H = ITEM_H * VISIBLE;
            var PAD = (WHEEL_H - ITEM_H) / 2;
            var Z = 1300;                 // above tournament modal (850)

            var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var DAYS_FULL = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

            var overlay = null;
            var ui = {};
            var wheels = {};            // name -> scroller element
            var onSetCb = null;
            var rafPending = false;
            var settleTimer = 0;
            var lastMonthKey = '';
            var reducedMotion = false;
            // FIX (2026-10-07): authoritative selection state.
            // Wheel scroll positions are NOT trusted across tab switches / re-opens —
            // a hidden pane (display:none) may not retain scrollTo, so reading the
            // wheels could silently return index 0 (Jan 1 / 1:00 AM) and clobber the
            // previously-set date or time on the next "Set". `sel` is the single
            // source of truth; wheels are synced FROM it whenever a pane shows.
            var sel = { y: 0, m: 1, d: 1, h24: 0, min: 0 };
            var activeTab = 'date';
            var yearList = [];

            // ── IST helpers ──────────────────────────────────────────────
            function istParts(d) {
                var p = {};
                try {
                    new Intl.DateTimeFormat('en-CA', {
                        timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit',
                        day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false
                    }).formatToParts(d || new Date()).forEach(function (x) { p[x.type] = x.value; });
                } catch (e) {
                    var n = d || new Date();
                    return { y: n.getFullYear(), m: n.getMonth() + 1, d: n.getDate(),
                             h: n.getHours(), min: n.getMinutes() };
                }
                return { y: +p.year, m: +p.month, d: +p.day,
                         h: p.hour === '24' ? 0 : +p.hour, min: +p.minute };
            }
            function istToUtcMs(y, m, d, h, min) {
                return Date.UTC(y, m - 1, d, h, min, 0) - 5.5 * 3600 * 1000;
            }
            function daysInMonth(y, m) { return new Date(y, m, 0).getDate(); }
            function pad2(n) { return String(n).padStart(2, '0'); }

            // ── DOM build (once) ─────────────────────────────────────────
            function build() {
                if (overlay) return;

                overlay = document.createElement('div');
                overlay.className = 'dtp-overlay';
                overlay.style.zIndex = Z;
                overlay.innerHTML =
                    '<div class="dtp-sheet" role="dialog" aria-modal="true" aria-label="Set date and time">' +
                        '<div class="sheet-handle"></div>' +
                        '<div class="dtp-head">' +
                            '<div class="dtp-title">Schedule</div>' +
                            '<button type="button" class="dtp-cancel" data-act="cancel">Cancel</button>' +
                        '</div>' +
                        '<div class="dtp-chips">' +
                            '<button type="button" class="dtp-chip" data-q="today">Today</button>' +
                            '<button type="button" class="dtp-chip" data-q="tomorrow">Tomorrow</button>' +
                            '<button type="button" class="dtp-chip" data-q="nextweek">Next week</button>' +
                        '</div>' +
                        '<div class="dtp-seg" role="tablist">' +
                            '<button type="button" class="dtp-segbtn active" data-tab="date" role="tab">Date</button>' +
                            '<button type="button" class="dtp-segbtn" data-tab="time" role="tab">Time</button>' +
                        '</div>' +
                        '<div class="dtp-wheels-wrap">' +
                            '<div class="dtp-wheels" data-pane="date"></div>' +
                            '<div class="dtp-wheels hidden" data-pane="time"></div>' +
                            '<div class="dtp-highlight" aria-hidden="true"></div>' +
                        '</div>' +
                        '<div class="dtp-warn" hidden></div>' +
                        '<div class="dtp-preview"></div>' +
                        '<button type="button" class="dtp-set" data-act="set">Set date and time</button>' +
                    '</div>';

                document.body.appendChild(overlay);

                ui.sheet = overlay.querySelector('.dtp-sheet');
                ui.warn = overlay.querySelector('.dtp-warn');
                ui.preview = overlay.querySelector('.dtp-preview');
                ui.panes = {
                    date: overlay.querySelector('[data-pane="date"]'),
                    time: overlay.querySelector('[data-pane="time"]')
                };

                // events (delegated)
                overlay.addEventListener('click', function (e) {
                    var t = e.target;
                    if (t === overlay) { close(); return; }                       // backdrop tap
                    var act = t.closest('[data-act]');
                    if (act) {
                        if (act.getAttribute('data-act') === 'cancel') close();
                        else doSet();
                        return;
                    }
                    var chip = t.closest('[data-q]');
                    if (chip) { applyQuick(chip.getAttribute('data-q')); return; }
                    var seg = t.closest('[data-tab]');
                    if (seg) { switchTab(seg.getAttribute('data-tab')); return; }
                });
                document.addEventListener('keydown', onKey);
            }

            function onKey(e) {
                if (!overlay || !overlay.classList.contains('open')) return;
                if (e.key === 'Escape') close();
            }

            // ── wheels ───────────────────────────────────────────────────
            function makeWheel(pane, name, items, flex) {
                var w = document.createElement('div');
                w.className = 'dtp-wheel';
                w.style.flex = flex || '1';
                w.setAttribute('data-w', name);
                w.setAttribute('aria-label', name);
                var inner = document.createElement('div');
                inner.className = 'dtp-items';
                inner.style.paddingTop = PAD + 'px';
                inner.style.paddingBottom = PAD + 'px';
                items.forEach(function (it) {
                    var d = document.createElement('div');
                    d.className = 'dtp-item';
                    d.textContent = it.label;
                    d.setAttribute('data-v', it.v);
                    inner.appendChild(d);
                });
                w.appendChild(inner);
                pane.appendChild(w);
                wheels[name] = w;
                w.addEventListener('scroll', function () { requestPaint(); }, { passive: true });
                return w;
            }

            function wheelItems(name) {
                return Array.prototype.map.call(
                    wheels[name].querySelectorAll('.dtp-item'),
                    function (el) { return el.getAttribute('data-v'); });
            }
            function wheelIndex(name) {
                var w = wheels[name];
                if (!w) return 0;
                var max = wheelItems(name).length - 1;
                return Math.max(0, Math.min(max, Math.round(w.scrollTop / ITEM_H)));
            }
            function scrollToIndex(name, idx, animate) {
                var w = wheels[name];
                if (!w) return;
                var max = wheelItems(name).length - 1;
                idx = Math.max(0, Math.min(max, idx));
                w.scrollTo({ top: idx * ITEM_H,
                             behavior: (animate && !reducedMotion) ? 'smooth' : 'auto' });
            }

            // 3D paint: items away from center get rotateX + scale + opacity
            function paint() {
                rafPending = false;
                ['month', 'day', 'year', 'hour', 'minute', 'ampm'].forEach(function (name) {
                    var w = wheels[name];
                    if (!w || w.offsetParent === null) return; // hidden pane
                    var pos = w.scrollTop / ITEM_H;
                    var items = w.querySelectorAll('.dtp-item');
                    for (var i = 0; i < items.length; i++) {
                        var d = i - pos;
                        var a = Math.min(Math.abs(d), 2.5);
                        items[i].style.transform =
                            'rotateX(' + (-d * 16).toFixed(1) + 'deg) scale(' + (1 - a * 0.11).toFixed(3) + ')';
                        items[i].style.opacity = (1 - a * 0.3).toFixed(2);
                    }
                });
            }
            function requestPaint() {
                if (rafPending) return;
                rafPending = true;
                requestAnimationFrame(paint);
                // settle → rebuild days if month/year moved + refresh preview/warning
                clearTimeout(settleTimer);
                settleTimer = setTimeout(onSettled, 140);
            }

            function onSettled() {
                // Only the visible (active) tab's wheels could have been spun by the user.
                readWheelsIntoSel();
                if (activeTab === 'date') {
                    var key = wheelIndex('month') + '-' + wheelIndex('year');
                    if (key !== lastMonthKey) {
                        lastMonthKey = key;
                        rebuildDays();
                    }
                }
                updatePreview();
            }

            function rebuildDays() {
                var dim = daysInMonth(sel.y, sel.m);
                if (sel.d > dim) sel.d = dim;   // e.g. Mar 31 -> Feb => Feb 28/29
                var pane = ui.panes.date;
                var old = wheels.day;
                if (old) old.remove();
                var items = [];
                for (var d = 1; d <= dim; d++) items.push({ v: d, label: String(d) });
                makeWheel(pane, 'day', items, '0.9');
                // re-insert in month/day/year order
                pane.insertBefore(wheels.day, wheels.year);
                scrollToIndex('day', sel.d - 1, false);
                requestPaint();
            }

            // ── read the ACTIVE (visible) tab's wheels into `sel` ────────
            // The hidden tab's wheels are never read — their scroll positions
            // may not have survived while hidden; `sel` already holds them.
            function readWheelsIntoSel() {
                if (activeTab === 'date') {
                    var y = +wheelItems('year')[wheelIndex('year')];
                    var m = +wheelItems('month')[wheelIndex('month')];
                    sel.y = y; sel.m = m;
                    sel.d = Math.min(wheelIndex('day') + 1, daysInMonth(y, m));
                } else {
                    var h12 = +wheelItems('hour')[wheelIndex('hour')];
                    var min = +wheelItems('minute')[wheelIndex('minute')];
                    var ap = wheelItems('ampm')[wheelIndex('ampm')];
                    sel.h24 = (h12 % 12) + (ap === 'PM' ? 12 : 0);
                    sel.min = min;
                }
            }
            // ── wheel index for a `sel` value ─────────────────────────────
            function selIndex(name) {
                switch (name) {
                    case 'month': return sel.m - 1;
                    case 'day': return Math.min(sel.d, daysInMonth(sel.y, sel.m)) - 1;
                    case 'year': { var i = yearList.indexOf(sel.y); return i < 0 ? 0 : i; }
                    case 'hour': return (sel.h24 % 12 || 12) - 1;
                    case 'minute': return sel.min;
                    case 'ampm': return sel.h24 >= 12 ? 1 : 0;
                }
                return 0;
            }
            // ── position a tab's wheels from `sel` (call AFTER pane visible)
            function syncWheels(tab) {
                var names = tab === 'date' ? ['month', 'day', 'year'] : ['hour', 'minute', 'ampm'];
                names.forEach(function (n) { scrollToIndex(n, selIndex(n), false); });
            }
            function fmtDate(y, m, d) { return y + '-' + pad2(m) + '-' + pad2(d); }
            function fmtTime(h24, min) { return pad2(h24) + ':' + pad2(min); }
            function fmtTime12(h24, min) {
                var ap = h24 >= 12 ? 'PM' : 'AM';
                var h = h24 % 12 || 12;
                return h + ':' + pad2(min) + ' ' + ap;
            }

            // ── preview + past warning ───────────────────────────────────
            function updatePreview() {
                var wd = DAYS_FULL[new Date(sel.y, sel.m - 1, sel.d).getDay()];
                ui.preview.textContent = wd + ', ' + pad2(sel.d) + ' ' + MONTHS[sel.m - 1] + ' ' + sel.y +
                                         ' • ' + fmtTime12(sel.h24, sel.min) + ' IST';
                var past = istToUtcMs(sel.y, sel.m, sel.d, sel.h24, sel.min) < Date.now() - 60 * 1000;
                if (past) {
                    ui.warn.hidden = false;
                    ui.warn.textContent = '⚠️ This date & time is in the past';
                } else {
                    ui.warn.hidden = true;
                }
            }

            // ── quick chips (IST) ────────────────────────────────────────
            function applyQuick(which) {
                var now = istParts(new Date());
                var base = new Date(Date.UTC(now.y, now.m - 1, now.d));
                var add = which === 'tomorrow' ? 1 : which === 'nextweek' ? 7 : 0;
                base.setUTCDate(base.getUTCDate() + add);
                sel.y = base.getUTCFullYear(); sel.m = base.getUTCMonth() + 1; sel.d = base.getUTCDate();
                // Date wheels directly rebuild for target (no scroll-race)
                buildDateWheels();
                switchTab('date');
            }

            // ── tabs ─────────────────────────────────────────────────────
            function switchTab(tab) {
                activeTab = tab;
                var btns = overlay.querySelectorAll('[data-tab]');
                for (var i = 0; i < btns.length; i++)
                    btns[i].classList.toggle('active', btns[i].getAttribute('data-tab') === tab);
                ui.panes.date.classList.toggle('hidden', tab !== 'date');
                ui.panes.time.classList.toggle('hidden', tab !== 'time');
                // Pane is visible NOW — (re)position its wheels from `sel`.
                // This is the core of the fix: scrollTo on a hidden pane may not
                // stick, so wheels are synced only after becoming visible.
                syncWheels(tab);
                requestPaint();
                updatePreview();
            }

            // ── build wheels for a given date ────────────────────────────
            function buildDateWheels() {
                var nowY = istParts(new Date()).y;
                var y0 = Math.min(sel.y, nowY - 1), y1 = Math.max(sel.y, nowY + 5);
                ui.panes.date.innerHTML = '';
                wheels.month = wheels.day = wheels.year = null;
                yearList = [];
                for (var yy = y0; yy <= y1; yy++) yearList.push(yy);
                var yi = yearList.map(function (v) { return { v: v, label: String(v) }; });
                makeWheel(ui.panes.date, 'month',
                    MONTHS.map(function (label, i) { return { v: i + 1, label: label }; }), '1.15');
                var dim = daysInMonth(sel.y, sel.m), di = [];
                for (var dd = 1; dd <= dim; dd++) di.push({ v: dd, label: String(dd) });
                makeWheel(ui.panes.date, 'day', di, '0.9');
                makeWheel(ui.panes.date, 'year', yi, '1');
                // Best-effort initial positions; the visible pane is re-synced
                // from `sel` in switchTab() (hidden-pane scrollTo may not stick).
                syncWheels('date');
                lastMonthKey = (sel.m - 1) + '-' + yearList.indexOf(sel.y);
            }
            function buildTimeWheels() {
                ui.panes.time.innerHTML = '';
                wheels.hour = wheels.minute = wheels.ampm = null;
                var hi = [];
                for (var h = 1; h <= 12; h++) hi.push({ v: h, label: String(h) });
                var mi = [];
                for (var mm = 0; mm < 60; mm++) mi.push({ v: mm, label: pad2(mm) });
                makeWheel(ui.panes.time, 'hour', hi, '1');
                makeWheel(ui.panes.time, 'minute', mi, '1');
                makeWheel(ui.panes.time, 'ampm', [{ v: 'AM', label: 'AM' }, { v: 'PM', label: 'PM' }], '0.9');
                syncWheels('time');
            }

            // ── open / close / set ───────────────────────────────────────
            function open(opts) {
                opts = opts || {};
                build();
                reducedMotion = window.matchMedia &&
                    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

                var now = istParts(new Date());
                // `sel` = single source of truth, seeded from existing values (or IST now).
                sel = { y: now.y, m: now.m, d: now.d, h24: now.h, min: now.min };
                if (opts.date) {
                    var dp = String(opts.date).split('-').map(Number);
                    if (dp.length === 3 && dp[0] > 1900) { sel.y = dp[0]; sel.m = dp[1]; sel.d = dp[2]; }
                }
                if (opts.time) {
                    var tp = String(opts.time).split(':').map(Number);
                    if (tp.length >= 2 && tp[0] >= 0 && tp[0] < 24) { sel.h24 = tp[0]; sel.min = tp[1] || 0; }
                }
                sel.d = Math.min(sel.d, daysInMonth(sel.y, sel.m));
                onSetCb = typeof opts.onSet === 'function' ? opts.onSet : null;

                buildDateWheels();
                buildTimeWheels();
                switchTab(opts.tab === 'time' ? 'time' : 'date');

                var prevOverflow = document.body.style.overflow;
                overlay.setAttribute('data-prev-overflow', prevOverflow);
                document.body.style.overflow = 'hidden';

                requestAnimationFrame(function () {
                    requestAnimationFrame(function () {
                        overlay.classList.add('open');
                        paint();
                        updatePreview();
                    });
                });
            }

            function close() {
                if (!overlay || !overlay.classList.contains('open')) return;
                overlay.classList.remove('open');
                document.body.style.overflow = overlay.getAttribute('data-prev-overflow') || '';
                clearTimeout(settleTimer);
            }

            function doSet() {
                // Read the visible tab's wheels one last time, then publish the
                // authoritative `sel` — date AND time always saved together.
                readWheelsIntoSel();
                if (onSetCb) {
                    try { onSetCb({ date: fmtDate(sel.y, sel.m, sel.d), time: fmtTime(sel.h24, sel.min) }); }
                    catch (e) { /* consumer handles */ }
                }
                close();
            }

            window.DateTimePickerSheet = { open: open, close: close };
        })();
