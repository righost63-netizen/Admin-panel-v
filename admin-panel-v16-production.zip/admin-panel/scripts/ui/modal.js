        window.showFullModal = function(id) {
            // নতুন মডাল খোলার আগে: অন্য সব শিট/ওভারলে + ফুল মডাল বন্ধ (একটাই layer থাকবে)
            window._overlayGen = (window._overlayGen || 0) + 1;
            const gen = window._overlayGen;
            document.querySelectorAll('.bottom-sheet.visible').forEach(s => s.classList.remove('visible'));
            document.querySelectorAll('.sheet-overlay.visible, .sheet-backdrop.visible').forEach(o => o.classList.remove('visible'));
            document.querySelectorAll('.full-modal.visible').forEach(m => {
                m.classList.remove('visible');
                m.style.display = 'none';
            });

            // অ্যাপ রুটে 'modal-pushed' ক্লাস যোগ করে পেছনের স্ক্রিনকে বামে সরানো হবে
            const root = document.querySelector('.app-root');
            if (root) root.classList.add('modal-pushed');

            const modal = document.getElementById(id);
            if (modal) {
                modal.style.display = 'flex';
                requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                        if (gen !== window._overlayGen) return; // এর মধ্যে নতুন overlay খুলেছে — এটা আর দেখিও না
                        modal.classList.add('visible');
                    });
                });
            }
        };

        window.hideFullModal = function(id) {
            const modal = document.getElementById(id);
            const root = document.querySelector('.app-root');
            if (modal) {
                modal.classList.remove('visible');

                setTimeout(() => {
                    modal.style.display = 'none';
                    // যদি অন্য কোনো ফুল মডাল স্ক্রিনে খোলা না থাকে, তবেই পেছনের স্ক্রিন ফেরত আসবে
                    const visibleModals = document.querySelectorAll('.full-modal.visible').length;
                    if (visibleModals === 0 && root) {
                        root.classList.remove('modal-pushed');
                    }
                }, 400);
            } else if (root) {
                // মডাল element DOM-এ নেই (re-render-এ মুছে গেছে) — তবু shift আটকে থাকবে না
                root.classList.remove('modal-pushed');
            }
        };

        window.closeModal = function(id) {
            hideFullModal(id);
        };

        // ══════════════════════════════════════════
        // TYPE-TO-CONFIRM modal (destructive actions)
        // ══════════════════════════════════════════
        // openTypeConfirm({ eyebrow, title, target, desc, expect, confirmLabel, onConfirm })
        // User must type `expect` (exact match) to enable the confirm button.
        // ESC / overlay click / Cancel closes. Focus goes to the input on open.
        window.openTypeConfirm = function(opts) {
            opts = opts || {};
            const expect = String(opts.expect || 'DELETE').trim() || 'DELETE';
            document.getElementById('ttcOverlay')?.remove();

            const ov = document.createElement('div');
            ov.className = 'ttc-overlay';
            ov.id = 'ttcOverlay';
            ov.setAttribute('role', 'dialog');
            ov.setAttribute('aria-modal', 'true');
            ov.setAttribute('aria-label', opts.title || 'Confirm');
            ov.innerHTML = `
                <div class="ttc-card">
                    <div class="ttc-hero">
                        <div class="ttc-eyebrow">${esc(opts.eyebrow || 'Danger zone')}</div>
                        <div class="ttc-title">${esc(opts.title || 'Are you sure?')}</div>
                        ${opts.target ? `<div class="ttc-target">${esc(opts.target)}</div>` : ''}
                    </div>
                    <div class="ttc-body">
                        ${opts.desc ? `<div class="ttc-desc">${opts.desc}</div>` : ''}
                        <label class="ttc-type-label" for="ttcInput">Type <code>${esc(expect)}</code> to confirm</label>
                        <input class="form-input" id="ttcInput" type="text" placeholder="${esc(expect)}"
                            autocomplete="off" autocapitalize="characters" spellcheck="false"
                            style="font-family:ui-monospace,monospace;letter-spacing:.06em;" />
                        <div class="ttc-actions">
                            <button class="cxs-btn cxs-btn-ghost" id="ttcCancel" type="button">Cancel</button>
                            <button class="cxs-btn cxs-btn-danger" id="ttcConfirm" type="button" disabled>${esc(opts.confirmLabel || 'Confirm Delete')}</button>
                        </div>
                    </div>
                </div>`;
            document.body.appendChild(ov);

            const input = ov.querySelector('#ttcInput');
            const confirmBtn = ov.querySelector('#ttcConfirm');
            const close = () => ov.remove();

            input.addEventListener('input', () => {
                confirmBtn.disabled = input.value.trim() !== expect;
            });
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !confirmBtn.disabled) confirmBtn.click();
            });
            ov.querySelector('#ttcCancel').addEventListener('click', close);
            ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
            ov.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') close();
                // simple focus trap: keep tab inside the modal
                if (e.key === 'Tab') {
                    const f = ov.querySelectorAll('button, input');
                    const first = f[0], last = f[f.length - 1];
                    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
                }
            });
            confirmBtn.addEventListener('click', async () => {
                confirmBtn.disabled = true;
                confirmBtn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
                try {
                    await opts.onConfirm();
                    close();
                } catch (e) {
                    console.error('type-confirm action failed:', e);
                    showToast('Failed: ' + (e.message || e), 'error');
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = opts.confirmLabel || 'Confirm Delete';
                }
            });

            setTimeout(() => input.focus(), 60);
        };

        window.closeTypeConfirm = function() {
            document.getElementById('ttcOverlay')?.remove();
        };
