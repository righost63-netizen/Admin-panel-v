// ✅ [নতুন ফাইল] সাইডবার (drawer): খোলা/বন্ধ + বাম কিনারা থেকে সোয়াইপ
        window.openDrawer = function() {
            const email = auth.currentUser?.email || '';
            const name = currentUser?.name || currentUser?.displayName || email.split('@')[0] || 'Admin';
            document.getElementById('drawerName').textContent = name;
            document.getElementById('drawerEmail').textContent = email || 'FF Admin Panel';
            document.getElementById('drawerAvatar').textContent = (Array.from(name.trim())[0] || 'A').toUpperCase();

            // Theme toggle removed (spec item 11): single fixed deep royal-blue dark theme, no switching.

            document.getElementById('drawer').classList.add('open');
            document.getElementById('drawer').setAttribute('aria-hidden', 'false');
            document.getElementById('drawerBackdrop').classList.add('open');
        };

        window.closeDrawer = function() {
            document.getElementById('drawer')?.classList.remove('open');
            document.getElementById('drawer')?.setAttribute('aria-hidden', 'true');
            document.getElementById('drawerBackdrop')?.classList.remove('open');
        };

        // বাম কিনারা থেকে ডানে সোয়াইপ = খোলা, ড্রয়ারে বামে সোয়াইপ = বন্ধ
        (function initDrawerSwipe() {
            let sx = 0, sy = 0, mode = null;
            document.addEventListener('touchstart', e => {
                const t = e.touches[0];
                sx = t.clientX; sy = t.clientY;
                const isOpen = document.getElementById('drawer')?.classList.contains('open');
                const appVisible = document.getElementById('app')?.classList.contains('visible');
                mode = isOpen ? 'close' : (appVisible && sx < 22 ? 'open' : null);
            }, { passive: true });
            document.addEventListener('touchmove', e => {
                if (!mode) return;
                const t = e.touches[0];
                const dx = t.clientX - sx;
                if (Math.abs(t.clientY - sy) > 40) { mode = null; return; }
                if (mode === 'open' && dx > 60) { mode = null; openDrawer(); }
                else if (mode === 'close' && dx < -60) { mode = null; closeDrawer(); }
            }, { passive: true });
            document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });
        })();
