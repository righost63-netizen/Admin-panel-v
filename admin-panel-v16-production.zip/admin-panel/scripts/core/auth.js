// ── AUTH ACTIONS ──
        // ══════════════════════════════════════════
        // AUTH ACTIONS
        // ══════════════════════════════════════════
        window.doLogin = async function() {
            const email = document.getElementById('loginEmail').value.trim();
            const pw = document.getElementById('loginPassword').value;
            if (!email || !pw) {
                showToast('Enter email and password', 'warning');
                return;
            }
            const btn = document.getElementById('loginBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
            try {
                const cred = await signInWithEmailAndPassword(auth, email, pw);
                const uDoc = await getDoc(doc(db, 'users', cred.user.uid));
                if (!uDoc.exists() || uDoc.data().role !== 'admin') {
                    await signOut(auth);
                    showToast('Access denied: Not an admin account', 'error');
                } else {
                    showApp(); // সফলভাবে লগইনের পর ড্যাশবোর্ড দেখানোর জন্য এটি অত্যন্ত জরুরি
                }
            } catch (e) {
                showToast(e.message, 'error');
            }
            btn.disabled = false;
            btn.textContent = 'Admin Login';
        };

        window.doLogout = function() {
            showActionSheet('Logout', 'Are you sure you want to logout?', [{
                label: 'Logout',
                style: 'destructive',
                action: async () => {
                    await signOut(auth);
                    listeners.forEach(u => u && u());
                    listeners = [];
                    // FIX: লগআউটের পর loadedScreens রিসেট না করলে আবার লগইনে
                    // পুরনো (মরা) DOM পড়ে থাকত, রিয়েলটাইম আপডেট আসত না।
                    loadedScreens = {};
                    activeTab = 'dashboard';
                }
            }]);
        };

        window.togglePw = function() {
            const inp = document.getElementById('loginPassword');
            const btn = document.getElementById('pwToggleBtn');
            if (inp.type === 'password') {
                inp.type = 'text';
                btn.textContent = 'Hide';
            } else {
                inp.type = 'password';
                btn.textContent = 'Show';
            }
        };


// ── FIX 1: SECURE ADMIN REGISTER ──
        // ══════════════════════════════════════════
        // FIX 1 — SECURE ADMIN REGISTER VIA CLOUD FUNCTION
        // ══════════════════════════════════════════
        window.toggleRegister = function() {
            const section = document.getElementById('registerSection');
            const chevron = document.getElementById('registerChevron');
            const isOpen = section.classList.contains('expanded');
            section.classList.toggle('expanded', !isOpen);
            chevron.classList.toggle('open', !isOpen);
        };

        // ── Cloud Function ছাড়া নিরাপদ admin রেজিস্ট্রেশন (request → approve মডেল) ──
        // নতুন user শুধু Auth অ্যাকাউন্ট + role='pending' ডকুমেন্ট বানাতে পারে।
        // role='admin' দেওয়ার ক্ষমতা শুধু existing admin-এর (Users স্ক্রিন থেকে Approve)।
        // Firestore rules নতুন user-কে নিজের ডকে role='admin' লিখতে দেয় না, তাই নিরাপদ।
        window.doAdminRegister = async function() {
            const fullName = document.getElementById('regName').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const password = document.getElementById('regPassword').value;
            const confirm = document.getElementById('regConfirm').value;
            if (!fullName || !email || !password || !confirm) {
                showToast('All fields are required', 'warning');
                return;
            }
            if (password !== confirm) {
                showToast('Passwords do not match', 'error');
                return;
            }
            const btn = document.getElementById('registerBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
            let createdUser = null;
            let profileDone = false;
            try {
                // admin register চলাকালীন navigation-এর guard যেন signOut না করে
                window.__registeringAdmin = true;
                const {
                    createUserWithEmailAndPassword
                } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js");
                // 1. Firebase Auth অ্যাকাউন্ট তৈরি
                const cred = await createUserWithEmailAndPassword(auth, email, password);
                createdUser = cred.user;

                // 2. users ডকুমেন্ট — role 'pending' (admin approval-এর অপেক্ষায়)
                await setDoc(doc(db, 'users', cred.user.uid), {
                    uid: cred.user.uid,
                    name: fullName,
                    email: email,
                    role: 'pending',
                    walletBalance: 0,
                    totalWins: 0,
                    totalEarnings: 0,
                    joinedTournaments: [],
                    createdAt: serverTimestamp()
                });
                profileDone = true;

                // 3. সাথে সাথে সাইন-আউট (approval-এর আগে প্যানেলে ঢুকতে পারবে না)
                await signOut(auth);
                window.__registeringAdmin = false;

                showToast('Account created! Main admin-কে বলো Users স্ক্রিন থেকে approve করতে।', 'success');
                document.getElementById('registerSection').classList.remove('expanded');
                document.getElementById('registerChevron').classList.remove('open');
                ['regName', 'regEmail', 'regPassword', 'regConfirm'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.value = '';
                });
            } catch (e) {
                // প্রোফাইল তৈরি না হলে অর্ধেক অ্যাকাউন্ট মুছে ফেলো (স্প্যাম রোধ)
                if (createdUser && !profileDone) {
                    try {
                        const { deleteUser } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js");
                        await deleteUser(createdUser).catch(() => {});
                    } catch (e2) {}
                }
                console.error('doAdminRegister error:', e);
                showToast(e.message || 'Registration failed', 'error');
            } finally {
                window.__registeringAdmin = false;
                btn.disabled = false;
                btn.textContent = 'Create Admin Account';
            }
        };



