// ── SPLASH + AUTH ──
        // ══════════════════════════════════════════
        // SPLASH + AUTH
        // ══════════════════════════════════════════
        // ✅ [নতুন] আগে স্প্ল্যাশ একটা ফিক্সড ২২০০+৬০০ms টাইমারে হাইড হতো, Index.html-এর boot()
        // (CSS/pages/script লোড) আসলেই শেষ হয়েছে কিনা তা না দেখেই — নেট স্লো হলে স্প্ল্যাশ আগেই সরে গিয়ে
        // আনস্টাইলড লগইন পেজ / raw টুর্নামেন্ট ফর্ম দেখা যেত। এখন কমপক্ষে ২২০০ms (আগের মতোই ব্র্যান্ডিং পজ)
        // *এবং* boot() সত্যিই শেষ হওয়া — দুটোই লাগবে।
        const MIN_SPLASH_MS = 2200;
        const splashMinDelay = new Promise(resolve => setTimeout(resolve, MIN_SPLASH_MS));
        const splashBootReady = window.__appBootReady
            ? Promise.resolve()
            : new Promise(resolve => window.addEventListener('app:boot-complete', resolve, { once: true }));

        Promise.all([splashMinDelay, splashBootReady]).then(() => {
            document.getElementById('splash').classList.add('hide');
            setTimeout(() => {
                document.getElementById('splash').style.display = 'none';
                onAuthStateChanged(auth, async (user) => {
                    if (user) {
                        // FIX: admin register চলাকালীন (users ডক তৈরি হওয়ার আগে)
                        // এই guard নতুন user-কে signOut করে দিত — ফ্ল্যাগ থাকলে কিছু করো না।
                        if (window.__registeringAdmin) return;
                        let uDoc;
                        try {
                            uDoc = await getDoc(doc(db, 'users', user.uid));
                        } catch (e) {
                            showLogin();
                            return;
                        }
                        if (uDoc.exists() && uDoc.data().role === 'admin') {
                            currentUser = {
                                uid: user.uid,
                                ...uDoc.data()
                            };
                            showApp();   // ✅ [নতুন] Firestore read-এর try/catch এর বাইরে আনা হলো, যাতে
                                         // showApp()/loadAllScreens()-এ কোনো ভুল হলে সেটা "Not authorized" হিসেবে ভুল দেখানো না হয়
                        } else {
                            await signOut(auth);
                            showLogin();
                            showToast('Not authorized as admin', 'error');
                        }
                    } else {
                        showLogin();
                    }
                });
            }, 600);
        });

        function showLogin() {
            document.getElementById('loginScreen').classList.add('visible');
            document.getElementById('app').classList.remove('visible');
        }

        function showApp() {
            document.getElementById('loginScreen').classList.remove('visible');
            document.getElementById('app').classList.add('visible');
            loadAllScreens();
        }




// ── NAVIGATION ──
        // ══════════════════════════════════════════
        // NAVIGATION
        // ══════════════════════════════════════════
        // ✅ [নতুন] সাইডবারের জন্য বদলানো: .tab-item → .nav-item, আর নেভিগেট করলে সাইডবার বন্ধ হয়
        // ✅ [নতুন] tab → তার load...() ফাংশনের *নাম* (string)। সরাসরি ফাংশন রেফারেন্স রাখলে এই লাইনটা
        // navigation.js পার্স হওয়ার সময়েই এক্সিকিউট হয়ে যেত, তখন dashboard.js/banners.js ইত্যাদি এখনো
        // লোড হয়নি — তাই "loadDashboard is not defined" ভেঙে পড়তো পুরো script। string রাখলে আসল
        // ফাংশনটা খোঁজা হয় ট্যাবে ক্লিকের সময় (window[নাম] দিয়ে), ততক্ষণে সব script লোড হয়ে থাকে।
        const screenLoaders = {
            dashboard:     'loadDashboard',
            banners:       'loadBanners',
            modes:         'loadModes',          // ← drawer.html: id="tab-modes" onclick="showScreen('modes')" (screen-modes)
            tournaments:   'loadTournaments',
            players:       'loadPlayersScreen',
            reports:       'loadPlayerReports',
            wallet:        'loadWallet',
            payout:        'loadPayout',
            users:         'loadUsers',
            notifications: 'loadNotifications',
            staff:         'loadStaff',
            settings:      'loadSettings',
            logs:          'loadLogs'
        };

        // ✅ [নতুন] switchTab() আর showScreen() দুটোই এটা কল করে — drawer.html-এ কিছু বাটন switchTab()
        // আর কিছু বাটন (banners, modes, notifications) showScreen() ব্যবহার করে, তাই দুই জায়গাতেই lazy-load দরকার
        function ensureScreenLoaded(name) {
            if (!loadedScreens[name]) {
                const fnName = screenLoaders[name];
                const loaderFn = fnName && window[fnName];
                if (typeof loaderFn === 'function') {
                    loaderFn();
                    loadedScreens[name] = true;
                }
            }
        }

        window.switchTab = function(tab) {
            // ✅ [নতুন] স্ক্রিন বদলালে খোলা শিট/মডাল/পিকার সব বন্ধ — ভুল স্ক্রিনের উপর
            // ভেসে থাকা বা dashboard shift হয়ে আটকে থাকা ঠেকায়
            if (window.closeAllOverlays) window.closeAllOverlays();
            document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
            document.querySelectorAll('.nav-item').forEach(t => t.classList.remove('active'));   // ← .tab-item ছিল, এখন .nav-item
            const screenEl = document.getElementById(`screen-${tab}`);
            const tabEl = document.getElementById(`tab-${tab}`);
            if (screenEl) screenEl.classList.add('active');
            if (tabEl) tabEl.classList.add('active');
            activeTab = tab;
            ensureScreenLoaded(tab);                                                               // ← নতুন লাইন
            window.closeDrawer?.();                                                              // ← নতুন লাইন
        };

        window.showScreen = function(name) {
            // ✅ [নতুন] স্ক্রিন বদলালে খোলা শিট/মডাল/পিকার সব বন্ধ (উপরের মতো)
            if (window.closeAllOverlays) window.closeAllOverlays();
            document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
            const el = document.getElementById(`screen-${name}`);
            if (el) el.classList.add('active');
            activeTab = name;
            document.querySelectorAll('.nav-item').forEach(t => t.classList.remove('active'));   // ← .tab-item ছিল, এখন .nav-item
            const tabEl = document.getElementById(`tab-${name}`);
            if (tabEl) tabEl.classList.add('active');
            ensureScreenLoaded(name);                                                              // ← নতুন লাইন
            window.closeDrawer?.();                                                              // ← নতুন লাইন
        };

