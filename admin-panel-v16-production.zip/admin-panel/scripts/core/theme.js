// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// THEME — DELETED (spec item 11)
// The admin panel now uses ONE fixed theme: "Production Console"
// deep royal-blue dark (tokens in styles/variables.css + assets/premium.css).
// Theme switching was completely removed: no theme attribute on <html>,
// no stored theme key, no mode toggles anywhere. This file is kept
// non-empty so old references to it do not 404; it intentionally
// exports nothing.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
(function singleFixedTheme() {
    'use strict';
    // No theme switching exists. Theme is the fixed deep royal-blue dark palette.
    window.__THEME_SINGLE_FIXED__ = true;
})();
