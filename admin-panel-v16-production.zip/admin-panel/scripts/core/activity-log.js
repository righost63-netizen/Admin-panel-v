        // ══════════════════════════════════════════
        // ADMIN ACTIVITY LOG — shared helper
        // ══════════════════════════════════════════
        // logAdminAction(action, module, details)
        // Writes one entry to the `adminActivityLogs` collection (admin-only,
        // see firestore.rules). Fire-and-forget: never breaks the admin flow.
        // Fields: timestamp, adminName, adminEmail, action, module, details, device.
        window.logAdminAction = function(action, module, details) {
            try {
                if (typeof db === 'undefined' || typeof collection === 'undefined') return;
                const cu = window.currentUser || {};
                const authEmail = (window.auth && window.auth.currentUser && window.auth.currentUser.email) || '';
                const email = authEmail || cu.email || '';
                const name = cu.name || cu.displayName || (email ? String(email).split('@')[0] : 'Admin');
                const entry = {
                    timestamp: serverTimestamp(),
                    adminName: String(name || 'Admin').slice(0, 80),
                    adminEmail: String(email || '').slice(0, 120),
                    action: String(action || '').slice(0, 120),
                    module: String(module || '').slice(0, 60),
                    details: String(details || '').slice(0, 600),
                    device: (navigator.userAgent || '').slice(0, 140)
                };
                addDoc(collection(db, 'adminActivityLogs'), entry).catch(function() {});
            } catch (e) { /* silent — logging must never break admin actions */ }
        };
