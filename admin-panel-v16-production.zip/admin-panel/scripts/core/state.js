        // ══════════════════════════════════════════
        // STATE
        // ══════════════════════════════════════════
        let currentUser = null;
        let activeTab = 'dashboard';
        let listeners = [];
        let loadedScreens = {};   // ← [নতুন] কোন tab-এর load...() ইতিমধ্যে কল হয়েছে (subscribe হয়েছে) তার ট্র্যাকিং — দ্বিতীয়বার একই tab-এ গেলে আবার reload/re-subscribe হবে না
        let allUsers = [];
        let lastVisibleUserDoc = null;
        let isUsersLoading = false;
        let usersSearchQuery = "";
        let tournamentMode = 'Solo';
        let tournamentContactMethod = 'telegram';
        let notifTarget = 'all';
        let notifType = 'info';
        let selectedNotifUserId = null;
        let editingBannerId = null;
        let editingModeId = null;
        let editingTournamentId = null;
        let editingUserId = null;
        let tournamentBannerUrl = null;
        let bannerImgUrl = null;
        let selectedEmoji = '🎮';
        let currentTournamentForPlayers = null;
        let currentTournamentForResults = null;
        let resultsData = {};
        let lastVisibleWithdrawDoc = null;
        let isWithdrawLoading = false;
        let withdrawSearchQuery = "";
        let withdrawMethodQuery = "all";



