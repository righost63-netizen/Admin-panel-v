        // ══════════════════════════════════════════
        // STAFF PANEL — sidebar screen
        //  • Staff Panel enable/disable control (settings/staffPanel)
        //  • Staff members: online/offline, email, role, last activity
        //  • Staff log history (30 days) + clear / delete-old-30-days
        // NOTE: Firebase Auth কখনোই কারো password ফেরত দেয় না — তাই password
        // এখানে দেখানো সম্ভব না (দেখানো মানেই plaintext-এ সেভ করা, যা মারাত্মক
        // security risk)। বদলে "Send password reset email" দেওয়া আছে।
        // ══════════════════════════════════════════════════════════════

        let _staffUnsub = null;
        let _staffPanelUnsub = null;
        let _staffListCache = [];

        window.loadStaff = function() {
            const el = document.getElementById('staffContent');
            if (!el) return;
            el.innerHTML = `
    <div class="spacer"></div>

    <div class="section-label">Staff Panel Control</div>
    <div class="stf-control-card">
      <div class="stf-control-top">
        <div class="stf-control-ic">🛡️</div>
        <div class="stf-control-main">
          <div class="stf-control-title">Staff Panel <span class="staff-badge offline" id="stfBadge">🔴 Offline</span></div>
          <div class="stf-control-sub" id="stfActivity">Last staff activity: Never</div>
          <div class="stf-control-sub faint" id="stfToggled">—</div>
        </div>
        <label class="toggle" aria-label="Enable staff panel"><input type="checkbox" id="stfToggle" onchange="toggleStaffPanel(this.checked)"><span class="toggle-slider"></span></label>
      </div>
      <div class="stf-control-foot" id="stfActiveStaff" hidden></div>
    </div>

    <div class="section-label">Staff Members <span class="us-count" id="stfCount" hidden></span></div>
    <div id="stfMembers"><div class="loading-center"><div class="spinner spinner-accent"></div></div></div>

    <div class="section-label">Pending Approval</div>
    <div id="stfPending"><div class="loading-center"><div class="spinner spinner-accent"></div></div></div>

    <div class="section-label">Staff Log History <span style="font-weight:500;color:var(--color-text-tertiary);font-size:12px;">· last 30 days</span></div>
    <div class="stf-log-actions">
      <button class="btn-sm btn-secondary" onclick="stfDeleteOldLogs()">🧹 Delete older than 30 days</button>
      <button class="btn-sm btn-error" onclick="stfClearLogs()">🗑️ Clear Logs</button>
    </div>
    <div id="stfLogs" style="margin-top:12px;"><div class="loading-center"><div class="spinner spinner-accent"></div></div></div>
    <div style="height:12px;"></div>`;

            _initStaffPanelControl();
            _loadStaffMembers();
            _loadStaffLogs();
        };

        // ── 1) Panel on/off control (moved from Settings) ──
        function _initStaffPanelControl() {
            const badgeEl = document.getElementById('stfBadge');
            const activityEl = document.getElementById('stfActivity');
            const toggleEl = document.getElementById('stfToggle');
            const toggledEl = document.getElementById('stfToggled');
            const activeEl = document.getElementById('stfActiveStaff');
            if (!badgeEl || !toggleEl) return;
            if (_staffPanelUnsub) { _staffPanelUnsub(); _staffPanelUnsub = null; }

            const fmtT = (v) => {
                if (!v) return null;
                const d = v.toDate ? v.toDate() : new Date(v);
                return (d && !isNaN(d.getTime())) ? d : null;
            };
            const render = (data) => {
                const enabled = !!(data && data.isEnabled === true);
                badgeEl.className = 'staff-badge ' + (enabled ? 'online' : 'offline');
                badgeEl.textContent = enabled ? '🟢 Online' : '🔴 Offline';
                toggleEl.checked = enabled;
                const last = fmtT(data && data.lastActiveAt);
                if (activityEl) activityEl.textContent = 'Last staff activity: ' + (last ? last.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Never');
                if (toggledEl) {
                    const tt = fmtT(data && data.lastToggledAt);
                    toggledEl.textContent = tt ? `Last ${enabled ? 'enabled' : 'disabled'}: ${tt.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })} by ${data.lastToggledBy || 'admin'}` : '';
                }
                // কোন staff এখন active (heartbeat < 3 min)
                if (activeEl) {
                    const email = data && data.lastActiveStaffEmail;
                    const online = enabled && last && email && (Date.now() - last.getTime() < 3 * 60 * 1000);
                    if (online) {
                        activeEl.hidden = false;
                        activeEl.innerHTML = `<span class="stf-live-dot"></span> Currently active: <b>${esc(email)}</b>`;
                    } else {
                        activeEl.hidden = true;
                        activeEl.innerHTML = '';
                    }
                }
                // sidebar badge: online staff count (1/0 — single heartbeat doc)
                const sb = document.getElementById('staffOnlineBadge');
                if (sb) {
                    const email = data && data.lastActiveStaffEmail;
                    const online = enabled && last && email && (Date.now() - last.getTime() < 3 * 60 * 1000);
                    sb.style.display = online ? 'inline-flex' : 'none';
                    sb.textContent = online ? '1' : '0';
                }
            };
            try {
                _staffPanelUnsub = onSnapshot(doc(db, 'settings', 'staffPanel'),
                    (snap) => render(snap.exists() ? snap.data() : null),
                    (err) => console.warn('[StaffPanel] listener:', err.message));
                listeners.push(() => { if (_staffPanelUnsub) { _staffPanelUnsub(); _staffPanelUnsub = null; } });
            } catch (e) { console.warn('[StaffPanel] init:', e.message); }
        }

        // toggleStaffPanel আগেই settings.js-এ আছে — এখানে reuse হবে (window.toggleStaffPanel)

        // ── 2) Staff members ──
        async function _loadStaffMembers() {
            const el = document.getElementById('stfMembers');
            const pendEl = document.getElementById('stfPending');
            if (!el) return;
            try {
                const snap = await getDocs(query(collection(db, 'users'), where('role', 'in', ['staff', 'pending-staff']), limit(100)));
                _staffListCache = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                const staff = _staffListCache.filter(u => u.role === 'staff');
                const pending = _staffListCache.filter(u => u.role === 'pending-staff');

                // সাম্প্রতিক activity: staffActivityLogs থেকে প্রত্যেক staff-এর latest
                let lastLogBy = {};
                try {
                    const lsnap = await getDocs(query(collection(db, 'staffActivityLogs'), orderBy('timestamp', 'desc'), limit(200)));
                    lsnap.docs.forEach(d => {
                        const l = d.data();
                        const key = l.staffUid || l.staffEmail;
                        if (key && !lastLogBy[key]) lastLogBy[key] = l;
                    });
                } catch (e) { console.warn('staff logs for members failed:', e.message); }

                let panelData = null;
                try {
                    const psnap = await getDoc(doc(db, 'settings', 'staffPanel'));
                    panelData = psnap.exists() ? psnap.data() : null;
                } catch (e) { /* ignore */ }
                const panelOn = !!(panelData && panelData.isEnabled === true);
                const hbAt = panelData && panelData.lastActiveAt ? (panelData.lastActiveAt.toDate ? panelData.lastActiveAt.toDate() : new Date(panelData.lastActiveAt)) : null;
                const hbEmail = panelData && panelData.lastActiveStaffEmail;

                const isOnline = (u) => {
                    const email = u.email || '';
                    return panelOn && hbAt && hbEmail === email && (Date.now() - hbAt.getTime() < 3 * 60 * 1000);
                };
                const lastActiveStr = (u) => {
                    const l = lastLogBy[u.id] || lastLogBy[u.email];
                    const t = l && l.timestamp ? (l.timestamp.toDate ? l.timestamp.toDate() : new Date(l.timestamp)) : null;
                    if (t && !isNaN(t.getTime())) return t.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
                    const c = u.createdAt ? (u.createdAt.toDate ? u.createdAt.toDate() : new Date(u.createdAt)) : null;
                    return (c && !isNaN(c.getTime())) ? ('Joined ' + c.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })) : '—';
                };

                const cnt = document.getElementById('stfCount');
                if (cnt) { cnt.hidden = false; cnt.textContent = staff.length; }

                el.innerHTML = staff.length ? `<div class="stf-list">` + staff.map(u => {
                    const online = isOnline(u);
                    const name = u.name || 'Staff';
                    return `<div class="stf-card">
                      <div class="stf-top">
                        <div class="us-avatar">${esc(name.trim().charAt(0).toUpperCase() || '?')}</div>
                        <div class="us-who">
                          <div class="us-name-row"><span class="us-name">${esc(name)}</span>
                            <span class="us-admin" style="background:rgba(56, 189, 248,.15);color:#38BDF8;border:1px solid rgba(56, 189, 248,.35);">Staff</span></div>
                          <div class="us-email">${esc(u.email || '—')}</div>
                        </div>
                        <span class="stf-online ${online ? 'on' : ''}"><i></i>${online ? 'Online' : 'Offline'}</span>
                      </div>
                      <div class="stf-details">
                        <div class="stf-detail"><span>Password</span><b class="stf-masked">•••••••• <em>managed by Firebase Auth</em></b></div>
                        <div class="stf-detail"><span>Last activity</span><b>${esc(lastActiveStr(u))}</b></div>
                        <div class="stf-detail"><span>Permissions</span><b>Withdrawals: approve / reject</b></div>
                      </div>
                      <div class="stf-card-actions">
                        <button class="us-btn us-btn-edit" onclick="stfResetPassword('${u.id}')">📧 Send password reset email</button>
                        <button class="us-btn us-btn-del" onclick="stfRemoveStaff('${u.id}', '${esc((u.name || u.email || '').replace(/'/g, "\\'"))}')">Remove</button>
                      </div>
                    </div>`;
                }).join('') + `</div>` : `<div class="us-empty"><div class="us-empty-ic">🛡️</div><h4>No staff yet</h4><p>Staff signup করলে admin approve করার পর এখানে দেখাবে।</p></div>`;

                if (pendEl) {
                    pendEl.innerHTML = pending.length ? `<div class="stf-list">` + pending.map(u => `
                      <div class="stf-card stf-pending-card">
                        <div class="stf-top">
                          <div class="us-avatar">?</div>
                          <div class="us-who">
                            <div class="us-name-row"><span class="us-name">${esc(u.name || 'Unknown')}</span>
                              <span class="us-admin" style="background:rgba(255, 213, 74,.15);color:#ffd54a;border:1px solid rgba(255, 213, 74,.35);">Pending</span></div>
                            <div class="us-email">${esc(u.email || '—')}</div>
                          </div>
                        </div>
                        <div class="stf-card-actions">
                          <button class="us-btn us-btn-edit" onclick="approveStaff('${u.id}', '${esc((u.name || '').replace(/'/g, "\\'"))}')">✅ Approve Staff</button>
                        </div>
                      </div>`).join('') + `</div>`
                      : `<div class="hs-empty"><p style="color:var(--color-text-tertiary);font-size:13.5px;">No pending requests 🎉</p></div>`;
                }
            } catch (e) {
                console.error('_loadStaffMembers error:', e);
                el.innerHTML = `<div class="us-empty"><h4>Failed to load</h4><p>${esc(e.message)}</p></div>`;
            }
        }

        // Password reset email (Firebase Auth — password দেখানো/বদলানো যায় না)
        window.stfResetPassword = function(uid) {
            const u = _staffListCache.find(x => x.id === uid) || {};
            const email = u.email || '';
            if (!email) { showToast('No email for this staff member', 'warning'); return; }
            showActionSheet('Send password reset email?', `${email} ঠিকানায় reset link যাবে।`, [{
                label: 'Send Reset Email',
                style: 'default',
                action: async () => {
                    try {
                        await sendPasswordResetEmail(auth, email);
                        showToast('Reset email sent! 📧', 'success');
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };

        // Staff remove → role 'staff' থেকে সরিয়ে সাধারণ user বানাও (Auth ডিলিট Console থেকে)
        window.stfRemoveStaff = function(uid, name) {
            showActionSheet('Remove staff access?', `"${name}" আর Staff Panel-এ ঢুকতে পারবে না।`, [{
                label: 'Remove Staff',
                style: 'destructive',
                action: async () => {
                    try {
                        await updateDoc(doc(db, 'users', uid), { role: 'user', updatedAt: serverTimestamp() });
                        showToast('Staff access removed', 'success');
                        _loadStaffMembers();
                    } catch (e) { showToast(e.message, 'error'); }
                }
            }]);
        };

        // ── 3) Log history ──
        let _stfLogsCache = [];
        async function _loadStaffLogs() {
            const el = document.getElementById('stfLogs');
            if (!el) return;
            try {
                const thirtyDaysAgo = new Date();
                thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                let snap;
                try {
                    snap = await getDocs(query(collection(db, 'staffActivityLogs'), orderBy('timestamp', 'desc'), limit(150)));
                } catch (indexErr) {
                    snap = await getDocs(query(collection(db, 'staffActivityLogs'), limit(150)));
                }
                _stfLogsCache = snap.docs.map(d => ({ id: d.id, ...d.data() }))
                    .filter(l => { const t = l.timestamp?.toDate?.(); return t ? t >= thirtyDaysAgo : true; })
                    .sort((a, b) => (b.timestamp?.toMillis?.() || 0) - (a.timestamp?.toMillis?.() || 0));

                if (!_stfLogsCache.length) {
                    el.innerHTML = `<div class="us-empty"><div class="us-empty-ic">📋</div><h4>No activity yet</h4><p>Staff approve/reject করলে এখানে দেখাবে।</p></div>`;
                    return;
                }
                el.innerHTML = `<div class="stf-log-list">` + _stfLogsCache.map(l => {
                    const isApprove = l.action === 'approve';
                    const t = l.timestamp?.toDate?.();
                    const when = t ? t.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) : '—';
                    return `<div class="stf-log-row">
                      <span class="al-badge ${isApprove ? 'approve' : 'reject'}">${isApprove ? 'Approved' : 'Rejected'}</span>
                      <div class="al-main">
                        <div class="al-amount">₹${(Number(l.amount) || 0).toLocaleString('en-IN')}</div>
                        <div class="al-sub">${esc(l.userName || 'User')} · ${when}</div>
                        <div class="al-sub faint">by ${esc(l.staffEmail || '—')}</div>
                      </div>
                    </div>`;
                }).join('') + `</div>`;
            } catch (e) {
                console.error('_loadStaffLogs error:', e);
                el.innerHTML = `<div class="us-empty"><h4>Failed to load logs</h4><p>${esc(e.message)}</p></div>`;
            }
        }

        // Clear all loaded logs (admin-only — rules enforce)
        window.stfClearLogs = function() {
            if (!_stfLogsCache.length) { showToast('Nothing to clear', 'warning'); return; }
            showActionSheet('Clear Staff Logs?', `${_stfLogsCache.length}টি log entry মুছে যাবে। এই কাজ undo করা যাবে না।`, [{
                label: 'Clear Logs',
                style: 'destructive',
                action: async () => {
                    try {
                        const refs = _stfLogsCache.map(l => doc(db, 'staffActivityLogs', l.id));
                        for (let i = 0; i < refs.length; i += 400) {
                            const batch = writeBatch(db);
                            refs.slice(i, i + 400).forEach(r => batch.delete(r));
                            await batch.commit();
                        }
                        showToast('Staff logs cleared', 'success');
                        _loadStaffLogs();
                    } catch (e) {
                        console.error('stfClearLogs error:', e);
                        showToast('Failed: ' + e.message, 'error');
                    }
                }
            }]);
        };

        // ৩০ দিনের পুরনো log ডিলিট
        window.stfDeleteOldLogs = async function() {
            showActionSheet('Delete old logs?', '৩০ দিনের পুরনো সব staff log মুছে যাবে।', [{
                label: 'Delete Old Logs',
                style: 'destructive',
                action: async () => {
                    try {
                        const cutoff = new Date();
                        cutoff.setDate(cutoff.getDate() - 30);
                        const snap = await getDocs(query(collection(db, 'staffActivityLogs'), limit(500)));
                        const old = snap.docs.filter(d => {
                            const t = d.data().timestamp?.toDate?.();
                            return t && t < cutoff;
                        });
                        if (!old.length) { showToast('No logs older than 30 days', 'warning'); return; }
                        for (let i = 0; i < old.length; i += 400) {
                            const batch = writeBatch(db);
                            old.slice(i, i + 400).forEach(d => batch.delete(d.ref));
                            await batch.commit();
                        }
                        showToast(`${old.length} old logs deleted 🧹`, 'success');
                        _loadStaffLogs();
                    } catch (e) {
                        console.error('stfDeleteOldLogs error:', e);
                        showToast('Failed: ' + e.message, 'error');
                    }
                }
            }]);
        };
