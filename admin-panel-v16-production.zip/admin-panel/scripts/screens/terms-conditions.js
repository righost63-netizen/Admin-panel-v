// ── FIX 11: TC DELETE ──
        // ══════════════════════════════════════════
        // FIX 11 — T&C DELETE BUTTON
        // ══════════════════════════════════════════
        window.openTCModal = async function() {
            const d = await getDoc(doc(db, 'settings', 'termsAndConditions'));
            document.getElementById('tcEditor').value = d.exists() ? (d.data().content || '') : '';
            const upd = d.exists() && d.data().updatedAt?.toDate?.();
            document.getElementById('tcLastUpdated').textContent = upd ? 'Last updated: ' + formatDate(upd) : '';
            showFullModal('tcModal');
        };

        window.clearTerms = async function() {
            showActionSheet('Delete Terms & Conditions?', 'This will permanently remove all content. This cannot be undone.', [{
                label: 'Delete Permanently',
                style: 'destructive',
                action: async () => {
                    try {
                        await setDoc(doc(db, 'settings', 'termsAndConditions'), {
                            content: '',
                            updatedAt: serverTimestamp()
                        }, {
                            merge: true
                        });
                        await touchCache('terms');
                        document.getElementById('tcEditor').value = '';
                        document.getElementById('tcLastUpdated').textContent = 'Cleared just now';
                        showToast('Terms & Conditions cleared', 'success');
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };

        window.saveTandC = async function() {
            const content = document.getElementById('tcEditor').value;
            try {
                await setDoc(doc(db, 'settings', 'termsAndConditions'), {
                    content,
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });
                await touchCache('terms');
                document.getElementById('tcLastUpdated').textContent = 'Last updated: just now';
                showToast('Terms & Conditions saved!', 'success');
                closeModal('tcModal');
            } catch (e) {
                showToast(e.message, 'error');
            }
        };



