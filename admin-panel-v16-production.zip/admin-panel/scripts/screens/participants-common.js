// 📁 scripts/screens/participants-common.js
const PT_ICONS = {
    users:  '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20v-1a6 6 0 0 1 6-6h1a6 6 0 0 1 6 6v1"/><circle cx="17.5" cy="9" r="2.5"/><path d="M21.5 19v-.5a4.5 4.5 0 0 0-4-4.4"/></svg>',
    trophy: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 21h8M12 17v4M6 3h12l-1.5 9a4.5 4.5 0 0 1-9 0L6 3Z"/><path d="M6 7H4a2 2 0 0 0 0 4h2M18 7h2a2 2 0 0 1 0 4h-2"/></svg>',
    lock:   '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
    unlock: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 7.5-1.9"/></svg>',
    target: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".6"/></svg>',
    check:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
    x:      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    doc:    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h7l5 5v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg>'
};

// FIX (XSS): স্লট গ্রিডের onclick-এ আর টিমের নাম পাঠানো হয় না —
// শুধু team doc id যায়, নাম _slotMapCache থেকে দেখা হয়।
let _slotMapCache = {};

function ptCap(s) { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); }function ptEmptyHTML(title, sub) {
    return `<div class="pt-empty"><div class="pt-empty-ic">${PT_ICONS.users}</div><h4>${title}</h4><p>${sub}</p></div>`;
}
function plShowEmpty(el) {
    el.innerHTML = ptEmptyHTML('No tournaments yet', 'Create a tournament to start managing players.');
}

// টুর্নামেন্টটা পেইড কিনা — ফ্রী/পেইড আলাদা করার একমাত্র জায়গা
function isPaidTournament(t) {
    t = t || currentTournObj;
    return t?.entryType === 'paid' || t?.isPaid === true;
}

function plCardHTML(t) {
    const status = (t.status || 'upcoming').toLowerCase();
    const cls = status === 'upcoming' ? 'up' : (status === 'ongoing' || status === 'live') ? 'live' : (status === 'cancelled' || status === 'canceled') ? 'bad' : 'done';
    const filledTeams = t.filledTeams || t.filledSlots || 0;
    const maxTeams = t.maxTeams || t.totalSlots || 0;
    const filledPlayers = t.filledPlayers || (filledTeams * (t.playersPerTeam || 1));
    const maxPlayers = t.maxPlayers || (maxTeams * (t.playersPerTeam || 1));
    const pct = maxTeams ? Math.min(100, Math.round(filledTeams / maxTeams * 100)) : 0;
    return `<article class="pl-card">
      <div class="pl-top"><div class="pl-name">${esc(t.name)}</div><span class="pl-pill ${cls}"><i></i>${esc(ptCap(status))}</span></div>
      <div class="pl-chips"><span class="pl-chip">${esc(t.gameMode || 'BR')}</span><span class="pl-chip">${esc(ptCap(String(t.teamFormat || 'SOLO').toLowerCase()))}</span></div>
      <div class="pl-fill">
        <div class="pl-fill-row"><span><strong>${filledTeams}/${maxTeams}</strong> teams</span><span>${filledPlayers}/${maxPlayers} players</span></div>
        <div class="pl-bar"><i style="width:${pct}%"></i></div>
      </div>
      <div class="pl-actions">
        <button class="pl-btn pl-btn-main" onclick="openViewPlayers('${esc(t.id)}')">${PT_ICONS.users}Participants</button>
        <button class="pl-btn pl-btn-sub" onclick="plAct('results','${esc(t.id)}')">${PT_ICONS.trophy}Results</button>
      </div>
    </article>`;
}

window.plAct = function(kind, id) {
    const t = (window._plItems || []).find(x => x.id === id);
    if (kind === 'results') openUpdateResults(id, t ? (t.name || '') : '');
};
window.ptAct = function(kind, id) {
    const it = allParticipantsData.find(x => x.id === id);
    if (kind === 'slot') openRoomSlotSheet(id, it ? (it.teamName || '') : '');
};

let currentTournForParticipants = null;
let currentTournPaymentsMap = {};
let currentTournObj = null;
let allParticipantsData = [];
let participantSearchQuery = '';

// ✂️ মূল পরিবর্তন: Players & Results লিস্ট এখন Free/Paid দুই সেকশনে ভাগ হয়ে রেন্ডার হয়
// ✅ পারফরম্যান্স ফিক্স: আগে এখানে 'tournaments' collection-এর উপর নিজের আলাদা একটা
// onSnapshot() চলত (dashboard.js আর tournaments.js-ও একই collection-এ আলাদা আলাদা
// onSnapshot চালাতো — একই collection-এ ৩টা duplicate লাইভ listener)। এখন এখানে আলাদা
// listener নেই — tournaments.js (একমাত্র owner) window.allTournamentsCache আপডেট করার
// সময় window.tournamentsUpdateListeners array-এর প্রতিটা ফাংশনকে কল করবে; এখানে শুধু
// নিজের রেন্ডার-ফাংশন সেই array-তে রেজিস্টার করে রাখা হচ্ছে।
function renderPlayersScreenTournaments(items) {
    const el = document.getElementById('playersContent');
    if (!el) return;
    if (!items.length) { plShowEmpty(el); return; }
    const hdrTitle = document.querySelector('#screen-players [data-header-title]');
    if (hdrTitle && !hdrTitle.textContent.trim()) hdrTitle.textContent = 'Players & Results';
    window._plItems = items;

    const freeItems = items.filter(t => !isPaidTournament(t));
    const paidItems = items.filter(t => isPaidTournament(t));

    el.innerHTML =
        `<div class="pl-section-title">🆓 Free Tournaments</div>` +
        (freeItems.length ? '<div class="pl-list">' + freeItems.map(plCardHTML).join('') + '</div>' : ptEmptyHTML('No free tournaments', 'Free tournaments will show up here.')) +
        `<div class="pl-section-title">💰 Paid Tournaments</div>` +
        (paidItems.length ? '<div class="pl-list">' + paidItems.map(plCardHTML).join('') + '</div>' : ptEmptyHTML('No paid tournaments', 'Paid tournaments will show up here.'));
}

function loadPlayersScreen() {
    (window.tournamentsUpdateListeners = window.tournamentsUpdateListeners || []).push(renderPlayersScreenTournaments);

    // tournaments.js এখনো হুক কল করা শুরু না করা পর্যন্ত (বা ওই স্ক্রিন এখনো visit না হওয়া
    // পর্যন্ত) shared cache খালি থাকতে পারে — তখন একবারের জন্য one-time getDocs() (লাইভ
    // listener নয়) দিয়ে initial তালিকা দেখানো হচ্ছে, যাতে screen খালি না দেখায়।
    if (window.allTournamentsCache && window.allTournamentsCache.length) {
        renderPlayersScreenTournaments(window.allTournamentsCache);
    } else {
        getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'))).then(snap => {
            renderPlayersScreenTournaments(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        }).catch(e => console.error('players screen initial tournaments fetch failed:', e));
    }
}

window.openViewPlayers = async function(tid) {
    currentTournForParticipants = tid;
    participantSearchQuery = '';
    document.getElementById('participantSearchInput').value = '';
    document.getElementById('viewPlayersContent').innerHTML = '<div class="loading-page"><div class="spinner spinner-accent"></div></div>';
    showFullModal('viewPlayersModal');
    try {
        const tDoc = await getDoc(doc(db, 'tournaments', tid));
        if (!tDoc.exists()) { showToast('Tournament not found', 'error'); closeModal('viewPlayersModal'); return; }
        currentTournObj = { id: tDoc.id, ...tDoc.data() };
        document.getElementById('viewPlayersTitle').textContent = currentTournObj.name;
        await refreshParticipants();
    } catch (e) {
        console.error('openViewPlayers error:', e);
        showToast(e.message, 'error');
    }
};

window.refreshParticipants = async function() {
    if (!currentTournForParticipants) return;
    const contentEl = document.getElementById('viewPlayersContent');
    contentEl.innerHTML = '<div class="loading-page"><div class="spinner spinner-accent"></div></div>';
    try {
        const teamsSnap = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', currentTournForParticipants)));
        let list = teamsSnap.docs.map(d => ({ id: d.id, ...d.data() }));

        if (list.length === 0) {
            const legacySnap = await getDocs(query(collection(db, 'joinRequests'), where('tournamentId', '==', currentTournForParticipants)));
            list = legacySnap.docs.map(d => {
                const r = d.data();
                return {
                    id: d.id,
                    teamId: r.teamId || ('TEAM-' + d.id.substring(0, 6).toUpperCase()),
                    teamName: r.teamName || r.userName || 'Solo Participant',
                    teamFormat: currentTournObj?.teamFormat || 'SOLO',
                    captainUserId: r.userId || '',
                    players: r.players || [{ userId: r.userId || '', playerName: r.userName || 'Player', ffUID: r.ffUID || '—' }],
                    status: r.status === 'accepted' ? 'confirmed' : (r.status || 'pending'),
                    locked: r.locked || false,
                    roomSlot: r.roomSlot || null,
                    createdAt: r.submittedAt || r.createdAt
                };
            });
        }

        allParticipantsData = list;

        currentTournPaymentsMap = {};
        if (isPaidTournament()) {
            try {
                const paySnap = await getDocs(query(collection(db, 'paymentRequests'), where('tournamentId', '==', currentTournForParticipants)));
                paySnap.forEach(d => {
                    const p = d.data();
                    const key = p.teamId;
                    if (!key) return;
                    const existing = currentTournPaymentsMap[key];
                    const pTime = p.submittedAt?.toMillis ? p.submittedAt.toMillis() : 0;
                    const eTime = existing?.submittedAt?.toMillis ? existing.submittedAt.toMillis() : 0;
                    if (!existing || pTime >= eTime) currentTournPaymentsMap[key] = { id: d.id, ...p };
                });
            } catch (e) {
                console.warn('[Payments] Could not load payment requests for tournament:', e.message);
            }
        }

        updateParticipantsSummaryCounters();
        renderParticipantsList();
    } catch (e) {
        console.error('refreshParticipants error:', e);
        contentEl.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><div class="empty-title">Error</div><div class="empty-subtitle">${e.message}</div></div>`;
    }
};

function updateParticipantsSummaryCounters() {
    const totalTeams = allParticipantsData.length;
    const playersPerTeam = currentTournObj?.playersPerTeam || 1;
    const confirmed = allParticipantsData.filter(t => t.status === 'confirmed').length;
    const pending = allParticipantsData.filter(t => t.status === 'pending').length;
    const locked = allParticipantsData.filter(t => t.locked === true).length;
    const totalPlayers = allParticipantsData.reduce((acc, cur) => acc + (cur.players ? cur.players.length : playersPerTeam), 0);
    document.getElementById('cnt_teams').textContent = totalTeams;
    document.getElementById('cnt_players').textContent = totalPlayers;
    document.getElementById('cnt_confirmed').textContent = confirmed;
    document.getElementById('cnt_pending').textContent = pending;
    document.getElementById('cnt_locked').textContent = locked;
}

window.onSearchParticipants = function(val) {
    participantSearchQuery = val.trim().toLowerCase();
    renderParticipantsList();
};

// ✂️ ফ্রী/পেইড অনুযায়ী আলাদা কার্ড ফাংশন কল হচ্ছে
// ptCardHTMLFree() → participants-free.js , ptCardHTMLPaid() → participants-paid.js
function renderParticipantsList() {
    const contentEl = document.getElementById('viewPlayersContent');
    if (!contentEl) return;
    let filtered = allParticipantsData;
    if (participantSearchQuery) {
        filtered = allParticipantsData.filter(t => {
            const matchTeamName = (t.teamName || '').toLowerCase().includes(participantSearchQuery);
            const matchTeamId = (t.teamId || t.id).toLowerCase().includes(participantSearchQuery);
            const matchPlayer = (t.players || []).some(p =>
                (p.playerName || '').toLowerCase().includes(participantSearchQuery) ||
                (p.ffUID || '').toLowerCase().includes(participantSearchQuery) ||
                (p.userId || '').toLowerCase().includes(participantSearchQuery)
            );
            return matchTeamName || matchTeamId || matchPlayer;
        });
    }
    if (filtered.length === 0) {
        contentEl.innerHTML = ptEmptyHTML(participantSearchQuery ? 'No matching team' : 'No teams yet',
            participantSearchQuery ? 'Try a different team name, player or UID.' : 'Teams will show up here once players join.');
        return;
    }
    const cardFn = isPaidTournament() ? ptCardHTMLPaid : ptCardHTMLFree;
    contentEl.innerHTML = '<div class="pt-list">' + filtered.map(cardFn).join('') + '</div>';
}

window.toggleTeamLock = async function(docId, lockState) {
    const actionWord = lockState ? 'Lock' : 'Unlock';
    showActionSheet(`${actionWord} this Team?`, lockState ? 'Players cannot be modified once locked.' : 'Unlocking will allow team changes. Are you sure?', [{
        label: `${actionWord} Team`, style: lockState ? 'default' : 'destructive',
        action: async () => {
            try {
                const teamRef = doc(db, 'tournamentTeams', docId);
                const teamSnap = await getDoc(teamRef);
                const teamData = teamSnap.exists() ? teamSnap.data() : null;
                const updatePayload = { locked: lockState, lockedAt: lockState ? serverTimestamp() : null, lockedBy: lockState ? 'admin' : null, updatedAt: serverTimestamp() };
                await updateDoc(teamRef, updatePayload).catch(() => updateDoc(doc(db, 'joinRequests', docId), updatePayload));
                if (teamData && teamData.captainUserId) {
                    const notifMsg = lockState ? `Your team "${teamData.teamName}" has been LOCKED 🔒 by admin. Team details and roster are now finalized.` : `Your team "${teamData.teamName}" has been UNLOCKED 🔓 by admin.`;
                    addNotification(teamData.captainUserId, lockState ? 'Team Locked 🔒' : 'Team Unlocked 🔓', notifMsg, lockState ? 'info' : 'warning');
                }
                showToast(`Team ${lockState ? 'Locked 🔒' : 'Unlocked 🔓'} successfully!`, 'success');
                await refreshParticipants();
            } catch (e) { showToast('Error: ' + e.message, 'error'); }
        }
    }]);
};

window.toggleAllTeamsLock = async function(lockState) {
    if (!currentTournForParticipants || allParticipantsData.length === 0) { showToast('No participants to lock/unlock', 'warning'); return; }
    const actionWord = lockState ? 'Lock All' : 'Unlock All';
    showActionSheet(`${actionWord} Teams?`, `This will ${lockState ? 'LOCK 🔒' : 'UNLOCK 🔓'} all ${allParticipantsData.length} teams in this tournament.`, [{
        label: `${actionWord} Teams`, style: lockState ? 'default' : 'destructive',
        action: async () => {
            try {
                const batch = writeBatch(db);
                allParticipantsData.forEach(item => {
                    const tRef = doc(db, 'tournamentTeams', item.id);
                    batch.update(tRef, { locked: lockState, lockedAt: lockState ? serverTimestamp() : null, lockedBy: lockState ? 'admin' : null, updatedAt: serverTimestamp() });
                    if (item.captainUserId) {
                        const notifRef = doc(collection(db, 'users', item.captainUserId, 'notifications'));
                        batch.set(notifRef, {
                            title: lockState ? 'Team Locked 🔒' : 'Team Unlocked 🔓',
                            message: lockState ? `All teams in "${currentTournObj?.name || 'Tournament'}" have been finalized and locked.` : `Your team has been unlocked.`,
                            type: lockState ? 'info' : 'warning', read: false, createdAt: serverTimestamp()
                        });
                    }
                });
                await batch.commit();
                showToast(`All teams ${lockState ? 'locked 🔒' : 'unlocked 🔓'} successfully!`, 'success');
                await refreshParticipants();
            } catch (e) { showToast('Batch lock error: ' + e.message, 'error'); }
        }
    }]);
};

window.openRoomSlotSheet = function(docId, teamName) {
    document.getElementById('slotTargetTeamId').value = docId;
    document.getElementById('slotTargetTeamName').textContent = `Team: ${teamName}`;
    const maxSlots = currentTournObj?.maxTeams || currentTournObj?.totalSlots || 12;
    const grid = document.getElementById('slotGridContainer');
    const slotMap = {};
    allParticipantsData.forEach(t => {
        if (t.status === 'confirmed' && t.roomSlot && t.id !== docId) slotMap[t.roomSlot] = { teamId: t.id, teamName: t.teamName || 'Occupied' };
    });
    _slotMapCache = slotMap;
    const currentTeam = allParticipantsData.find(t => t.id === docId);
    const currentSlot = currentTeam?.roomSlot || null;
    let html = '';
    for (let i = 1; i <= maxSlots; i++) {
        const occupant = slotMap[i];
        const isOccupiedByOther = Boolean(occupant);
        const isCurrent = (currentSlot === i);
        html += `
            <button type="button" class="btn-sm" style="height:52px; border-radius:10px; font-size:12px; font-weight:700; flex-direction:column; gap:2px; padding:4px 2px;
                ${isCurrent ? 'background:var(--color-accent); color:var(--color-on-accent); box-shadow:0 0 10px var(--color-accent-glow);' : isOccupiedByOther ? 'background:rgba(255, 69, 58,0.15); color:var(--color-error); border:0.5px solid rgba(255, 69, 58,0.3);' : 'background:var(--color-bg-raised); color:var(--color-text-primary); border:0.5px solid var(--color-border);'}"
                onclick="onSlotButtonClick(${i}, '${isOccupiedByOther ? occupant.teamId : ''}')">
                <span>Slot ${String(i).padStart(2, '0')}</span>
                <span style="font-size:9px; font-weight:500; text-overflow:ellipsis; overflow:hidden; white-space:nowrap; max-width:70px;">${isCurrent ? 'SELECTED' : isOccupiedByOther ? esc(occupant.teamName) : 'Free'}</span>
            </button>`;
    }
    grid.innerHTML = html;
    showSheet('roomSlotSheet', 'roomSlotOverlay');
};

window.closeRoomSlotSheet = function() { hideSheet('roomSlotSheet', 'roomSlotOverlay'); };

window.onSlotButtonClick = function(slotNum, occupiedTeamId) {
    // FIX (XSS): onclick থেকে শুধু team doc id আসে; নাম ক্যাশ থেকে নেওয়া হয় —
    // প্লেয়ারের দেওয়া নাম আর কখনো JS-এ ঢোকে না।
    const occupant = occupiedTeamId ? _slotMapCache[slotNum] : null;
    const occupiedTeamName = occupant && occupant.teamId === occupiedTeamId ? occupant.teamName : '';
    if (occupiedTeamId && occupiedTeamName) {
        showActionSheet(`Reassign Slot ${slotNum}?`, `Slot ${slotNum} is currently assigned to "${occupiedTeamName}". Do you want to move it to this team?`, [{
            label: `Reassign to This Team`, style: 'destructive', action: async () => { await assignTeamSlot(slotNum, occupiedTeamId); }
        }]);
    } else {
        assignTeamSlot(slotNum, occupiedTeamId || null);
    }
};

window.assignTeamSlot = async function(slotNum, previousTeamIdToClear = null) {
    const docId = document.getElementById('slotTargetTeamId').value;
    if (!docId) return;
    try {
        const currentRef = doc(db, 'tournamentTeams', docId);
        const prevRef = previousTeamIdToClear ? doc(db, 'tournamentTeams', previousTeamIdToClear) : null;
        // FIX: স্লট দেওয়া মানেই টিম confirm নয় — শুধু roomSlot বসবে।
        // Confirm/Reject আলাদা বাটনেই থাকবে, যাতে টাকা না দেওয়া টিম ভুল করে ঢুকে না যায়।
        await runTransaction(db, async (transaction) => {
            const teamSnap = await transaction.get(currentRef);
            if (!teamSnap.exists()) throw new Error('Team not found!');
            if (prevRef) transaction.update(prevRef, { roomSlot: null, updatedAt: serverTimestamp() });
            transaction.update(currentRef, { roomSlot: slotNum, updatedAt: serverTimestamp() });
        });
        showToast(`Slot ${slotNum} assigned 🎯`, 'success');
        closeRoomSlotSheet();
        await refreshParticipants();
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
};

window.unassignTeamSlot = async function() {
    const docId = document.getElementById('slotTargetTeamId').value;
    if (!docId) return;
    try {
        await updateDoc(doc(db, 'tournamentTeams', docId), { roomSlot: null, updatedAt: serverTimestamp() });
        showToast('Slot removed', 'info');
        closeRoomSlotSheet();
        await refreshParticipants();
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
};