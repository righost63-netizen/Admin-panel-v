        // ══════════════════════════════════════════
        // ADMIN ACTIVITY LOG SCREEN
        // ══════════════════════════════════════════
        // Reads `adminActivityLogs` (admin-only). Filters: Today / Last 7 Days /
        // Last 30 Days — applied client-side so no composite index is needed.
        // Clear button: type-to-confirm, chunked delete. Auto-cleanup: entries
        // older than 30 days are deleted when the screen opens (Cloud Functions
        // isn't available, so this lazy cleanup runs in the admin panel).
        let _logCache = [];
        let _logFilter = 'today';
        let _logSearch = '';
        let _logShown = 50;
        const LOG_PAGE = 50;

        const LOG_ICONS = {
            create: '➕', update: '✏️', delete: '🗑️', login: '🔓', logout: '🔒',
            cancel: '🚫', approve: '✅', reject: '❌', publish: '📢', distribute: '💰',
            refund: '💸', mode: '🎮', banner: '🖼️', wallet: '💳', user: '👤',
            tournament: '🏆', room: '🚪', result: '📊', settings: '⚙️', notify: '🔔'
        };
        function logIconFor(action, module) {
            const a = String(action || '').toLowerCase();
            const m = String(module || '').toLowerCase();
            for (const k of Object.keys(LOG_ICONS)) {
                if (a.includes(k) || m.includes(k)) return LOG_ICONS[k];
            }
            return '📝';
        }
        function logModClass(module) {
            const m = String(module || '').toLowerCase();
            if (/delete|cancel|ban/.test(m)) return 'log-mod danger';
            if (/wallet|payout|prize|refund|payment/.test(m)) return 'log-mod money';
            return 'log-mod';
        }

        function logRangeStart(filter) {
            const now = new Date();
            const d = new Date(now.getFullYear(), now.getMonth(), now.getDate()); // local midnight
            if (filter === 'today') return d;
            if (filter === '7d') { d.setDate(d.getDate() - 6); return d; }
            d.setDate(d.getDate() - 29); // 30d
            return d;
        }

        function getFilteredLogs() {
            const start = logRangeStart(_logFilter);
            const q = _logSearch.trim().toLowerCase();
            return _logCache.filter(l => {
                const ts = l._date;
                if (!ts || ts < start) return false;
                if (q) {
                    const hay = `${l.action || ''} ${l.adminName || ''} ${l.adminEmail || ''} ${l.module || ''} ${l.details || ''}`.toLowerCase();
                    if (!hay.includes(q)) return false;
                }
                return true;
            });
        }

        function renderLogs() {
            const list = document.getElementById('logList');
            if (!list) return;
            const rows = getFilteredLogs();
            const badge = document.getElementById('logTotalBadge');
            if (badge) {
                badge.style.display = rows.length ? '' : 'none';
                badge.textContent = rows.length;
            }
            const moreWrap = document.getElementById('logMoreWrap');
            if (!rows.length) {
                list.innerHTML = `<div class="rs-empty"><div class="rs-empty-ic">📜</div><h4>No logs found</h4><p>${_logSearch ? 'Try a different search.' : 'No admin activity in this period yet.'}</p></div>`;
                if (moreWrap) moreWrap.style.display = 'none';
                return;
            }
            const shown = rows.slice(0, _logShown);
            list.innerHTML = shown.map(l => {
                const dt = l._date;
                const dateStr = dt ? dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
                const timeStr = dt ? dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—';
                return `<div class="log-item">
                    <div class="log-ic">${logIconFor(l.action, l.module)}</div>
                    <div class="log-main">
                        <div class="log-action">${esc(l.action || 'Action')}</div>
                        <div class="log-meta">${esc(l.adminName || 'Admin')}${l.adminEmail ? ' • ' + esc(l.adminEmail) : ''} • ${dateStr}, ${timeStr}</div>
                        ${l.details ? `<div class="log-detail">${esc(l.details)}</div>` : ''}
                    </div>
                    <span class="${logModClass(l.module)}">${esc(l.module || 'general')}</span>
                </div>`;
            }).join('');
            if (moreWrap) moreWrap.style.display = rows.length > _logShown ? '' : 'none';
        }

        window.setLogFilter = function(filter, btn) {
            _logFilter = filter;
            _logShown = LOG_PAGE;
            document.querySelectorAll('.log-chip').forEach(c => c.classList.remove('active'));
            if (btn) btn.classList.add('active');
            renderLogs();
        };

        window.onLogSearch = function(v) {
            _logSearch = v || '';
            _logShown = LOG_PAGE;
            renderLogs();
        };

        window.loadMoreLogs = function() {
            _logShown += LOG_PAGE;
            renderLogs();
        };

        // 30+ দিনের পুরনো লগ auto-delete (lazy cleanup — Cloud Functions নেই বলে)
        async function autoCleanupOldLogs() {
            try {
                const cutoff = new Date();
                cutoff.setDate(cutoff.getDate() - 30);
                const old = _logCache.filter(l => l._date && l._date < cutoff);
                if (!old.length) return;
                for (let i = 0; i < old.length; i += 450) {
                    const batch = writeBatch(db);
                    old.slice(i, i + 450).forEach(l => batch.delete(doc(db, 'adminActivityLogs', l.id)));
                    await batch.commit();
                }
                _logCache = _logCache.filter(l => !(l._date && l._date < cutoff));
            } catch (e) { console.warn('log auto-cleanup failed:', e.message); }
        }

        window.loadLogs = async function() {
            const list = document.getElementById('logList');
            if (list) list.innerHTML = `<div class="rs-skel"></div><div class="rs-skel"></div><div class="rs-skel"></div>`;
            try {
                // orderBy timestamp desc — single-field index auto-created by Firestore
                const snap = await getDocs(query(collection(db, 'adminActivityLogs'), orderBy('timestamp', 'desc'), limit(500)));
                _logCache = snap.docs.map(d => {
                    const data = d.data();
                    return { id: d.id, ...data, _date: tsToDate(data.timestamp) };
                });
                await autoCleanupOldLogs();
                renderLogs();
            } catch (e) {
                console.error('loadLogs error:', e);
                if (list) list.innerHTML = `<div class="rs-empty"><div class="rs-empty-ic">⚠️</div><h4>Failed to load logs</h4><p>${esc(e.message || '')}</p></div>`;
            }
        };

        // ── CLEAR ALL (type-to-confirm) ──
        window.confirmClearLogs = function() {
            openTypeConfirm({
                eyebrow: 'Danger zone',
                title: 'Clear All Activity Logs?',
                target: 'All admin activity logs',
                desc: 'This will <b>permanently delete every log entry</b> from the app and the database. This cannot be undone.',
                expect: 'CLEAR',
                confirmLabel: 'Clear All Logs',
                onConfirm: async () => {
                    // 500+ হলে loop করে সব মুছবে
                    let total = 0;
                    do {
                        const q = query(collection(db, 'adminActivityLogs'), orderBy('timestamp', 'desc'), limit(450));
                        const s = await getDocs(q);
                        if (s.empty) break;
                        const batch = writeBatch(db);
                        s.forEach(d => batch.delete(d.ref));
                        await batch.commit();
                        total += s.size;
                        if (s.size < 450) break;
                    } while (true);
                    _logCache = [];
                    renderLogs();
                    showToast(`Cleared ${total} log entries 🗑️`, 'success');
                }
            });
        };
