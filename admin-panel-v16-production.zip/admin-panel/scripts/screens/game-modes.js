        // ══════════════════════════════════════════
        // GAME MODES
        // ══════════════════════════════════════════
        const EMOJIS = ['🎮', '⚔️', '🏹', '💣', '🔫', '🛡️', '🏃', '🚁', '🚗', '💥', '🎯', '🌟', '🔥', '⚡', '🦁', '🐉', '🥊', '🏆', '👑', '🎲', '🗡️', '🧨', '🌪️', '💀'];

        // FIX (apostrophe): onclick থেকে আর JSON পাঠানো হয় না — শুধু doc id, ডাটা _modeCache থেকে।
        let _modeCache = [];

        function renderEmojiGrid() {
            document.getElementById('emojiGrid').innerHTML = EMOJIS.map(e => `<button class="emoji-btn ${e===selectedEmoji?'selected':''}" onclick="selectEmoji('${e}',this)">${e}</button>`).join('');
        }

        window.selectEmoji = function(e, btn) {
            selectedEmoji = e;
            document.querySelectorAll('.emoji-btn').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
            document.getElementById('ms_customEmoji').value = '';
        };

        function loadModes() {
            const el = document.getElementById('modesContent');
            const u = onSnapshot(query(collection(db, 'gameModes'), limit(200)), snap => {   // ✅ [নতুন] soft-cap: বেশি বাড়লেও একসাথে ২০০-র বেশি ডকুমেন্ট শুনবে না
                if (snap.empty) {
                    const badge0 = document.getElementById('modeCountBadge');
                    if (badge0) badge0.style.display = 'none';
                    el.innerHTML = `<div class="empty-state">
                        <div class="empty-icon">🎮</div>
                        <div class="empty-title">No Game Modes</div>
                        <div class="empty-subtitle">Create your first game mode — tournaments will use these.</div>
                        <button class="btn-primary empty-cta" onclick="openModeSheet(null)">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" style="width:18px;height:18px;"><path d="M12 5v14M5 12h14"/></svg>
                          <span>Add Game Mode</span>
                        </button>
                      </div>`;
                    return;
                }
                const items = snap.docs.map(d => ({
                    id: d.id,
                    ...d.data()
                }));
                _modeCache = items;
                const badge = document.getElementById('modeCountBadge');
                if (badge) { badge.style.display = ''; badge.textContent = items.length; }
                el.innerHTML = `<div class="mode-list">${items.map(m=>`
      <div class="mode-item">
        <div class="mode-icon-wrap">${m.icon||'🎮'}</div>
        <div class="mode-name">${esc(m.name)}</div>
        <span class="badge ${m.isActive!==false?'badge-active':'badge-rejected'}">${m.isActive!==false?'Active':'Off'}</span>
        <div class="mode-actions">
          <button class="icon-btn icon-btn-edit" onclick="openModeSheet('${m.id}')">✏️</button>
          <button class="icon-btn icon-btn-delete" onclick="deleteMode('${m.id}')">🗑️</button>
        </div>
      </div>`).join('')}</div>`;
            });
            listeners.push(u);
        }

        window.openModeSheet = function(mode) {
            // FIX: এখন শুধু id আসে (আগে JSON object আসত) — ক্যাশ থেকে ডাটা নাও।
            if (typeof mode === 'string') mode = (_modeCache || []).find(x => x.id === mode) || { id: mode };
            editingModeId = mode?.id || null;
            selectedEmoji = mode?.icon || '🎮';
            document.getElementById('modeSheetTitle').textContent = mode ? 'Edit Game Mode' : 'Add Game Mode';
            document.getElementById('ms_name').value = mode?.name || '';
            document.getElementById('ms_active').checked = mode?.isActive !== false;
            document.getElementById('ms_customEmoji').value = '';
            renderEmojiGrid();
            showSheet('modeSheet', 'modeSheetOverlay');
        };

        window.closeModeSheet = function() {
            hideSheet('modeSheet', 'modeSheetOverlay');
        };

        window.saveMode = async function() {
            const name = document.getElementById('ms_name').value.trim();
            if (!name) {
                showToast('Enter mode name', 'warning');
                return;
            }
            const custom = document.getElementById('ms_customEmoji').value.trim();
            const icon = custom || selectedEmoji;
            const btn = document.getElementById('saveModeBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
            try {
                const data = {
                    name,
                    icon,
                    isActive: document.getElementById('ms_active').checked,
                    // FIX: এডিটে createdAt ওভাররাইট হতো — শুধু নতুন মোডে বসবে
                    ...(editingModeId ? {} : { createdAt: serverTimestamp() })
                };
                if (editingModeId) await updateDoc(doc(db, 'gameModes', editingModeId), data);
                else await addDoc(collection(db, 'gameModes'), data);
                await touchCache('gameModes');
                closeModeSheet();
                showToast('Game mode saved!', 'success');
            } catch (e) {
                showToast(e.message, 'error');
            }
            btn.disabled = false;
            btn.textContent = 'Save Mode';
        };

        window.deleteMode = function(id) {
            showActionSheet('Delete Game Mode', 'This will remove the mode permanently.', [{
                label: 'Delete Mode',
                style: 'destructive',
                action: async () => {
                    try {
                        await deleteDoc(doc(db, 'gameModes', id));
                        await touchCache('gameModes');
                        showToast('Mode deleted', 'success');
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };



