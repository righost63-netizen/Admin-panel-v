// 📁 scripts/screens/participants-paid.js
function ptCardHTMLPaid(item) {
    const teamId = item.teamId || item.id;
    const status = (item.status || 'pending').toLowerCase();
    const isLocked = item.locked === true;
    const isConfirmed = status === 'confirmed' || status === 'approved';
    const isRejected = status === 'rejected';
    const pcls = isConfirmed ? 'ok' : isRejected ? 'bad' : status === 'pending' ? 'wait' : 'neutral';
    const players = item.players || [];
    const payment = currentTournPaymentsMap[teamId];

    const rows = players.map((p, idx) => `<div class="pt-player">
        <span class="pt-pav">${esc((p.playerName || 'P').trim().charAt(0).toUpperCase() || 'P')}</span>
        <div class="pt-pmain"><div class="pt-pname">${esc(p.playerName || 'Player')}${(idx === 0 && players.length > 1) ? '<span class="pt-cap">Captain</span>' : ''}</div>
        <div class="pt-puid">UID ${esc(p.ffUID || '—')}</div></div>
        <span class="pt-pid">${esc((p.userId || '').substring(0, 8))}</span></div>`).join('');

    const okBtn = () => isConfirmed
        ? `<button class="pt-btn done-ok" disabled>${PT_ICONS.check}Confirmed</button>`
        : `<button class="pt-btn pt-btn-ok" onclick="confirmPaidParticipant('${item.id}')">${PT_ICONS.check}Confirm</button>`;
    const badBtn = () => isRejected
        ? `<button class="pt-btn done-bad" disabled>${PT_ICONS.x}Rejected</button>`
        : `<button class="pt-btn pt-btn-bad" onclick="rejectPaidParticipant('${item.id}')">${PT_ICONS.x}Reject</button>`;

    let action;
    if (!payment) {
        action = `<div class="pt-note">Waiting for the player to submit payment details (UTR / Txn ID).</div>
        <div class="pt-acts one">${badBtn()}</div>`;
    } else {
        const isChecked = payment.adminChecked === true;
        action = `<label class="pt-verify"><input type="checkbox" ${isChecked || isConfirmed ? 'checked' : ''} ${isConfirmed || isRejected ? 'disabled' : ''} onchange="togglePaymentCheck('${payment.id}', this.checked)">Payment verified</label>
        <div class="pt-acts">${okBtn()}${badBtn()}</div>
        <button class="pt-btn pt-btn-line" onclick="viewPaymentDetails('${payment.id}')">${PT_ICONS.doc}View payment details</button>`;
    }

    return `<article class="pt-card">
      <div class="pt-top">
        <div><div class="pt-team">${esc(item.teamName || 'Solo Player')}</div><div class="pt-tid">${esc(teamId)}</div></div>
        <span class="pt-pill ${pcls}"><i></i>${esc(ptCap(status))}</span>
      </div>
      <span class="pt-lock ${isLocked ? 'on' : ''}">${isLocked ? PT_ICONS.lock + 'Locked' : PT_ICONS.unlock + 'Open'}</span>
      <div class="pt-players">${rows}</div>
      <div class="pt-slot">
        <span class="pt-slot-tag ${item.roomSlot ? 'has' : ''}">${PT_ICONS.target}${item.roomSlot ? 'Slot ' + String(item.roomSlot).padStart(2, '0') : 'No slot'}</span>
        <div class="pt-slot-btns">
          <button class="pt-mini" onclick="ptAct('slot','${item.id}')">Slot</button>
          <button class="pt-mini ${isLocked ? 'warn' : ''}" onclick="toggleTeamLock('${item.id}', ${!isLocked})">${isLocked ? PT_ICONS.unlock + 'Unlock' : PT_ICONS.lock + 'Lock'}</button>
        </div>
      </div>
      ${action}
    </article>`;
}

window.togglePaymentCheck = async function(paymentDocId, checked) {
    try {
        await updateDoc(doc(db, 'paymentRequests', paymentDocId), { adminChecked: checked, adminCheckedAt: serverTimestamp() });
        if (currentTournPaymentsMap) Object.values(currentTournPaymentsMap).forEach(p => { if (p.id === paymentDocId) p.adminChecked = checked; });
        showToast(checked ? 'Payment marked as verified ✅' : 'Payment verification removed', 'info');
        renderParticipantsList();
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
};

window.viewPaymentDetails = function(paymentDocId) {
    const payment = Object.values(currentTournPaymentsMap).find(p => p.id === paymentDocId);
    if (!payment) { showToast('Payment details not found', 'error'); return; }
    const subDate = tsToDate(payment.submittedAt);
    const dateStr = subDate ? subDate.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
    const timeStr = subDate ? subDate.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—';
    showActionSheet('💳 Payment Details', '', [{ label: 'Close', style: 'default', action: () => {} }]);
    document.getElementById('asSubtitle').innerHTML = `
        <div style="text-align:left; font-size:13px; line-height:1.9;">
            <div><strong>Team:</strong> ${esc(payment.teamName || '—')}</div>
            <div><strong>Player:</strong> ${esc(payment.userName || '—')} (${esc(payment.userEmail || '—')})</div>
            <div><strong>Date:</strong> ${dateStr}</div>
            <div><strong>Time:</strong> ${timeStr}</div>
            <div><strong>Amount:</strong> ₹${payment.amount || payment.entryFee || 0}</div>
            <div><strong>Transaction / UTR ID:</strong> <span style="font-family:var(--font-mono); color:var(--color-accent);">${esc(payment.transactionId || 'NOT PROVIDED')}</span></div>
            <div><strong>Method:</strong> ${esc(payment.paymentMethod || 'UPI')}</div>
            <div><strong>Status:</strong> ${esc(payment.status || 'pending').toUpperCase()}</div>
        </div>`;
};

// ── হেল্পার: docId আগে tournamentTeams-এ খোঁজে, না পেলে legacy joinRequests-এ ──
// (এটা না থাকাই ছিল "Confirm/Reject ক্লিকে কিছু না হওয়া" বাগের আসল কারণ)
async function ptResolveParticipantRef(docId) {
    let ref = doc(db, 'tournamentTeams', docId);
    let snap = await getDoc(ref);
    if (snap.exists()) return { ref, snap, legacy: false };

    ref = doc(db, 'joinRequests', docId);
    snap = await getDoc(ref);
    if (snap.exists()) return { ref, snap, legacy: true };

    return null;
}

window.confirmPaidParticipant = async function(docId) {
    showToast('Confirming...', 'info');
    const resolved = await ptResolveParticipantRef(docId);
    if (!resolved) { showToast('Participant record not found (removed or outdated)', 'error'); return; }
    const { ref: teamRef, snap: teamSnap, legacy } = resolved;
    const teamData = teamSnap.data();
    const teamKey = teamData.teamId || docId;
    const payment = currentTournPaymentsMap[teamKey];

    if (!payment) { showToast('No payment request found for this team!', 'warning'); return; }
    if (!payment.transactionId) { showToast('Cannot confirm payment without Transaction ID!', 'warning'); return; }

    try {
        const tournId = teamData.tournamentId || currentTournForParticipants;
        const captainId = teamData.captainUserId || teamData.userId;
        const tourRef = tournId ? doc(db, 'tournaments', tournId) : null;
        const payRef = doc(db, 'paymentRequests', payment.id);
        const userRef = captainId ? doc(db, 'users', captainId) : null;
        const lockRef = captainId && tournId ? doc(db, 'tournamentCaptains', `${tournId}_${captainId}`) : null;
        // usedTransactions collection-এ UTR/Transaction ID রেজিস্টার করা হচ্ছে,
        // যাতে একই Transaction ID দুইবার ব্যবহার করা না যায়।
        const txnDocRef = doc(db, 'usedTransactions', payment.transactionId.toUpperCase());

        await runTransaction(db, async (transaction) => {
            // Firestore transaction থেকে fresh টিম ডাটা read করা হচ্ছে (race-condition ফিক্স)
            // আগে বাইরের stale teamData থেকে oldStatus নেওয়া হতো, যার ফলে দুইজন admin
            // একসাথে confirm করলে দুজনেই পুরোনো 'pending' status দেখে duplicate slot বাড়িয়ে ফেলতো।
            const freshTeamSnap = await transaction.get(teamRef);
            if (!freshTeamSnap.exists()) throw new Error('Team record no longer exists!');
            const freshTeamData = freshTeamSnap.data();
            const oldStatus = (freshTeamData.status || 'pending').toLowerCase();

            if (oldStatus === 'confirmed' || oldStatus === 'accepted') {
                // অন্য কোনো admin/device ইতিমধ্যে confirm করে ফেলেছে — duplicate confirm আটকানো হলো
                throw new Error('ALREADY_CONFIRMED');
            }

            // Transaction ID (UTR) ডুপ্লিকেট চেক — usedTransactions-এ আগে ব্যবহার হয়েছে কিনা দেখা হচ্ছে
            const txnSnap = await transaction.get(txnDocRef);
            if (txnSnap.exists()) {
                throw new Error(`Transaction ID (${payment.transactionId}) is already used for another payment!`);
            }

            if (oldStatus !== 'confirmed' && oldStatus !== 'accepted' && tourRef) {
                const tourSnap = await transaction.get(tourRef);
                if (tourSnap.exists()) {
                    const tData = tourSnap.data();
                    const filled = Number(tData.filledTeams || tData.filledSlots || 0);
                    const maxTeams = Number(tData.maxTeams || tData.totalSlots || 0);
                    if (maxTeams > 0 && filled >= maxTeams) throw new Error('Tournament is already full! Cannot confirm.');
                    const newFilled = filled + 1;
                    // ✅ FIX: ইউজার অ্যাপ পেইড জয়েনে pendingTeams +1 করে সিট রিজার্ভ করে।
                    // Confirm-এ সেটা ছেড়ে দিতে হবে, নইলে টুর্নামেন্ট ভুল করে FULL দেখাবে।
                    const pending = Number(tData.pendingTeams || 0);
                    const newPending = Math.max(0, pending - 1);
                    transaction.update(tourRef, { filledTeams: newFilled, filledSlots: newFilled, filledPlayers: newFilled * (tData.playersPerTeam || 1), pendingTeams: newPending });
                }
            }

            transaction.set(txnDocRef, {
                transactionId: payment.transactionId.toUpperCase(),
                paymentId: payment.id,
                tournamentId: tournId || '',
                teamId: teamKey || '',
                userId: captainId || '',
                approvedAt: serverTimestamp()
            });

            transaction.update(teamRef, {
                status: 'confirmed',
                paymentStatus: 'approved',
                updatedAt: serverTimestamp()
            });

            transaction.update(payRef, { status: 'approved', adminChecked: true, reviewedAt: serverTimestamp(), reviewedBy: 'admin' });
            if (userRef) transaction.update(userRef, { joinedTournaments: arrayUnion(tournId) });
            if (lockRef) transaction.update(lockRef, { status: 'confirmed' });
            // ✅ FIX: প্লেয়ার UID লকগুলো confirmed মার্ক করা হচ্ছে, যাতে পরে
            // reject হলে 'rejected' সেট করে ছেড়ে দেওয়া যায়।
            (freshTeamData.players || []).forEach(p => {
                const ffUID = String(p?.ffUID || '').trim();
                if (ffUID && tournId) {
                    transaction.set(
                        doc(db, 'tournamentPlayerUIDs', `${tournId}_${ffUID}`),
                        { status: 'confirmed', teamId: teamKey, updatedAt: serverTimestamp() },
                        { merge: true }
                    );
                }
            });
        });

        if (captainId) notifyUserWithPush(captainId, 'Payment Verified & Confirmed! ✅', `Your registration for "${currentTournObj?.name || 'the tournament'}" is confirmed!`, 'success');
        showToast('Team Confirmed successfully!', 'success');
        await refreshParticipants();
    } catch (e) {
        console.error('confirmPaidParticipant error:', e);
        if (e.message === 'ALREADY_CONFIRMED') {
            showToast('এই টিম ইতিমধ্যে অন্য কেউ Confirm করে ফেলেছে!', 'warning');
            await refreshParticipants();
            return;
        }
        if (e.message.includes('is already used')) {
            showActionSheet('⚠️ Duplicate Transaction!', e.message, [{
                label: 'Close',
                style: 'destructive',
                action: () => {}
            }]);
            return;
        }
        showToast('Error: ' + e.message, 'error');
    }
};

window.rejectPaidParticipant = async function(docId) {
    const resolved = await ptResolveParticipantRef(docId);
    if (!resolved) { showToast('Participant record not found (removed or outdated)', 'error'); return; }
    const { ref: teamRef, snap: teamSnap } = resolved;
    const teamData = teamSnap.data();
    const teamKey = teamData.teamId || docId;
    const payment = currentTournPaymentsMap[teamKey];

    showActionSheet('Reject this Player?', `This will reject "${teamData.teamName || 'this team'}". You will need to refund them manually.`, [{
        label: 'Reject & Notify', style: 'destructive',
        action: async () => {
            try {
                const tournId = teamData.tournamentId || currentTournForParticipants;
                const captainId = teamData.captainUserId || teamData.userId;
                const tourRef = tournId ? doc(db, 'tournaments', tournId) : null;
                const userRef = captainId ? doc(db, 'users', captainId) : null;
                const lockRef = captainId && tournId ? doc(db, 'tournamentCaptains', `${tournId}_${captainId}`) : null;

                await runTransaction(db, async (transaction) => {
                    // fresh read, transaction-এর বাইরের stale teamData ব্যবহার না করে (race-condition ফিক্স)
                    const freshTeamSnap = await transaction.get(teamRef);
                    if (!freshTeamSnap.exists()) throw new Error('Team record no longer exists!');
                    const freshTeamData = freshTeamSnap.data();
                    const oldStatus = (freshTeamData.status || 'pending').toLowerCase();
                    if (oldStatus === 'rejected') throw new Error('ALREADY_REJECTED');

                    if ((oldStatus === 'confirmed' || oldStatus === 'accepted') && tourRef) {
                        const tourSnap = await transaction.get(tourRef);
                        if (tourSnap.exists()) {
                            const tData = tourSnap.data();
                            const filled = Number(tData.filledTeams || tData.filledSlots || 0);
                            const newFilled = Math.max(0, filled - 1);
                            transaction.update(tourRef, { filledTeams: newFilled, filledSlots: newFilled, filledPlayers: newFilled * (tData.playersPerTeam || 1) });
                        }
                    }

                    // ✅ FIX: pending অবস্থায় reject হলে রিজার্ভ করা সিট ছেড়ে দিতে হবে
                    // (ইউজার অ্যাপ পেইড জয়েনে pendingTeams +1 করে)।
                    if (oldStatus !== 'confirmed' && oldStatus !== 'accepted' && tourRef) {
                        const tourSnap = await transaction.get(tourRef);
                        if (tourSnap.exists()) {
                            const tData = tourSnap.data();
                            const pending = Number(tData.pendingTeams || 0);
                            transaction.update(tourRef, { pendingTeams: Math.max(0, pending - 1) });
                        }
                    }

                    // ✅ FIX: প্লেয়ার UID লকগুলো 'rejected' করা হচ্ছে, যাতে এই FF UID
                    // দিয়ে আবার একই টুর্নামেন্টে রেজিস্ট্রেশন করা যায়।
                    (freshTeamData.players || []).forEach(p => {
                        const ffUID = String(p?.ffUID || '').trim();
                        if (ffUID && tournId) {
                            transaction.set(
                                doc(db, 'tournamentPlayerUIDs', `${tournId}_${ffUID}`),
                                { status: 'rejected', teamId: teamKey, updatedAt: serverTimestamp() },
                                { merge: true }
                            );
                        }
                    });

                    transaction.update(teamRef, {
                        status: 'rejected',
                        paymentStatus: 'rejected',
                        updatedAt: serverTimestamp()
                    });

                    if (payment) {
                        transaction.update(doc(db, 'paymentRequests', payment.id), {
                            status: 'rejected',
                            rejectionReason: 'ভুল তথ্যের কারণে বাতিল।',
                            reviewedAt: serverTimestamp(),
                            reviewedBy: 'admin'
                        });
                    }

                    if (userRef) transaction.update(userRef, { joinedTournaments: arrayRemove(tournId) });
                    if (lockRef) transaction.update(lockRef, { status: 'rejected' });
                });

                if (captainId) notifyUserWithPush(captainId, 'Registration Rejected ❌', 'তোমার ভুল তথ্যের কারণে তোমাকে রিজেক্ট করা হয়েছে। তোমার টাকা অ্যাডমিন ম্যানুয়ালি রিফান্ড করে দেবে।', 'warning');
                showToast('Player rejected successfully.', 'success');
                await refreshParticipants();
            } catch (e) {
                console.error('rejectPaidParticipant error:', e);
                if (e.message === 'ALREADY_REJECTED') {
                    showToast('এই টিম ইতিমধ্যে reject করা হয়ে গেছে!', 'warning');
                    await refreshParticipants();
                    return;
                }
                showToast('Error: ' + e.message, 'error');
            }
        }
    }]);
};