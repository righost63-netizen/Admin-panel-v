        // ╔══════════════════════════════════════════════════════════════════════╗
        // ║ ফাইল: scripts/screens/wallet.js  (পুরো ফাইলটাই রিপ্লেস করা যাবে)        ║
        // ║ শুধু অংশ পেস্ট করতে চাইলে নিচের ✅ চিহ্নিত ৫টা ব্লক খুঁজে বদলান:          ║
        // ║   ০) এই আইকন ব্লক  → ফাইলের একদম উপরে নতুন যোগ                          ║
        // ║   ১) loadWallet()             → পুরোটা রিপ্লেস                          ║
        // ║   ২) setWalletFilter + filterWithdrawals → রিপ্লেস + নতুন সার্চ টাইমার    ║
        // ║   ৩) fetchWithdrawals এর ভেতরে ২টা লাইন বদল (৩-ক, ৩-খ)                  ║
        // ║   ৪) renderWithdrawals() থেকে ফাইলের শেষ পর্যন্ত → রিপ্লেস                ║
        // ║ approveWithdrawal / rejectWithdrawal / saveMinWithdraw অপরিবর্তিত।        ║
        // ╚══════════════════════════════════════════════════════════════════════╝

        // ✅ [ওয়ালেট রিডিজাইন ০] শুরু — আইকন (Index.html এর sprite এ হাত দিতে হবে না)
        const WL_ICONS = {
            search: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
            copy:   '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="3"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>',
            check:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
            x:      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
            inbox:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 13l3-8h12l3 8v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Z"/><path d="M3 13h5l1 3h6l1-3h5"/></svg>'
        };
        // ✅ [ওয়ালেট রিডিজাইন ০] শেষ

        // ══════════════════════════════════════════
        // WALLET
        // ══════════════════════════════════════════
        let walletFilter = 'pending';
        let allWithdrawals = [];

        // ╔══════════════════════════════════════════════════════════════╗
        // ║ ✅ [ওয়ালেট রিডিজাইন ১] শুরু — পুরনো loadWallet() এর জায়গায়      ║
        // ╚══════════════════════════════════════════════════════════════╝
        function loadWallet() {
            const el = document.getElementById('walletContent');

            // হেডারের টাইটেল ফাঁকা থাকলে ভরে দেয় (স্ক্রিনশটে টাইটেল আসেনি)
            const hdrTitle = document.querySelector('#screen-wallet [data-header-title]');
            if (hdrTitle && !hdrTitle.textContent.trim()) hdrTitle.textContent = 'Wallet Management';

            // ট্যাবে ফিরে এলে ইনপুট ফাঁকা হয়, তাই পুরনো সার্চ/মেথড ফিল্টারও রিসেট
            withdrawSearchQuery = '';
            withdrawMethodQuery = 'all';

            el.innerHTML = `
    <div class="wl">

      <!-- ১) হিরো: Minimum Withdrawal -->
      <section class="wl-hero">
        <div class="wl-hero-top">
          <div class="wl-hero-label">Minimum withdrawal</div>
          <span class="wl-chip" id="minWithdrawCurrent">Loading...</span>
        </div>
        <div class="wl-field">
          <div class="wl-input-wrap">
            <span>₹</span>
            <input class="wl-input" type="number" inputmode="numeric" id="minWithdrawInput" placeholder="100" aria-label="Minimum withdrawal amount">
          </div>
          <button class="wl-save" onclick="saveMinWithdraw()">Save</button>
        </div>
        <div class="wl-hero-hint">Players can't request less than this amount.</div>
      </section>

      <!-- ২) সার্চ + মেথড -->
      <div class="wl-tools">
        <label class="wl-search">
          ${WL_ICONS.search}
          <input type="text" id="withdrawSearch" placeholder="Search name or UID" oninput="walletSearchTyped()" autocomplete="off" aria-label="Search by name or UID">
        </label>
        <select class="wl-select" id="withdrawMethodFilter" onchange="filterWithdrawals()" aria-label="Payment method">
          <option value="all">All</option>
          <option value="upi">UPI</option>
        </select>
      </div>

      <!-- ৩) স্ট্যাটাস সেগমেন্ট -->
      <div class="wl-seg" role="tablist">
        ${['pending', 'approved', 'rejected'].map(f => `<button role="tab" data-f="${f}" class="${walletFilter === f ? 'active' : ''}" onclick="setWalletFilter('${f}')"><i></i>${f.charAt(0).toUpperCase() + f.slice(1)}</button>`).join('')}
      </div>

      <!-- ৪) লিস্ট হেডিং + কাউন্ট -->
      <div class="wl-sec">
        <h3 id="wlTitle">${walletFilter.charAt(0).toUpperCase() + walletFilter.slice(1)} requests</h3>
        <span class="wl-count" id="wlCount" hidden>0</span>
      </div>

      <!-- ৫) রিকোয়েস্ট কার্ড (fetchWithdrawals এখানে বসায়) -->
      <div id="withdrawList">${walletSkeletonHTML()}</div>
      <div id="loadMoreWithdrawContainer"></div>
    </div>`;

            // লোড মিনিমাম অ্যামাউন্ট (আগের মতোই)
            getDoc(doc(db, 'settings', 'withdrawal')).then(d => {
                const el2 = document.getElementById('minWithdrawInput');
                const el3 = document.getElementById('minWithdrawCurrent');
                if (el2 && d.exists()) {
                    el2.value = d.data().minAmount || '';
                    if (el3) el3.textContent = `Current: ₹${d.data().minAmount||0}`;
                } else if (el3) el3.textContent = 'Not set';
            });

            fetchWithdrawals(false);
        }
        // ✅ [ওয়ালেট রিডিজাইন ১] শেষ

        // ✅ [ওয়ালেট রিডিজাইন ২] শুরু — setWalletFilter + filterWithdrawals এর জায়গায়
        window.setWalletFilter = function(f) {
            walletFilter = f;
            document.querySelectorAll('#walletContent .wl-seg button').forEach(b => {
                b.classList.toggle('active', b.dataset.f === f);
            });
            walletSetCount(null);            // নতুন ট্যাবের ডেটা আসা পর্যন্ত কাউন্ট লুকানো
            fetchWithdrawals(false);
        };

        window.filterWithdrawals = function() {
            withdrawMethodQuery = document.getElementById('withdrawMethodFilter').value.toLowerCase();
            // আগের বাগ ফিক্স: সার্চ lowercase না হওয়ায় "Rahul" লিখলে কিছু মিলত না
            withdrawSearchQuery = document.getElementById('withdrawSearch').value.trim().toLowerCase();
            fetchWithdrawals(false);
        };

        // প্রতিটা অক্ষরে Firestore এ রিড না করে, টাইপ থামলে (০.৪ সেকেন্ড পর) সার্চ করবে
        let _walletSearchTimer = null;
        window.walletSearchTyped = function() {
            clearTimeout(_walletSearchTimer);
            _walletSearchTimer = setTimeout(() => filterWithdrawals(), 400);
        };
        // ✅ [ওয়ালেট রিডিজাইন ২] শেষ

        window.fetchWithdrawals = async function(isLoadMore = false) {
            if (isWithdrawLoading) return;
            isWithdrawLoading = true;

            const elList = document.getElementById('withdrawList');
            if (!isLoadMore) {
                elList.innerHTML = walletSkeletonHTML();   // ✅ [ওয়ালেট রিডিজাইন ৩-ক] আগে এখানে spinner ছিল
                lastVisibleWithdrawDoc = null;
                allWithdrawals = [];
            } else {
                const btn = document.getElementById('loadMoreWithdrawBtn');
                if (btn) btn.innerHTML = '<div class="spinner spinner-accent" style="width:16px; height:16px; margin:auto;"></div>';
            }

            try {
                let snap;
                try {
                    // প্রথমে orderBy সহ চেষ্টা করব
                    let q = query(
                        collection(db, 'withdrawalRequests'),
                        where('status', '==', walletFilter),
                        orderBy('requestedAt', 'desc')
                    );
                    if (isLoadMore && lastVisibleWithdrawDoc) {
                        q = query(q, startAfter(lastVisibleWithdrawDoc), limit(15));
                    } else {
                        q = query(q, limit(15));
                    }
                    snap = await getDocs(q);
                } catch (indexErr) {
                    // Composite index না থাকলে orderBy ছাড়া চেষ্টা
                    console.warn('Withdrawal index missing, fallback query:', indexErr);
                    // FIX: Load More-এ startAfter না থাকায় প্রথম ১৫টাই বারবার আসত (ডুপ্লিকেট কার্ড)
                    let q2 = query(
                        collection(db, 'withdrawalRequests'),
                        where('status', '==', walletFilter),
                        limit(15)
                    );
                    if (isLoadMore && lastVisibleWithdrawDoc) {
                        q2 = query(
                            collection(db, 'withdrawalRequests'),
                            where('status', '==', walletFilter),
                            startAfter(lastVisibleWithdrawDoc),
                            limit(15)
                        );
                    }
                    snap = await getDocs(q2);
                }
                if (snap.empty && !isLoadMore) {
                    walletShowEmpty(elList);   // ✅ [ওয়ালেট রিডিজাইন ৩-খ] আগে এখানে 💰 empty-state ছিল
                    document.getElementById('loadMoreWithdrawContainer').innerHTML = '';
                    isWithdrawLoading = false;
                    return;
                }

                const chunk = snap.docs.map(d => ({
                    id: d.id,
                    ...d.data()
                }));
                lastVisibleWithdrawDoc = snap.docs[snap.docs.length - 1];

                if (isLoadMore) {
                    allWithdrawals = [...allWithdrawals, ...chunk];
                } else {
                    allWithdrawals = chunk;
                }

                let displayed = allWithdrawals;
                if (withdrawMethodQuery !== 'all') {
                    displayed = displayed.filter(w => (w.method || '').toLowerCase().includes(withdrawMethodQuery));
                }
                if (withdrawSearchQuery) {
                    displayed = displayed.filter(w =>
                        (w.userName || '').toLowerCase().includes(withdrawSearchQuery) ||
                        (w.ffUid || w.ffUID || '').toLowerCase().includes(withdrawSearchQuery)
                    );
                }

                renderWithdrawals(displayed);

                const loadMoreContainer = document.getElementById('loadMoreWithdrawContainer');
                if (snap.docs.length < 15) {
                    loadMoreContainer.innerHTML = '';
                } else {
                    loadMoreContainer.innerHTML = `<button class="btn-secondary" id="loadMoreWithdrawBtn" onclick="fetchWithdrawals(true)" style="width:100%; height:44px;">Load More</button>`;
                }
            } catch (e) {
                console.error('fetchWithdrawals error:', e);
                showToast('Failed to load withdrawals: ' + e.message, 'error');
            }
            isWithdrawLoading = false;
        };


        window.saveMinWithdraw = async function() {
            const val = parseFloat(document.getElementById('minWithdrawInput').value) || 0;
            // FIX: নেগেটিভ min withdrawal সেভ করা যাবে না
            if (val < 0) {
                showToast('Minimum withdrawal cannot be negative', 'warning');
                return;
            }
            try {
                await setDoc(doc(db, 'settings', 'withdrawal'), {
                    minAmount: val
                }, {
                    merge: true
                });
                showToast('Minimum withdrawal updated', 'success');
                document.getElementById('minWithdrawCurrent').textContent = `Current: ₹${val}`;
            } catch (e) {
                showToast(e.message, 'error');
            }
        };


// ── NEW MONEY FLOW (matches Staff Panel v2 + User App v2) ──
        // ══════════════════════════════════════════════════════════════
        // ✅ APPROVE: deduct `amount` from wallet atomically + ledger entry.
        //    Admin pays the user MANUALLY after approving.
        // ✅ REJECT: status → 'rejected' ONLY. No refund, no ledger entry —
        //    nothing was ever deducted at request time.
        // ══════════════════════════════════════════════════════════════
        window.approveWithdrawal = function(id, userId, amount, userName) {
            showActionSheet('Approve Withdrawal', `Approve ₹${amount} for ${userName}?\nAmount will be DEDUCTED from the user's wallet now — pay them manually afterwards.`, [{
                label: 'Approve & Deduct',
                style: 'default',
                action: async () => {
                    try {
                        let deducted = 0;
                        // FIX (race): reject হওয়া request আবার approve করা যাবে না —
                        // transaction-এ fresh status চেক করা হলো।
                        await runTransaction(db, async (transaction) => {
                            const wRef = doc(db, 'withdrawalRequests', id);
                            const wSnap = await transaction.get(wRef);
                            if (!wSnap.exists()) throw new Error('Withdrawal request not found!');
                            const st = (wSnap.data().status || 'pending').toLowerCase();
                            if (st === 'approved') throw new Error('ALREADY_APPROVED');
                            if (st === 'rejected') throw new Error('ALREADY_REJECTED');
                            // Amount server doc থেকে নেওয়া হচ্ছে — client param বিশ্বাস করা হচ্ছে না
                            const amt = Number(wSnap.data().amount) || 0;
                            if (amt <= 0) throw new Error('Invalid withdrawal amount.');
                            if (!userId) throw new Error('Missing user for this request.');
                            const uRef = doc(db, 'users', userId);
                            const uSnap = await transaction.get(uRef);
                            if (!uSnap.exists()) throw new Error('User not found.');
                            const bal = Number(uSnap.data().walletBalance) || 0;
                            if (bal < amt) throw new Error('INSUFFICIENT_BALANCE');
                            deducted = amt;
                            transaction.update(wRef, {
                                status: 'approved',
                                resolvedAt: serverTimestamp()
                            });
                            transaction.update(uRef, { walletBalance: increment(-amt) });
                            // Idempotent ledger entry — double-tap can't double-deduct
                            transaction.set(doc(db, 'walletTransactions', `withdraw_${id}`), {
                                userId: userId,
                                type: 'withdrawal',
                                title: 'Withdrawal Approved',
                                description: 'Deducted on admin approval — paid manually by admin',
                                withdrawalRequestId: id,
                                amount: -amt,
                                status: 'completed',
                                createdAt: serverTimestamp()
                            });
                        });

                        if (userId) {
                            await notifyUserWithPush(userId, '✅ Withdrawal Approved', `Your withdrawal of ₹${deducted} has been approved and deducted from your wallet. Payment will be sent to you manually shortly.`, 'success');
                        }
                        showToast('Withdrawal approved & deducted! ✅', 'success');
                        if (window.logAdminAction) logAdminAction('Approve withdrawal', 'wallet', `${userName || userId} — ₹${deducted}`);
                        fetchWithdrawals(false);
                    } catch (e) {
                        if (e.message === 'ALREADY_APPROVED') { showToast('Already approved.', 'warning'); fetchWithdrawals(false); return; }
                        if (e.message === 'ALREADY_REJECTED') { showToast('Already rejected — cannot approve now.', 'warning'); fetchWithdrawals(false); return; }
                        if (e.message === 'INSUFFICIENT_BALANCE') { showToast('User wallet balance is lower than the requested amount.', 'error'); return; }
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };

        window.rejectWithdrawal = function(id, userId, amount, userName) {
            showActionSheet('Reject Withdrawal?', `Reject withdrawal of ₹${amount} for ${userName}?\nNo money will move — nothing was deducted at request time.`, [{
                label: 'Reject',
                style: 'destructive',
                action: async () => {
                    try {
                        // NEW MONEY FLOW: রিকোয়েস্টের সময় টাকা কাটা হয়নি, তাই reject মানে
                        // শুধু status বদলানো। কোনো refund বা ledger entry হবে না।
                        const withdrawRef = doc(db, 'withdrawalRequests', id);

                        await runTransaction(db, async (transaction) => {
                            // fresh স্ট্যাটাস চেক — ইতিমধ্যে reject/approve হয়ে থাকলে retry হবে না
                            const wSnap = await transaction.get(withdrawRef);
                            if (!wSnap.exists()) throw new Error('Withdrawal request not found!');
                            const wStatus = (wSnap.data().status || 'pending').toLowerCase();
                            if (wStatus === 'rejected') throw new Error('ALREADY_REJECTED');
                            if (wStatus === 'approved') throw new Error('This withdrawal is already approved. Cannot reject now.');

                            transaction.update(withdrawRef, {
                                status: 'rejected',
                                resolvedAt: serverTimestamp()
                            });
                        });

                        if (userId) {
                            await notifyUserWithPush(userId, '❌ Withdrawal Rejected', `Your withdrawal request of ₹${amount} was rejected. No money was deducted — your wallet balance is unchanged.`, 'warning');
                        }

                        showToast('Withdrawal rejected.', 'info');
                        if (window.logAdminAction) logAdminAction('Reject withdrawal', 'wallet', `${userName || userId} — ₹${amount}`);
                        fetchWithdrawals(false);
                    } catch (e) {
                        if (e.message === 'ALREADY_REJECTED') {
                            showToast('This withdrawal was already rejected.', 'warning');
                            fetchWithdrawals(false);
                            return;
                        }
                        console.error('rejectWithdrawal error:', e);
                        showToast('Error: ' + e.message, 'error');
                    }
                }
            }]);
        };


// ╔══════════════════════════════════════════════════════════════╗
        // ║ ✅ [ওয়ালেট রিডিজাইন ৪] শুরু — renderWithdrawals() এর জায়গায়      ║
        // ║ (পুরনো "FIX 13: WALLET FF UID" কমেন্ট থেকে ফাইলের শেষ পর্যন্ত)      ║
        // ╚══════════════════════════════════════════════════════════════╝
        function renderWithdrawals(list) {
            const el = document.getElementById('withdrawList');
            if (!el) return;
            if (!list || list.length === 0) {
                walletShowEmpty(el);
                return;
            }
            walletSetCount(list.length);
            el.innerHTML = '<div class="wl-list">' + list.map(walletCardHTML).join('') + '</div>';
        }

        // একটা রিকোয়েস্ট কার্ড
        function walletCardHTML(w) {
            const status = (w.status === 'approved' || w.status === 'rejected') ? w.status : 'pending';
            const reqAt = w.requestedAt?.toDate?.();
            const doneAt = w.resolvedAt?.toDate?.();
            const name = w.userName || 'Unknown';
            const ffUid = w.ffUid || w.ffUID || '';
            const rawMethod = String(w.method || '—');
            const method = rawMethod.length <= 4 ? rawMethod.toUpperCase() : rawMethod;   // upi → UPI
            const payTo = String(w.phoneNumber || '').trim();
            const amount = (Number(w.amount) || 0).toLocaleString('en-IN');

            return `<article class="wl-card">
      <div class="wl-card-top">
        <div>
          <div class="wl-amount"><small>₹</small>${amount}</div>
          <div class="wl-when">${reqAt ? 'Requested ' + walletFmt(reqAt) : 'Request time unavailable'}</div>
        </div>
        <span class="wl-pill ${status}"><i></i>${status}</span>
      </div>

      <div class="wl-user">
        <div class="wl-avatar">${esc(name.trim().charAt(0).toUpperCase() || '?')}</div>
        <div class="wl-user-main">
          <div class="wl-name">${esc(name)}</div>
          <div class="wl-uid">${ffUid ? 'FF UID ' + esc(ffUid) : 'No FF UID'}</div>
        </div>
        ${ffUid ? `<button class="wl-copy" data-copy="${esc(ffUid)}" onclick="walletCopy(this)" aria-label="Copy FF UID">${WL_ICONS.copy}</button>` : ''}
      </div>

      <div class="wl-pay">
        <span class="wl-method">${esc(method)}</span>
        <span class="wl-pay-num">${esc(payTo || '—')}</span>
        ${payTo ? `<button class="wl-copy" data-copy="${esc(payTo)}" onclick="walletCopy(this)" aria-label="Copy payment number">${WL_ICONS.copy}</button>` : ''}
      </div>

      ${status === 'pending'
        ? `<div class="wl-actions">
        <button class="wl-btn wl-btn-reject" onclick="walletAct('reject','${esc(w.id)}')">${WL_ICONS.x}Reject</button>
        <button class="wl-btn wl-btn-approve" onclick="walletAct('approve','${esc(w.id)}')">${WL_ICONS.check}Approve</button>
      </div>`
        : `<div class="wl-foot">${status === 'approved' ? 'Approved' : 'Rejected'}${doneAt ? ' on ' + walletFmt(doneAt) : ''}</div>`}
    </article>`;
        }

        // Approve/Reject: এখন শুধু id পাঠানো হয়, নাম/টাকা allWithdrawals থেকে নেয়
        // (আগের বাগ ফিক্স: O'Neil এর মতো নামে একটা ' থাকলে onclick ভেঙে যেত)
        window.walletAct = function(kind, id) {
            const w = allWithdrawals.find(x => x.id === id);
            if (!w) { showToast('Request not found. Pull to reload the list.', 'error'); return; }
            const args = [w.id, w.userId || '', Number(w.amount) || 0, w.userName || ''];
            if (kind === 'approve') approveWithdrawal(...args);
            else rejectWithdrawal(...args);
        };

        // UPI / ফোন নম্বর / FF UID কপি (ক্লিপবোর্ড ব্লক থাকলে fallback আছে)
        window.walletCopy = function(btn) {
            const text = btn.dataset.copy || '';
            const done = () => {
                btn.classList.add('done');
                btn.innerHTML = WL_ICONS.check;
                setTimeout(() => { btn.classList.remove('done'); btn.innerHTML = WL_ICONS.copy; }, 1400);
            };
            const fallback = () => {
                const t = document.createElement('textarea');
                t.value = text;
                t.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
                document.body.appendChild(t);
                t.select();
                try { document.execCommand('copy') ? done() : showToast('Copy failed', 'error'); }
                catch (e) { showToast('Copy failed', 'error'); }
                t.remove();
            };
            if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(done).catch(fallback);
            else fallback();
        };

        // ── ছোট হেল্পার ──
        function walletFmt(d) {
            const opts = { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true };
            if (d.getFullYear() !== new Date().getFullYear()) opts.year = 'numeric';
            return d.toLocaleString('en-IN', opts);
        }

        // লিস্ট হেডিং আর কাউন্ট চিপ (n = null হলে কাউন্ট লুকায়)
        function walletSetCount(n) {
            const t = document.getElementById('wlTitle');
            const c = document.getElementById('wlCount');
            if (t) t.textContent = walletFilter.charAt(0).toUpperCase() + walletFilter.slice(1) + ' requests';
            if (c) { c.hidden = (n === null); c.textContent = n === null ? '' : n; }
        }

        function walletSkeletonHTML() {
            return '<div class="wl-list"><div class="wl-skel"></div><div class="wl-skel"></div></div>';
        }

        // খালি অবস্থা: কেন খালি সেটা বলে দেয়
        function walletShowEmpty(el) {
            walletSetCount(0);
            const filtering = !!withdrawSearchQuery || (withdrawMethodQuery && withdrawMethodQuery !== 'all');
            let title, sub;
            if (filtering) {
                title = 'No matching requests';
                sub = 'Try a different name, UID or method.';
            } else if (walletFilter === 'pending') {
                title = 'No pending requests';
                sub = 'New requests will show up here.';
            } else {
                title = 'No ' + walletFilter + ' requests';
                sub = 'Requests you ' + (walletFilter === 'approved' ? 'approve' : 'reject') + ' will be listed here.';
            }
            el.innerHTML = `<div class="wl-empty"><div class="wl-empty-ic">${WL_ICONS.inbox}</div><h4>${title}</h4><p>${sub}</p></div>`;
        }
        // ✅ [ওয়ালেট রিডিজাইন ৪] শেষ
