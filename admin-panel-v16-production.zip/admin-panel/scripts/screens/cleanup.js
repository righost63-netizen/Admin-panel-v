// ── DATABASE CLEANUP 30+ DAYS ──
        // ══════════════════════════════════════════
        // DATABASE CLEANUP — 30+ DAYS OLD DATA
        // ══════════════════════════════════════════
        // FIX: ক্লিনআপে কোনো কনফার্মেশন ছিল না — একটা ট্যাপেই ৩০ দিনের পুরনো
        // রেকর্ড (আর্থিক হিসাবসহ) মুছে যেত। এখন আগে কনফার্ম চাওয়া হয়।
        window.confirmCleanup = function(colName, dateField, statusField, statusValues, btnId, label) {
            showActionSheet('Delete old records?', `This will PERMANENTLY delete ${label || colName} older than 30 days. This cannot be undone.`, [{
                label: 'Yes, Delete Permanently',
                style: 'destructive',
                action: async () => { await runCleanup(colName, dateField, statusField, statusValues, btnId); }
            }]);
        };
        window.runCleanup = async function(colName, dateField, statusField, statusValues, btnId) {
            const btn = document.getElementById(btnId);
            const originalText = btn ? btn.textContent : 'Clean';
            if (btn) {
                btn.disabled = true;
                btn.textContent = 'ক্লিন হচ্ছে...';
            }

            try {
                // 30 days cutoff
                const cutoff = new Date();
                cutoff.setDate(cutoff.getDate() - 30);
                const cutoffTimestamp = Timestamp.fromDate(cutoff);

                // FIX: when a statusField is given, filter it server-side too (where 'in'),
                // instead of pulling the entire 30+ day date range and discarding most of it
                // client-side. This needs a Firestore composite index (range + 'in'); if the
                // index isn't there yet, Firestore will throw and we fall back to the old
                // full-read + client-side filter so the feature never breaks.
                let q;
                let usedServerSideStatusFilter = false;
                if (dateField && statusField && Array.isArray(statusValues) && statusValues.length > 0 && statusValues.length <= 10) {
                    q = query(collection(db, colName), where(dateField, '<', cutoffTimestamp), where(statusField, 'in', statusValues));
                    usedServerSideStatusFilter = true;
                } else if (dateField) {
                    q = query(collection(db, colName), where(dateField, '<', cutoffTimestamp));
                } else {
                    q = query(collection(db, colName));
                }

                let snap;
                try {
                    snap = await getDocs(q);
                } catch (indexErr) {
                    if (usedServerSideStatusFilter) {
                        console.warn('runCleanup: compound query failed (likely missing Firestore index), falling back to full read:', indexErr);
                        usedServerSideStatusFilter = false;
                        q = query(collection(db, colName), where(dateField, '<', cutoffTimestamp));
                        snap = await getDocs(q);
                    } else {
                        throw indexErr;
                    }
                }
                if (snap.empty) {
                    showToast('ডিলিট করার মতো কোনো পুরোনো ডাটা পাওয়া যায়নি।', 'info');
                    return;
                }

                let docsToDelete = [];
                snap.docs.forEach(docSnap => {
                    if (usedServerSideStatusFilter) {
                        // Already filtered by the Firestore query itself
                        docsToDelete.push(docSnap.ref);
                        return;
                    }
                    const data = docSnap.data();
                    if (statusField && statusValues && Array.isArray(statusValues)) {
                        if (statusValues.includes(data[statusField])) {
                            docsToDelete.push(docSnap.ref);
                        }
                    } else {
                        docsToDelete.push(docSnap.ref);
                    }
                });

                if (docsToDelete.length === 0) {
                    showToast('ডিলিট করার মতো কোনো পুরোনো ডাটা পাওয়া যায়নি।', 'info');
                    return;
                }

                // Batch delete in chunks of 450
                const CHUNK_SIZE = 450;
                let deletedCount = 0;
                for (let i = 0; i < docsToDelete.length; i += CHUNK_SIZE) {
                    const chunk = docsToDelete.slice(i, i + CHUNK_SIZE);
                    const batch = writeBatch(db);
                    chunk.forEach(ref => batch.delete(ref));
                    await batch.commit();
                    deletedCount += chunk.length;
                    if (btn) btn.textContent = `ডিলিট হচ্ছে... ${deletedCount}/${docsToDelete.length}`;
                }

                showToast(`সফলভাবে ${deletedCount}টি পুরোনো ডাটা মুছে ফেলা হয়েছে! 🗑️`, 'success');
            } catch (e) {
                console.error('runCleanup error:', e);
                showToast('ক্লিনআপ ব্যর্থ হয়েছে: ' + (e.message || e), 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = originalText;
                }
            }
        };

        // REMOVED: sendNotificationFromAdmin() was dead code — not wired to any button,
        // and it looked up form fields by placeholder text (e.g. input[placeholder="Title"]),
        // which breaks silently the moment anyone edits that placeholder wording.
        // Sending notifications is already handled by window.sendNotification() in
        // notifications.js via sendOneSignalPush().



