// ── PAYMENT GATEWAY & UPI SETTINGS ──
        // ══════════════════════════════════════════════════════════════
        // PAYMENT GATEWAY & UPI SETTINGS LOGIC (5 REQUIREMENTS)
        // ══════════════════════════════════════════════════════════════
        window.openPaymentSettingsSheet = async function() {
            // ইনপুট রিসেট
            document.getElementById('ps_upi_id').value = '';
            document.getElementById('ps_payee_name').value = '';
            document.getElementById('ps_upi_number').value = '';
            document.getElementById('ps_instructions').value = '';

            try {
                const snap = await getDoc(doc(db, 'settings', 'payment'));
                if (snap.exists()) {
                    const data = snap.data();
                    document.getElementById('ps_upi_id').value = data.upiId || data.number || '';
                    document.getElementById('ps_payee_name').value = data.payeeName || data.accountName || '';
                    document.getElementById('ps_upi_number').value = data.upiNumber || '';
                    document.getElementById('ps_instructions').value = data.instructions || data.notice || '';
                }
            } catch (e) {
                console.error('[PaymentSettings] Fetch error:', e);
            }

            updatePaymentLivePreview();
            showSheet('paymentSettingsSheet', 'paymentSettingsOverlay');
        };

        window.closePaymentSettingsSheet = function() {
            hideSheet('paymentSettingsSheet', 'paymentSettingsOverlay');
        };

        // কুইক হ্যান্ডেল যোগ করার ফাংশন (@okaxis, @paytm ইত্যাদি)
        window.appendUpiHandle = function(handle) {
            const input = document.getElementById('ps_upi_id');
            let current = input.value.trim();
            if (current.includes('@')) {
                current = current.split('@')[0];
            }
            input.value = (current || 'admin') + handle;
            updatePaymentLivePreview();
        };

        // লাইভ প্রিভিউ কার্ড আপডেট (QR ছাড়া — শুধু UPI ডিটেইলস)
        window.updatePaymentLivePreview = function() {
            const upiId = document.getElementById('ps_upi_id')?.value.trim() || 'admin@upi';
            const payeeName = document.getElementById('ps_payee_name')?.value.trim() || 'Tournament Admin';
            const upiNumber = document.getElementById('ps_upi_number')?.value.trim();

            const nameEl = document.getElementById('ps_preview_name');
            const upiEl = document.getElementById('ps_preview_upi');
            const numEl = document.getElementById('ps_preview_number');

            if (nameEl) nameEl.textContent = payeeName;
            if (upiEl) upiEl.textContent = upiId;
            if (numEl) numEl.textContent = upiNumber ? `📱 UPI Number: ${upiNumber}` : 'No UPI Number set';

            // ✅ Gateway status pill (display-only — save logic unchanged)
            const stEl = document.getElementById('ps_gateway_status');
            if (stEl) {
                const configured = upiId.includes('@') && upiId !== 'admin@upi';
                stEl.className = 'ps-status-pill' + (configured ? ' is-live' : ' is-off');
                stEl.textContent = configured ? '● Gateway Live' : '○ Not Configured';
            }
        };

        // ৫টি তথ্য ডাটাবেসে সেভ করা
        window.savePaymentSettings = async function() {
            const upiId = document.getElementById('ps_upi_id').value.trim();
            const payeeName = document.getElementById('ps_payee_name').value.trim();
            const upiNumber = document.getElementById('ps_upi_number').value.trim();
            const instructions = document.getElementById('ps_instructions').value.trim();

            if (!upiId) {
                showToast('Please enter your primary UPI ID', 'warning');
                document.getElementById('ps_upi_id').focus();
                return;
            }

            if (!upiId.includes('@')) {
                showToast('Invalid UPI ID! Must include "@" (e.g. name@okaxis)', 'error');
                document.getElementById('ps_upi_id').focus();
                return;
            }

            if (!payeeName) {
                showToast('Please enter Payee / Business Name', 'warning');
                document.getElementById('ps_payee_name').focus();
                return;
            }

            const btn = document.getElementById('savePaymentSettingsBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div> Saving...';

            try {
                const payload = {
                    upiId: upiId,
                    number: upiId, // Backward compatibility
                    payeeName: payeeName,
                    accountName: payeeName, // Backward compatibility
                    upiNumber: upiNumber,
                    instructions: instructions,
                    notice: instructions, // Backward compatibility
                    updatedAt: serverTimestamp()
                };

                // ফায়ারস্টোরে সেটিংস ডকুমেন্টে সেভ করা
                await setDoc(doc(db, 'settings', 'payment'), payload, {
                    merge: true
                });

                // ইউজার অ্যাপ ক্যাশ ক্লিয়ার ট্র্যাকিং
                await touchCache('payment');

                showToast('Payment settings saved successfully! 💳', 'success');
                closePaymentSettingsSheet();
            } catch (e) {
                console.error('savePaymentSettings error:', e);
                showToast('Failed to save settings: ' + e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.textContent = '💾 Save Payment Gateway Settings';
            }
        };


