        // ══════════════════════════════════════════
        // SETTINGS
        // ══════════════════════════════════════════
        function loadSettings() {
            document.getElementById('settingsContent').innerHTML = `
    <div class="spacer"></div>
    <div class="section-label">Content</div>
    <div class="settings-group">
      <div class="settings-row" onclick="showScreen('banners')">
        <div class="settings-icon" style="background:rgba(255, 107, 0,0.15);">🖼️</div>
        <div class="settings-text"><div class="settings-title-text">Banner Management</div><div class="settings-subtitle">Manage promo banners</div></div>
        <span class="settings-arrow">›</span>
      </div>
      <div class="settings-row" onclick="showScreen('modes')">
        <div class="settings-icon" style="background:rgba(10, 132, 255,0.15);">🎮</div>
        <div class="settings-text"><div class="settings-title-text">Game Modes</div><div class="settings-subtitle">Manage game modes</div></div>
        <span class="settings-arrow">›</span>
      </div>
    </div>

<div class="section-label">Notifications</div>
    <div class="settings-group">
      <div class="settings-row" onclick="showScreen('notifications')">
        <div class="settings-icon" style="background:rgba(255, 45, 85,0.15);">🔔</div>
        <div class="settings-text"><div class="settings-title-text">Notification Logs</div><div class="settings-subtitle">View sent notifications history</div></div>
        <span class="settings-arrow">›</span>
      </div>
      <div class="settings-row" onclick="openReminderSheet()">
        <div class="settings-icon" style="background:rgba(255, 152, 0,0.15);">⏰</div>
        <div class="settings-text"><div class="settings-title-text">Tournament Reminder</div><div class="settings-subtitle">Player দের ম্যানুয়ালি reminder পাঠান</div></div>
        <span class="settings-arrow">›</span>
      </div>
      <div class="settings-row" onclick="publishLeaderboard()">
        <div class="settings-icon" style="background:rgba(255, 193, 7,0.15);">🏆</div>
        <div class="settings-text"><div class="settings-title-text">Publish Leaderboard</div><div class="settings-subtitle" id="lbPublishSub">Top 50 players by total earnings</div></div>
        <span class="settings-arrow">›</span>
      </div>
    </div>

<div class="section-label">Payment Gateway</div>
    <div class="settings-group">
      <div class="settings-row" onclick="openPaymentSettingsSheet()">
        <div class="settings-icon" style="background:rgba(59, 130, 246,0.15);color:var(--color-accent);">💳</div>
        <div class="settings-text">
          <div class="settings-title-text">UPI & Payment Settings</div>
          <div class="settings-subtitle">Configure UPI ID, QR, Payee & Notice</div>
        </div>
        <span class="settings-arrow">›</span>
      </div>
    </div>

    <div class="section-label">Legal & Support</div>
    <div class="settings-group">
      <div class="settings-row" onclick="openTCModal()">
        <div class="settings-icon" style="background:rgba(59, 130, 246,0.15);">📄</div>
        <div class="settings-text"><div class="settings-title-text">Terms & Conditions</div><div class="settings-subtitle">Edit T&C content</div></div>
        <span class="settings-arrow">›</span>
      </div>
      <div class="settings-row" onclick="openHelpSettings()">
        <div class="settings-icon" style="background:rgba(0, 132, 255,0.15);">💬</div>
        <div class="settings-text"><div class="settings-title-text">Help & Support</div><div class="settings-subtitle">Manage support contacts</div></div>
        <span class="settings-arrow">›</span>
      </div>
    </div>

<div class="section-label">OneSignal</div>
<div class="settings-group">
<div class="settings-row" onclick="openOneSignalSettings()">
        <div class="settings-icon" style="background:rgba(255, 45, 85,0.15);">🔐</div>
        <div class="settings-text"><div class="settings-title-text">OneSignal API Key</div><div class="settings-subtitle">Manage Push Notification Key</div></div>
        <span class="settings-arrow">›</span>
      </div>
      </div>

<div class="section-label">Maintenance</div>
    <div class="settings-group">
      <div class="settings-row" onclick="openMaintenanceSheet()">
        <div class="settings-icon" style="background:rgba(255, 152, 0,0.15);">⚙️</div>
        <div class="settings-text"><div class="settings-title-text">Database Cleanup</div><div class="settings-subtitle">রিমুভ করুন পুরনো বা ফালতু হিস্ট্রি</div></div>
        <span class="settings-arrow">›</span>
      </div>
    </div>

    <div class="section-label">Account</div>
    <div class="settings-group">
      <div class="settings-row" onclick="switchTab('users')">
        <div class="settings-icon" style="background:rgba(255, 107, 0,0.15);">👥</div>
        <div class="settings-text"><div class="settings-title-text">User Management</div><div class="settings-subtitle">Manage all players</div></div>
        <span class="settings-arrow">›</span>
      </div>
</div>
          <div style="text-align:center;padding:24px;font-size:12px;color:var(--text-tertiary);">FF Admin Panel v8.0</div>

    <div class="settings-danger-zone">
      <div class="settings-danger-divider"></div>
      <button class="settings-logout-btn" onclick="doLogout()">
        <svg class="ic"><use href="#i-logout"/></svg><span>Logout</span>
      </button>
    </div>
  `;
            // Leaderboard-এর শেষ publish time দেখাও (1 read, page load-এ একবার)
            if (typeof refreshLeaderboardPublishInfo === 'function') refreshLeaderboardPublishInfo();
        }






        // ══════════════════════════════════════════
        // 🏆 PUBLISH LEADERBOARD (2026-10-07)
        // User app v6.1 leaderboard/current ডক পড়ে (1 read/view) — এই বাটন
        // সেটাই publish করে। Rule: firestore-rules v10.1-এ leaderboard public-read
        // + admin-write আছে — console-এ v10.1 deploy করা থাকতে হবে।
        // totalPlayers = totalEarnings > 0 আছে এমন users (count query)।
        // ══════════════════════════════════════════
        window.refreshLeaderboardPublishInfo = async function() {
            const sub = document.getElementById('lbPublishSub');
            if (!sub) return;
            try {
                const s = await getDoc(doc(db, 'leaderboard', 'current'));
                if (s.exists() && s.data().updatedAt) {
                    const raw = s.data().updatedAt;
                    const t = (raw && typeof raw.toDate === 'function') ? raw.toDate() : new Date(raw);
                    sub.textContent = 'Last published: ' + t.toLocaleString('en-IN', {
                        timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short',
                        hour: '2-digit', minute: '2-digit'
                    });
                } else {
                    sub.textContent = 'Not published yet — top 50 by earnings';
                }
            } catch (e) { /* subtitle default-ই থাকবে */ }
        };

        window.publishLeaderboard = async function() {
            if (window._lbPublishing) return;
            window._lbPublishing = true;
            const sub = document.getElementById('lbPublishSub');
            const prevSub = sub ? sub.textContent : '';
            if (sub) sub.textContent = 'Publishing…';
            try {
                // 1) Top 50 by totalEarnings
                const snap = await getDocs(query(collection(db, 'users'), orderBy('totalEarnings', 'desc'), limit(50)));
                const rows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                // 2) Tie-break: সমান totalEarnings হলে নাম alphabetically আগে যার, rank তার ভালো
                rows.sort((a, b) => {
                    const ea = Number(a.totalEarnings) || 0, eb = Number(b.totalEarnings) || 0;
                    if (eb !== ea) return eb - ea;
                    return String(a.name || a.displayName || '').localeCompare(String(b.name || b.displayName || ''));
                });
                const entries = rows.map((u, i) => ({
                    rank: i + 1,
                    name: String(u.name || u.displayName || 'Player'),
                    ffUID: String(u.ffUID || ''),
                    totalEarnings: Number(u.totalEarnings) || 0
                }));
                // 3) মোট player (totalEarnings > 0) — count query, consistent সংজ্ঞা
                let totalPlayers = entries.length;
                try {
                    const c = await getCountFromServer(query(collection(db, 'users'), where('totalEarnings', '>', 0)));
                    totalPlayers = c.data().count;
                } catch (e) { console.warn('leaderboard count fallback:', e.message); }
                // 4) ONE doc — আগের publish overwrite হবে (set + merge)
                const uid = (typeof currentUser !== 'undefined' && currentUser && currentUser.uid)
                    || (typeof auth !== 'undefined' && auth.currentUser && auth.currentUser.uid) || 'admin';
                await setDoc(doc(db, 'leaderboard', 'current'), {
                    updatedAt: serverTimestamp(),
                    publishedBy: uid,
                    totalPlayers: totalPlayers,
                    entries: entries
                }, { merge: true });
                showToast('Leaderboard published ✅', 'success');
                refreshLeaderboardPublishInfo();
            } catch (e) {
                console.error('publishLeaderboard:', e);
                showToast('Publish failed: ' + (e.message || e), 'error');
                if (sub) sub.textContent = prevSub;
            } finally {
                window._lbPublishing = false;
            }
        };
        // ══════════════════════════════════════════
        // STAFF PANEL CONTROL (settings/staffPanel) — এখন sidebar-এর Staff স্ক্রিনে
        // (scripts/screens/staff.js)। toggleStaffPanel এখানেই থাকে (staff.js reuse করে)।
        // ফিল্ড: isEnabled, lastToggledAt, lastToggledBy (+ lastActiveAt লেখে staff app নিজে)
        // ══════════════════════════════════════════
        window.toggleStaffPanel = async function(checked) {
            const toggleEl = document.getElementById('stfToggle') || document.getElementById('staffPanelToggle');
            try {
                const by = (typeof currentUser !== 'undefined' && currentUser && (currentUser.email || currentUser.uid)) || 'admin';
                await setDoc(doc(db, 'settings', 'staffPanel'), {
                    isEnabled: checked,
                    lastToggledAt: serverTimestamp(),
                    lastToggledBy: by
                }, { merge: true });
                showToast(checked ? 'Staff Panel Enabled 🟢' : 'Staff Panel Disabled 🔴', checked ? 'success' : 'warning');
            } catch (e) {
                showToast('Failed to update: ' + e.message, 'error');
                if (toggleEl) toggleEl.checked = !checked;
            }
        };
