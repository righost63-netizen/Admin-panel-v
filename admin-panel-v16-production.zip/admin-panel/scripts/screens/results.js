// ── RESULT ENTRY HEADER ──
        // ══════════════════════════════════════════════════════════════
        // RESULT ENTRY, AUTO LEADERBOARD & WALLET LEDGER (SPEC 27-36, 47)
        // ══════════════════════════════════════════════════════════════
        let currentResultTournId = null;
        let currentResultTournData = null;
        let currentResultEntries = []; // Single source of truth for result calculation
        let isResultPublished = false;
        let isPrizesDistributed = false;




// ── STEP 6 FIX: UNIFIED RESULT ENTRY ──
        // ══════════════════════════════════════════════════════════════
        // ✅ STEP 6 FIX: UNIFIED RESULT ENTRY & DUO/SQUAD SCHEMA
        // ══════════════════════════════════════════════════════════════
        window.openUpdateResults = async function(tid, tname = '') {
            currentResultTournId = tid;
            document.getElementById('updateResultsTitle').textContent = tname || 'Results';
            document.getElementById('res_tourn_name').textContent = tname || 'Tournament';
            document.getElementById('resultEntryContainer').innerHTML = '<div class="loading-page"><div class="spinner spinner-accent"></div></div>';
            showFullModal('updateResultsModal');
            // FIX 6 — search/sort toolbar reset on every open
            window._resView = { q: '', sort: 'rank' };
            const _rsSearch = document.getElementById('resSearchInput');
            if (_rsSearch) _rsSearch.value = '';
            const _rsSort = document.getElementById('resSortSelect');
            if (_rsSort) _rsSort.value = 'rank';

            try {
                // ১. টুর্নামেন্ট ডাটা লোড
                const tSnap = await getDoc(doc(db, 'tournaments', tid));
                if (!tSnap.exists()) {
                    showToast('Tournament not found', 'error');
                    closeModal('updateResultsModal');
                    return;
                }
                currentResultTournData = {
                    id: tSnap.id,
                    ...tSnap.data()
                };
                const t = currentResultTournData;
                const isSolo = (t.teamFormat || 'SOLO') === 'SOLO';

                document.getElementById('res_tourn_name').textContent = t.name;
                // ✂️ টুর্নামেন্টের Prize Type (fixed / perkill / both) রেজল্ভ করে রাখা হচ্ছে —
                // legacy টুর্নামেন্টে prizeType ফিল্ড না থাকলে perKill/prizePool থেকে অনুমান করা হয় (tournaments.js এর মতোই)
                const resPrizeType = t.prizeType || (Number(t.perKill) > 0 && Number(t.prizePool) > 0 ? 'both' : Number(t.perKill) > 0 ? 'perkill' : 'fixed');
                window._resPrizeType = resPrizeType;
                const resTotalBudget = t.totalPrizeBudget !== undefined ? t.totalPrizeBudget :
                    calcTotalPrizeBudget(resPrizeType, t.perKill || 0, t.prizePool || 0, t.teamFormat || 'SOLO');
                const metaBits = [`Format: ${t.teamFormat || 'SOLO'}`];
                if (resPrizeType !== 'fixed') metaBits.push(`Per Kill: ₹${t.perKill || 0}`);
                metaBits.push(`Total Budget: ₹${resTotalBudget}`);
                const typeLabel = resPrizeType === 'perkill' ? 'Per Kill Only' : resPrizeType === 'both' ? 'Fixed + Per Kill' : 'Fixed Pool';
                document.getElementById('res_tourn_meta').textContent = `${metaBits.join(' • ')} • ${typeLabel}`;

                isPrizesDistributed = t.prizesDistributed === true;
                updatePayoutBadge(isPrizesDistributed);

                // ২. পূর্বে সেভ করা রেজাল্ট থাকলে তা ফেচ করা
                const resDocSnap = await getDoc(doc(db, 'tournamentResults', tid));
                let savedResultsMap = {};
                if (resDocSnap.exists()) {
                    const rData = resDocSnap.data();
                    isResultPublished = rData.published === true;
                    // Compatibility for both 'results' and legacy 'players' array
                    (rData.results || rData.players || []).forEach(r => {
                        const key = r.teamId || r.userId;
                        if (key) savedResultsMap[key] = r;
                    });
                } else {
                    isResultPublished = false;
                }
                updatePublishBadge(isResultPublished);

                // ৩. পার্টিসিপেন্ট তালিকা ফেচ করা (শুধুমাত্র Confirmed/Approved)
                // ✅ FIX: tournamentId দিয়ে সব টিম ফেচ করে status ক্লায়েন্ট-সাইডে ফিল্টার করা হচ্ছে,
                // যাতে 'in' + equality কম্পোজিট ইনডেক্স না থাকলেও কোয়েরি ফেইল না করে।
                let participants = [];
                const teamsSnap = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', tid)));
                const confirmedTeams = teamsSnap.docs.filter(d => {
                    const st = (d.data().status || '').toLowerCase();
                    return st === 'confirmed' || st === 'approved';
                });

                if (confirmedTeams.length > 0) {
                    participants = confirmedTeams.map(d => ({
                        id: d.id,
                        ...d.data()
                    }));
                } else {
                    // Fallback to legacy joinRequests
                    const reqSnapAll = await getDocs(query(collection(db, 'joinRequests'), where('tournamentId', '==', tid)));
                    const reqSnap = {
                        docs: reqSnapAll.docs.filter(d => {
                            const st = (d.data().status || '').toLowerCase();
                            return st === 'accepted' || st === 'confirmed';
                        })
                    };
                    participants = reqSnap.docs.map(d => {
                        const dData = d.data();
                        return {
                            id: d.id,
                            teamId: dData.teamId || d.id,
                            teamName: dData.teamName || dData.userName || 'Solo Participant',
                            captainUserId: dData.userId || '',
                            players: dData.players || [{
                                userId: dData.userId || '',
                                playerName: dData.userName || 'Player',
                                ffUID: dData.ffUID || '—'
                            }],
                            status: 'confirmed'
                        };
                    });
                }

                if (participants.length === 0) {
                    document.getElementById('resultEntryContainer').innerHTML = `
                        <div class="empty-state">
                            <div class="empty-icon">👥</div>
                            <div class="empty-title">No Confirmed Participants</div>
                            <div class="empty-subtitle">Please confirm participants before entering match results.</div>
                        </div>
                    `;
                    document.getElementById('liveLeaderboardBox').innerHTML = '<div style="text-align:center;color:var(--color-text-secondary);">No participants</div>';
                    return;
                }

                // ৪. রেজাল্ট স্টেট প্রস্তুত করা (Strict Solo vs Duo/Squad Schema)
                currentResultEntries = participants.map((p, idx) => {
                    const key = p.teamId || p.id;
                    const saved = savedResultsMap[key] || {};

                    // Unified Team & Player Naming
                    const cName = p.captainName || (p.players && p.players[0]?.playerName) || p.teamName || 'Player';
                    const cUid = p.captainUserId || (p.players && p.players[0]?.userId) || '';
                    const cFFuid = (p.players && p.players[0]?.ffUID) || '—';

                    return {
                        teamId: key,
                        teamName: isSolo ? cName : (p.teamName || 'Team'),
                        userId: cUid,
                        playerName: cName,
                        ffUID: cFFuid,
                        players: p.players || [], // Teammates data for frontend UI
                        rank: saved.rank !== undefined ? saved.rank : (idx + 1),
                        kills: saved.kills !== undefined ? saved.kills : 0,
                        killReward: 0,
                        rankPrize: 0,
                        totalPrize: 0
                    };
                });

                renderResultEntryInputs(isSolo);
                recalculateAllResults();
            } catch (e) {
                console.error('openUpdateResults error:', e);
                showToast('Failed to load results: ' + e.message, 'error');
            }
        };

        // ── Render Result Inputs per participant ──
        // ✂️ পরিবর্তন: শুধু ✅ প্রিমিয়াম ক্লাস ব্যবহার হচ্ছে, আর টুর্নামেন্টের Prize Type
        // (fixed / perkill / both) অনুযায়ী Rank# আর Kills ইনপুট আলাদাভাবে শো/হাইড হয়
        // FIX 6 — search/sort view state (logic untouched: handlers still get original idx)
        window._resView = window._resView || { q: '', sort: 'rank' };

        window.resOnSearch = function(v) {
            window._resView.q = (v || '').toLowerCase();
            if (!currentResultEntries.length) return;
            const isSolo = (currentResultTournData && currentResultTournData.teamFormat || 'SOLO') === 'SOLO';
            renderResultEntryInputs(isSolo);
        };
        window.resOnSort = function(v) {
            window._resView.sort = v || 'rank';
            if (!currentResultEntries.length) return;
            const isSolo = (currentResultTournData && currentResultTournData.teamFormat || 'SOLO') === 'SOLO';
            renderResultEntryInputs(isSolo);
        };

        function getResultViewOrder() {
            const v = window._resView || { q: '', sort: 'rank' };
            let order = currentResultEntries.map((_, i) => i);
            if (v.q) {
                order = order.filter(i => {
                    const it = currentResultEntries[i];
                    const hay = ((it.teamName || '') + ' ' + (it.playerName || '') + ' ' + (it.ffUID || '') + ' ' + (it.teamId || '')).toLowerCase();
                    return hay.indexOf(v.q) !== -1;
                });
            }
            const by = {
                rank: (a, b) => (currentResultEntries[a].rank || 999) - (currentResultEntries[b].rank || 999),
                kills: (a, b) => (currentResultEntries[b].kills || 0) - (currentResultEntries[a].kills || 0),
                prize: (a, b) => (currentResultEntries[b].totalPrize || 0) - (currentResultEntries[a].totalPrize || 0),
                name: (a, b) => String(currentResultEntries[a].teamName || '').localeCompare(String(currentResultEntries[b].teamName || ''))
            };
            order.sort(by[v.sort] || by.rank);
            return order;
        }

        function renderResultEntryInputs(isSolo) {
            const container = document.getElementById('resultEntryContainer');
            const pType = window._resPrizeType || 'fixed';
            const showRank = pType === 'fixed' || pType === 'both';
            const showKills = pType === 'perkill' || pType === 'both';
            const order = getResultViewOrder();

            const countEl = document.getElementById('resEntryCount');
            if (countEl) countEl.textContent = order.length === currentResultEntries.length
                ? order.length + ' entries' : order.length + ' of ' + currentResultEntries.length;

            if (!order.length) {
                container.innerHTML = '<div class="rs-empty"><div class="rs-empty-ic">🔍</div><h4>No matches</h4><p>Try a different search.</p></div>';
                return;
            }

            container.innerHTML = order.map((origIdx) => {
                // FIX (XSS): ffUID / teamId / playerName যুজার-ইনপুট — esc() ছাড়া innerHTML-এ
                // ঢুকলে admin ব্রাউজারে স্ক্রিপ্ট চলতে পারে। subText এখানেই escape করা হলো।
                const subText = isSolo ?
                    `UID: ${esc(item.ffUID || '')}` :
                    `Team ID: ${esc(item.teamId || '')} \u2022 Cap: ${esc(item.playerName || '')}`;

                const rankField = !showRank ? '' : `
                        <div class="rs-field"><label>Rank</label>
                            <input type="number" value="${item.rank}" min="1" max="100" oninput="onEntryRankChange(${origIdx}, this.value)" aria-label="Rank">
                        </div>`;

                const killsField = !showKills ? '' : `
                        <div class="rs-field"><label>Kills</label>
                            <div class="rs-stepper">
                                <button type="button" class="rs-step-btn" onclick="adjustKillStep(${origIdx}, -1)" aria-label="Decrease kills">\u2212</button>
                                <input id="inp-kills-${origIdx}" type="number" value="${item.kills}" min="0" max="99" oninput="onEntryKillChange(${origIdx}, this.value)" aria-label="Kills">
                                <button type="button" class="rs-step-btn" onclick="adjustKillStep(${origIdx}, 1)" aria-label="Increase kills">+</button>
                            </div>
                        </div>`;

                const topCls = (item.rank === 1) ? 'is-top1' : (item.rank === 2) ? 'is-top2' : (item.rank === 3) ? 'is-top3' : '';
                return `
                    <div class="rs-entry ${topCls}">
                        <div class="rs-rank">${item.rank || '\u2013'}</div>
                        <div class="rs-info">
                            <div class="rs-name">${esc(item.teamName)}</div>
                            <div class="rs-sub">${subText}</div>
                            <div class="rs-prize" id="calc-preview-${origIdx}">\u20b90</div>
                        </div>
                        <div class="rs-fields">${rankField}${killsField}</div>
                    </div>
                `;
            }).join('');

            // search/sort re-render-এর পর preview line sync (মান recalculateAllResults-ই হিসাব করে)
            currentResultEntries.forEach((item, idx) => {
                const el = document.getElementById(`calc-preview-${idx}`);
                if (el) {
                    const bits = [];
                    if (showKills) bits.push(`Kills: \u20b9${item.killReward || 0}`);
                    if (showRank) bits.push(`Rank: \u20b9${item.rankPrize || 0}`);
                    el.textContent = `\u20b9${item.totalPrize || 0}` + (bits.length ? ` (${bits.join(' + ')})` : '');
                }
            });
        }

        function recalculateAllResults() {
            const pType = window._resPrizeType || 'fixed';
            const useKills = pType === 'perkill' || pType === 'both';
            const useRank = pType === 'fixed' || pType === 'both';
            const perKillRate = useKills ? (currentResultTournData?.perKill || 0) : 0;
            let prizeDist = currentResultTournData?.prizeDistribution || [];
            // ফলব্যাক: যদি পুরনো টুর্নামেন্টে prizeDistribution না থাকে
            if (prizeDist.length === 0 && (currentResultTournData?.firstPrize || currentResultTournData?.secondPrize)) {
                if (currentResultTournData.firstPrize) prizeDist.push({
                    rank: 1,
                    amount: Number(currentResultTournData.firstPrize)
                });
                if (currentResultTournData.secondPrize) prizeDist.push({
                    rank: 2,
                    amount: Number(currentResultTournData.secondPrize)
                });
                if (currentResultTournData.thirdPrize) prizeDist.push({
                    rank: 3,
                    amount: Number(currentResultTournData.thirdPrize)
                });
            }

            // Rank -> Prize Mapping
            const rankPrizeMap = {};
            prizeDist.forEach(p => {
                rankPrizeMap[p.rank] = p.amount || 0;
            });

            // 1. Calculate each row
            currentResultEntries.forEach((item, idx) => {
                const kills = item.kills || 0;
                // Per Kill Only মোডে Rank ইনপুট নেই — অভ্যন্তরীণভাবে ক্রম অনুযায়ী rank বসিয়ে রাখা হচ্ছে (leaderboard sort-এর জন্য)
                if (!useRank) item.rank = idx + 1;
                const rank = item.rank || 1;
                item.killReward = useKills ? kills * perKillRate : 0;
                item.rankPrize = useRank ? (rankPrizeMap[rank] || 0) : 0;
                item.totalPrize = item.killReward + item.rankPrize;

                const prevEl = document.getElementById(`calc-preview-${idx}`);
                if (prevEl) {
                    const bits = [];
                    if (useKills) bits.push(`Kills: ₹${item.killReward}`);
                    if (useRank) bits.push(`Rank: ₹${item.rankPrize}`);
                    prevEl.textContent = `₹${item.totalPrize}` + (bits.length ? ` (${bits.join(' + ')})` : '');
                }
            });

            // 2. Validate Duplicate Ranks (Section 30) — Rank ইনপুট শো হলেই শুধু প্রযোজ্য
            const warnEl = document.getElementById('rankConflictWarning');
            if (useRank) {
                const rankCounts = {};
                let hasDuplicate = false;
                currentResultEntries.forEach(item => {
                    if (item.rank) {
                        rankCounts[item.rank] = (rankCounts[item.rank] || 0) + 1;
                        if (rankCounts[item.rank] > 1) hasDuplicate = true;
                    }
                });
                if (hasDuplicate) {
                    warnEl.style.display = 'block';
                    warnEl.textContent = '⚠️ Duplicate rank detected! Each participant must have a unique rank.';
                } else {
                    warnEl.style.display = 'none';
                }
            } else {
                warnEl.style.display = 'none';
            }

            // 3. Generate Automatic Leaderboard Preview
            renderLeaderboardPreview();
        }

        function renderLeaderboardPreview() {
            const previewEl = document.getElementById('liveLeaderboardBox');
            if (!previewEl) return;

            const pType = window._resPrizeType || 'fixed';
            const useKills = pType === 'perkill' || pType === 'both';
            const useRank = pType === 'fixed' || pType === 'both';

            // Per Kill Only হলে Kills দিয়ে সাজানো হবে (বেশি কিল যার আগে), নাহলে Rank দিয়ে
            const sorted = [...currentResultEntries].sort((a, b) =>
                useRank ? (a.rank || 999) - (b.rank || 999) : (b.kills || 0) - (a.kills || 0)
            );

            previewEl.innerHTML = sorted.map((item, idx) => {
                const posNum = useRank ? item.rank : idx + 1;
                const rankBadge = posNum === 1 ? '🥇' : posNum === 2 ? '🥈' : posNum === 3 ? '🥉' : `#${posNum}`;

                const subBits = [];
                if (useKills) subBits.push(`${item.kills} kills (₹${item.killReward})`);
                if (useRank) subBits.push(`Rank prize ₹${item.rankPrize}`);

                return `
                    <div class="rs-lb-row">
                        <div class="rs-lb-rank">${rankBadge}</div>
                        <div style="min-width:0;">
                            <div class="rs-lb-name">${esc(item.teamName)}</div>
                            <div class="rs-lb-sub">${subBits.join(' • ') || '—'}</div>
                        </div>
                        <div class="rs-lb-prize">₹${item.totalPrize}</div>
                    </div>
                `;
            }).join('');
        }

        // ── Save Results to Firebase ──
        window.saveResultDraft = async function(silent = false) {
            if (!currentResultTournId) return;

            // Sort before saving
            const sortedResults = [...currentResultEntries].sort((a, b) => (a.rank || 999) - (b.rank || 999));

            try {
                await setDoc(doc(db, 'tournamentResults', currentResultTournId), {
                    tournamentId: currentResultTournId,
                    tournamentName: currentResultTournData?.name || 'Tournament',
                    teamFormat: currentResultTournData?.teamFormat || 'SOLO',
                    perKill: currentResultTournData?.perKill || 0,
                    prizePool: currentResultTournData?.prizePool || 0,
                    results: sortedResults,
                    players: sortedResults, // compatibility
                    published: isResultPublished,
                    prizesDistributed: isPrizesDistributed,
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });

                if (!silent) showToast('Results saved successfully! ✅', 'success');
            } catch (e) {
                console.error('saveResultDraft error:', e);
                if (!silent) showToast('Failed to save results: ' + e.message, 'error');
            }
        };

        // ── Toggle Publish Results (Section 33) ──
        window.togglePublishResults = async function() {
            // Check for duplicate ranks before publishing
            const ranks = currentResultEntries.map(r => r.rank);
            if (new Set(ranks).size !== ranks.length) {
                showToast('Cannot publish with duplicate ranks! Fix ranks first.', 'error');
                return;
            }

            const newPublishState = !isResultPublished;
            isResultPublished = newPublishState;
            updatePublishBadge(isResultPublished);

            try {
                await saveResultDraft(true);
                await updateDoc(doc(db, 'tournamentResults', currentResultTournId), {
                    published: newPublishState,
                    publishedAt: newPublishState ? serverTimestamp() : null
                });

                if (newPublishState) {
                    await updateDoc(doc(db, 'tournaments', currentResultTournId), {
                        status: 'completed',
                        updatedAt: serverTimestamp()
                    });
                }

                await touchCache('leaderboard');
                showToast(newPublishState ? 'Leaderboard published to users! 📢' : 'Leaderboard unpublished (Draft) 🔒', newPublishState ? 'success' : 'info');
            } catch (e) {
                showToast('Error: ' + e.message, 'error');
            }
        };
window.distributePrizesWithLedger = function() {
    if (isPrizesDistributed) { showToast('প্রাইজ আগেই ডিস্ট্রিবিউট হয়ে গেছে!', 'warning'); return; }
    // FIX: "Distribute Only" পথে ডুপ্লিকেট র‍্যাঙ্ক চেক ছিল না (togglePublishResults-এ আছে)
    const ranks = currentResultEntries.map(r => r.rank);
    if (new Set(ranks).size !== ranks.length) { showToast('Duplicate ranks found! Fix ranks before distributing.', 'error'); return; }
    // FIX: মোট পেআউট প্রাইজ পুলের বেশি হলে ব্লক করো
    const totalPayout = currentResultEntries.reduce((s, r) => s + Number(r.totalPrize || 0), 0);
    const prizePool = Number(currentResultTournData?.prizePool || 0);
    if (prizePool > 0 && totalPayout > prizePool) { showToast(`Total payout ₹${totalPayout} exceeds prize pool ₹${prizePool}!`, 'error'); return; }
    showActionSheet('Distribute Tournament Prizes?', 'This will credit prize amounts to winners\' wallets. This action cannot be reversed.', [{
        label: 'Confirm & Distribute Now',
        style: 'default',
        action: async () => {
            const btn = document.getElementById('btnDistributePrizes');
            if (btn) { btn.disabled = true; btn.textContent = 'Distributing...'; }
            try {
                await saveResultDraft(true);
                await runPrizeDistributionCore();
                showToast('Prizes credited! 🏆', 'success');
            } catch (e) {
                if (e.message === "ALREADY_DISTRIBUTED") { showToast('Already distributed!', 'warning'); isPrizesDistributed = true; updatePayoutBadge(true); }
                else showToast('Distribution failed: ' + e.message, 'error');
            } finally {
                if (btn) { btn.disabled = false; btn.textContent = isPrizesDistributed ? '✅ Distributed' : '💰 Distribute Prizes to Wallets'; }
            }
        }
    }]);
};

// ── আগের distributePrizesWithLedger এর ভেতরের পুরো transaction লজিক এখানে (অপরিবর্তিত) ──
async function runPrizeDistributionCore() {
    const tName = currentResultTournData?.name || 'Tournament';
    let distributedCount = 0;
    const notificationsToSend = [];

    await runTransaction(db, async (transaction) => {
        const tourRef = doc(db, 'tournaments', currentResultTournId);
        const tourSnap = await transaction.get(tourRef);
        if (!tourSnap.exists()) throw new Error("Tournament not found!");
        if (tourSnap.data().prizesDistributed === true) throw new Error("ALREADY_DISTRIBUTED");

        for (const item of currentResultEntries) {
            const recipientUserId = item.userId;
            const amount = item.totalPrize || 0;
            if (recipientUserId && amount > 0) {
                distributedCount++;
                const ledgerDocRef = doc(collection(db, 'walletTransactions'));
                const userRef = doc(db, 'users', recipientUserId);
                transaction.set(ledgerDocRef, {
                    transactionId: 'TXN-PRZ-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
                    userId: recipientUserId, userName: item.playerName || item.teamName,
                    amount, type: 'prize', title: `${tName} - Prize`,
                    referenceType: 'tournament', referenceId: currentResultTournId, tournamentName: tName,
                    description: `Prize for ${tName} (Rank #${item.rank}: ₹${item.rankPrize} + Kills: ₹${item.killReward})`,
                    status: 'completed', createdAt: serverTimestamp()
                });
                transaction.update(userRef, {
                    walletBalance: increment(amount), totalEarnings: increment(amount),
                    // FIX: Per-Kill মোডে rank=1 হলেও rankPrize ০ হতে পারে — তখন win গণনা হবে না
                    totalWins: (item.rank === 1 && Number(item.rankPrize || 0) > 0) ? increment(1) : increment(0),
                    prizeHistory: arrayUnion({ tournamentId: currentResultTournId, tournamentName: tName, rank: item.rank, amount, distributedAt: new Date().toISOString() })
                });
                notificationsToSend.push({ userId: recipientUserId, amount });
            }
        }

        transaction.update(tourRef, { status: 'completed', prizesDistributed: true, prizeDistributedAt: serverTimestamp(), updatedAt: serverTimestamp() });
        transaction.update(doc(db, 'tournamentResults', currentResultTournId), { prizesDistributed: true, published: true, distributedAt: serverTimestamp() });
    });

    notificationsToSend.forEach(n => notifyUserWithPush(n.userId, '🏆 Tournament Prize Credited!', `You received ₹${n.amount} from tournament! Check your wallet.`, 'prize').catch(() => {}));
    await touchCache('leaderboard');
    isPrizesDistributed = true; isResultPublished = true;
    updatePayoutBadge(true); updatePublishBadge(true);
}


// গ্লোবাল ভেরিয়েবল টেম্পোরারি স্টোরেজের জন্য
let currentTournSettings = {};
let confirmedPlayers = [];

function closeResultsSheet() {
    document.getElementById('resultsSheetOverlay').classList.remove('visible');
    document.getElementById('resultsSheet').classList.remove('visible');
}


// 4. পাবলিশ এবং ডিস্ট্রিবিউট (Firebase Batch Write)
async function publishResultsAndPay() {
    const btn = document.getElementById('btnPublishResults');
    btn.innerHTML = '<div class="spinner spinner-accent"></div> Publishing...';
    btn.disabled = true;

    try {
        // Firebase Batch Write শুরু করুন
        // import { writeBatch, doc } from "firebase/firestore";
        // const batch = writeBatch(db);

        // ১. প্রতিটি প্লেয়ারের ডাটা আপডেট এবং ওয়ালেটে টাকা যোগ করা
        for (const player of confirmedPlayers) {
            // যদি Win > 0 হয় তবে ইউজারের ওয়ালেট আপডেট করার কোড (Batch-এ)
            if (player.calculatedWin > 0) {
                /*
                const userRef = doc(db, "users", player.userId);
                batch.update(userRef, {
                    walletBalance: increment(player.calculatedWin)
                });
                
                // Transaction History তেও সেভ করা উচিত
                */
            }
            
            // টুর্নামেন্টের রেজাল্ট কালেকশনে প্লেয়ারের Rank, Kills সেভ করুন
            /*
            const resultRef = doc(db, `tournaments/${currentTournSettings.id}/results`, player.id);
            batch.set(resultRef, {
                rank: player.rank,
                kills: player.kills,
                prizeWon: player.calculatedWin
            });
            */
        }

        // ২. টুর্নামেন্টের স্ট্যাটাস 'completed' করে দেওয়া
        /*
        const tournRef = doc(db, "tournaments", currentTournSettings.id);
        batch.update(tournRef, { status: "completed" });
        
        await batch.commit();
        */

        showToast("Results Published & Prizes Distributed Successfully! 🏆", "success");
        closeResultsSheet();
        
    } catch (error) {
        console.error(error);
        showToast("Failed to publish results!", "error");
    } finally {
        btn.innerHTML = '🚀 Publish Results & Distribute Prize';
        btn.disabled = false;
    }
}
// ── ব্যাজ ফাংশন (আগে অনুপস্থিত ছিল) ──
function updatePublishBadge(published) {
    const el = document.getElementById('publishBadge');
    if (!el) return;
    el.textContent = published ? '📢 Published' : '🔒 Draft';
    el.className = 'rs-badge ' + (published ? 'is-published' : 'is-draft');
}
function updatePayoutBadge(distributed) {
    const el = document.getElementById('payoutBadge');
    if (!el) return;
    el.textContent = distributed ? '💰 Distributed' : '⏳ Not Distributed';
    el.className = 'rs-badge ' + (distributed ? 'is-paid' : 'is-pending');
}

// ── ✅ এক-ক্লিকে: Save + Publish + Auto Prize Distribution (FREE/PAID উভয়ে কাজ করে) ──
window.finalizeResults = async function() {
    if (!currentResultTournId || currentResultEntries.length === 0) {
        showToast('কোনো প্লেয়ার ডাটা নেই!', 'warning'); return;
    }
    const ranks = currentResultEntries.map(r => r.rank);
    if (new Set(ranks).size !== ranks.length) {
        showToast('একই Rank দুইজনকে দেওয়া যাবে না!', 'error'); return;
    }
    if (isPrizesDistributed) {
        showToast('প্রাইজ আগেই ডিস্ট্রিবিউট হয়ে গেছে।', 'warning'); return;
    }

    const btn = document.getElementById('btnFinalizeResults');
    if (btn) { btn.disabled = true; btn.textContent = 'Finalizing...'; }

    try {
        await saveResultDraft(true);
        isResultPublished = true;
        updatePublishBadge(true);
        await updateDoc(doc(db, 'tournamentResults', currentResultTournId), { published: true, publishedAt: serverTimestamp() });
        await updateDoc(doc(db, 'tournaments', currentResultTournId), { status: 'completed', updatedAt: serverTimestamp() });
        await touchCache('leaderboard');

        await runPrizeDistributionCore(); // নিচের রিফ্যাক্টর করা কোর ফাংশন

        showToast('Result Published & Prize Distributed! 🏆✅', 'success');
    } catch (e) {
        console.error('finalizeResults error:', e);
        showToast('Error: ' + e.message, 'error');
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = '🏆 Finalize: Publish + Auto Distribute'; }
    }
};