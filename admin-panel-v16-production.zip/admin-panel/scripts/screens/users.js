        // ╔══════════════════════════════════════════════════════════════════════╗
        // ║ ফাইল: scripts/screens/users.js  (পুরো ফাইল রিপ্লেস করা যাবে)            ║
        // ║ শুধু অংশ বদলাতে চাইলে ✅ চিহ্নিত ৩টা ব্লক:                                ║
        // ║   ১) এই আইকন ব্লক → ফাইলের একদম উপরে যোগ                                ║
        // ║   ২) loadUsers এর ভেতরে ১টা লাইন বদল ("No Users Found" এর লাইন)          ║
        // ║   ৩) renderUsers() থেকে ফাইলের শেষ পর্যন্ত → রিপ্লেস                       ║
        // ║ pages/users.html এ কোনো পরিবর্তন লাগবে না।                               ║
        // ╚══════════════════════════════════════════════════════════════════════╝

        // ✅ [ইউজার রিডিজাইন ১] শুরু — আইকন
        const US_ICONS = {
            copy:  '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="3"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>',
            check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
            edit:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/></svg>',
            ban:   '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="m6 6 12 12"/></svg>',
            trash: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>',
            users: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20v-1a6 6 0 0 1 6-6h1a6 6 0 0 1 6 6v1"/><circle cx="17.5" cy="9" r="2.5"/><path d="M21.5 19v-.5a4.5 4.5 0 0 0-4-4.4"/></svg>'
        };
        // ✅ [ইউজার রিডিজাইন ১] শেষ

        // ✅ [নতুন] সার্চ debounce টাইমার — filterUsers()-এ ব্যবহার হবে
        let usersSearchDebounceTimer = null;

        // ══════════════════════════════════════════
        // USERS
        // ══════════════════════════════════════════
        window.loadUsers = async function(isLoadMore = false) {
            if (isUsersLoading) return;
            isUsersLoading = true;

            const elList = document.getElementById('usersList');
            if (!isLoadMore) {
                elList.innerHTML = '<div class="loading-center"><div class="spinner spinner-accent"></div></div>';
                lastVisibleUserDoc = null;
                allUsers = [];
            } else {
                const loadMoreBtn = document.getElementById('loadMoreUsersBtn');
                if (loadMoreBtn) loadMoreBtn.innerHTML = '<div class="spinner spinner-accent" style="width:16px; height:16px; margin:auto;"></div>';
            }

            try {
                let q;
                const usersRef = collection(db, 'users');

                if (usersSearchQuery) {
                    // FIX: exact-match সার্চ case-sensitive ছিল ("Rahul" ≠ "rahul")।
                    // Firestore-এ contains সার্চ নেই, তাই ২০০টা এনে client-side-এ
                    // case-insensitive contains ফিল্টার করা হয় (name/email/FF UID)।
                    q = query(usersRef, orderBy('createdAt', 'desc'), limit(200));
                } else {
                    // সাধারণ পেজিনেটেড কুয়েরি (একবারে মাত্র ২০টি ডকুমেন্ট)
                    if (isLoadMore && lastVisibleUserDoc) {
                        q = query(usersRef, orderBy('createdAt', 'desc'), startAfter(lastVisibleUserDoc), limit(20));
                    } else {
                        q = query(usersRef, orderBy('createdAt', 'desc'), limit(20));
                    }
                }

                const snap = await getDocs(q);
                const newUsers = snap.docs.map(d => ({
                    id: d.id,
                    ...d.data()
                }));

                // FIX: সার্চ হলে client-side case-insensitive contains ফিল্টার
                let filteredUsers = newUsers;
                if (usersSearchQuery) {
                    const ql = usersSearchQuery.toLowerCase();
                    filteredUsers = newUsers.filter(u =>
                        String(u.name || '').toLowerCase().includes(ql) ||
                        String(u.email || '').toLowerCase().includes(ql) ||
                        String(u.ffUID || u.ffUid || '').toLowerCase().includes(ql) ||
                        String(u.id || '').toLowerCase().includes(ql)
                    );
                }

                if (filteredUsers.length === 0 && !isLoadMore) {
                    usersShowEmpty(elList);   // ✅ [ইউজার রিডিজাইন ২] আগে এখানে 👤 empty-state ছিল
                    const loadMoreContainer = document.getElementById('loadMoreUsersContainer');
                    if (loadMoreContainer) loadMoreContainer.innerHTML = '';
                    isUsersLoading = false;
                    return;
                }

                lastVisibleUserDoc = snap.docs[snap.docs.length - 1];

                if (isLoadMore) {
                    allUsers = [...allUsers, ...filteredUsers];
                } else {
                    allUsers = filteredUsers;
                }

                renderUsers(allUsers);

                // Load More বাটন সেকশন তৈরি
                let loadMoreContainer = document.getElementById('loadMoreUsersContainer');
                if (!loadMoreContainer) {
                    loadMoreContainer = document.createElement('div');
                    loadMoreContainer.id = 'loadMoreUsersContainer';
                    loadMoreContainer.style.padding = '16px';
                    elList.after(loadMoreContainer);
                }

                // সার্চ করা থাকলে বা পরবর্তী পেজ না থাকলে Load More হাইড থাকবে
                if (snap.docs.length < 20 || usersSearchQuery) {
                    loadMoreContainer.innerHTML = '';
                } else {
                    loadMoreContainer.innerHTML = `<button class="btn-secondary" id="loadMoreUsersBtn" onclick="loadUsers(true)" style="width:100%; height:44px;">Load More Users</button>`;
                }

            } catch (e) {
                showToast('Error loading users: ' + e.message, 'error');
            }
            isUsersLoading = false;
        };

        window.filterUsers = function() {
            // ✅ [নতুন] প্রতি কিস্ট্রোকে সাথে সাথে query না পাঠিয়ে, টাইপ থামার ৪০০ms পর একবার পাঠানো হয় (wallet.js-এর walletSearchTyped() প্যাটার্ন)
            clearTimeout(usersSearchDebounceTimer);
            usersSearchDebounceTimer = setTimeout(() => {
                const qInput = document.getElementById('userSearch').value.trim();
                usersSearchQuery = qInput;
                loadUsers(false); // নতুন সার্চের জন্য প্রথম পেইজ থেকে লোড শুরু হবে
            }, 400);
        };

        window.openUserSheet = function(u) {
            editingUserId = u.id;
            document.getElementById('us_name').value = u.name || '';
            document.getElementById('us_ffuid').value = u.ffUID || '';
            document.getElementById('us_balance_display').textContent = '₹' + (u.walletBalance || 0).toLocaleString();
            document.getElementById('us_add').value = '';
            document.getElementById('us_deduct').value = '';
            document.getElementById('us_wins').value = u.totalWins || 0; // উইন কাউন্টার সেট করা হচ্ছে
            // ✅ Premium header: avatar + email
            const av = document.getElementById('us_avatar');
            if (av) av.textContent = (u.name || '?').trim().charAt(0).toUpperCase() || '?';
            const em = document.getElementById('us_email_sub');
            if (em) em.textContent = u.email || u.id || '—';
            // ✅ Premium status chips (display-only — saveUser logic unchanged)
            const st = document.getElementById('us_status');
            if (st) {
                const chips = [];
                const role = u.role || 'user';
                if (role === 'admin') chips.push('<span class="ue-chip ue-chip-admin">👑 Admin</span>');
                else if (role === 'staff') chips.push('<span class="ue-chip ue-chip-staff">🛡️ Staff</span>');
                else if (role === 'pending') chips.push('<span class="ue-chip ue-chip-warn">⏳ Pending Admin</span>');
                else if (role === 'pending-staff') chips.push('<span class="ue-chip ue-chip-warn">⏳ Pending Staff</span>');
                else chips.push('<span class="ue-chip ue-chip-role">🎮 Player</span>');
                chips.push(u.isBanned
                    ? '<span class="ue-chip ue-chip-banned">🚫 Banned</span>'
                    : '<span class="ue-chip ue-chip-active"><i class="ue-dot"></i>Active</span>');
                st.innerHTML = chips.join('');
            }
            showSheet('userSheet', 'userSheetOverlay');
        };

        window.closeUserSheet = function() {
            hideSheet('userSheet', 'userSheetOverlay');
        };


// ── STEP 11 FIX: ADMIN BALANCE ADJUSTMENT ──
        // ══════════════════════════════════════════════════════════════
        // ✅ STEP 11 FIX: ADMIN BALANCE ADJUSTMENT WITH LEDGER & NOTIFICATION
        // ══════════════════════════════════════════════════════════════
        window.saveUser = async function() {
            if (!editingUserId) return;
            const btn = document.getElementById('saveUserBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';

            try {
                const add = parseFloat(document.getElementById('us_add').value) || 0;
                const deduct = parseFloat(document.getElementById('us_deduct').value) || 0;
                const wins = parseInt(document.getElementById('us_wins').value) || 0;
                const delta = add - deduct;
                const userName = document.getElementById('us_name').value.trim();

                const userRef = doc(db, 'users', editingUserId);

                const data = {
                    name: userName,
                    ffUID: document.getElementById('us_ffuid').value.trim(),
                    totalWins: wins,
                    updatedAt: serverTimestamp()
                };

                // যদি ব্যালেন্স পরিবর্তন করা হয়
                if (delta !== 0) {
                    // FIX: ডেবিট (delta < 0) হলে ব্যালেন্স আগে fresh পড়ে যাচাই করা —
                    // balance + delta < 0 হলে abort, নাহলে wallet negative হয়ে যাবে।
                    if (delta < 0) {
                        const balSnap = await getDoc(userRef);
                        const bal = balSnap.exists() ? (Number(balSnap.data().walletBalance) || 0) : 0;
                        if (bal + delta < 0) {
                            showToast(`Insufficient balance — user has ₹${bal}, cannot deduct ₹${Math.abs(delta)}.`, 'error');
                            return;
                        }
                    }
                    const batch = writeBatch(db);

                    // ১. ইউজারের ব্যালেন্স আপডেট
                    data.walletBalance = increment(delta);
                    batch.update(userRef, data);

                    // ২. ওয়ালেট লেজারে ট্রানজেকশন হিস্ট্রি যোগ করা (User Panel-এ দেখানোর জন্য)
                    const isCredit = delta > 0;
                    const ledgerRef = doc(collection(db, 'walletTransactions'));
                    batch.set(ledgerRef, {
                        transactionId: 'TXN-ADM-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
                        userId: editingUserId,
                        userName: userName,
                        amount: delta,
                        type: isCredit ? 'credit' : 'debit',
                        title: isCredit ? 'Admin Balance Credit' : 'Admin Balance Deduction',
                        description: isCredit ?
                            `Admin added ₹${delta} to your wallet.` :
                            `Admin deducted ₹${Math.abs(delta)} from your wallet.`,
                        status: 'completed',
                        createdAt: serverTimestamp()
                    });

                    // ৩. ইউজারকে ইন-অ্যাপ নোটিফিকেশন পাঠানো
                    const notifRef = doc(collection(db, 'users', editingUserId, 'notifications'));
                    batch.set(notifRef, {
                        title: isCredit ? '💰 Wallet Credited' : '💸 Wallet Debited',
                        message: isCredit ?
                            `₹${delta} has been added to your wallet balance by Admin.` :
                            `₹${Math.abs(delta)} has been deducted from your wallet balance by Admin.`,
                        type: isCredit ? 'success' : 'warning',
                        read: false,
                        createdAt: serverTimestamp()
                    });

                    await batch.commit();

                    // পুশ নোটিফিকেশন পাঠানো
                    // FIX (BUILD 16): honest result — fail হলে warning toast
                    const pushTitle = isCredit ? '💰 Wallet Credited!' : '💸 Wallet Debited';
                    const pushMsg = isCredit ? `₹${delta} added by admin.` : `₹${Math.abs(delta)} deducted by admin.`;
                    sendOneSignalPush(pushTitle, pushMsg, isCredit ? 'success' : 'warning', [editingUserId])
                        .then(res => {
                            if (res && !res.ok) showToast('Wallet updated ✅ — but push failed ⚠️', 'warning');
                        })
                        .catch(() => {});
                } else {
                    // শুধু নাম বা UID পরিবর্তন হলে সাধারণ আপডেট
                    await updateDoc(userRef, data);
                }

                closeUserSheet();
                showToast('User updated with ledger record! ✅', 'success');
                loadUsers(false);
            } catch (e) {
                console.error('saveUser error:', e);
                showToast(e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.textContent = 'Save Changes';
            }
        };

        window.toggleBan = function(id, ban, name) {
            showActionSheet(ban ? 'Ban User' : 'Unban User', `${ban?'Ban':'Unban'} ${name}?`, [{
                label: ban ? 'Ban User' : 'Unban User',
                style: ban ? 'destructive' : 'default',
                action: async () => {
                    try {
                        await updateDoc(doc(db, 'users', id), {
                            isBanned: ban
                        });
                        showToast(`User ${ban?'banned':'unbanned'}`, ban ? 'error' : 'success');
                        // FIX: Ban/Unban-এর পর লিস্ট রিফ্রেশ না হলে কার্ড পুরনো স্ট্যাটাসেই থাকত
                        loadUsers(false);
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };

        function loadNotifications() {
            const el = document.getElementById('notifContent');
            if (!el) return;
            el.innerHTML = `
    <div class="spacer"></div>
    <div class="ntf-topbar">
      <div>
        <div class="section-title" style="margin:0;">Sent History</div>
        <div class="ntf-topbar-sub">All push + in-app notifications</div>
      </div>
      <button class="ntf-send-btn" onclick="openNotifSheet()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
        Send New
      </button>
    </div>
    <div id="notifHistoryList">
      <div class="loading-center"><div class="spinner spinner-accent"></div></div>
    </div>`;
            loadNotifHistory(); // পূর্ববর্তী নোটিফিকেশন হিস্ট্রি লোড করবে
        }


// ── FIX 8: DELETE USER ──
        // ══════════════════════════════════════════
        // FIX 8 — DELETE USER COMPLETELY (Auth + Firestore + Cleanup)
        // ══════════════════════════════════════════
// ── DELETE USER (Cloud Function ছাড়া) ──
        // ══════════════════════════════════════════════════════════════
        // Firestore-এর সব ডেটা (profile + notifications) মুছে ফেলা হয়।
        // Auth login অ্যাকাউন্ট ব্রাউজার থেকে মোছা যায় না — Firebase Console
        // → Authentication → Users থেকে ডিলিট করতে হবে (মোবাইল ব্রাউজারেই হয়)।
        // ══════════════════════════════════════════════════════════════
        // FIX 7 — DELETE USER COMPLETELY: type-to-confirm + cascade
        // (profile, wallet txns, withdrawals, payments, teams, UID locks,
        //  notifications) — UI + DB দুটো থেকেই। Auth অ্যাকাউন্ট ব্রাউজার থেকে
        // মোছা যায় না — Firebase Console থেকে ম্যানুয়ালি (নিচে রিমাইন্ডার আছে)।
        window.deleteUser = function(id, name) {
            const displayName = name || 'this user';
            openTypeConfirm({
                eyebrow: 'Danger zone',
                title: 'Delete User Completely?',
                target: displayName,
                desc: `This will <b>permanently delete</b> <b>${esc(displayName)}</b>'s profile, wallet history, withdrawal requests, team registrations, UID locks and notifications \u2014 from the app <b>and</b> the database. This cannot be undone.`,
                expect: (name || '').trim() || 'DELETE',
                confirmLabel: 'Delete User Data',
                onConfirm: async () => {
                    const refs = [];
                    const n = { teams: 0, txns: 0, withdrawals: 0, payments: 0 };

                    // ১. টিম রেজিস্ট্রেশন (captain বা member হিসেবে) + captain lock
                    const teamDocs = new Map();
                    for (const q of [
                        query(collection(db, 'tournamentTeams'), where('captainUserId', '==', id)),
                        query(collection(db, 'tournamentTeams'), where('userId', '==', id))
                    ]) {
                        const s = await getDocs(q);
                        s.forEach(d => teamDocs.set(d.id, d));
                    }
                    const confirmedByTourn = {};
                    teamDocs.forEach(d => {
                        const data = d.data();
                        refs.push(d.ref);
                        n.teams++;
                        const tId = data.tournamentId;
                        if (tId) {
                            refs.push(doc(db, 'tournamentCaptains', `${tId}_${id}`));
                            const st = String(data.status || '').toLowerCase();
                            if (st === 'confirmed' || st === 'approved') {
                                confirmedByTourn[tId] = (confirmedByTourn[tId] || 0) + 1;
                            }
                        }
                    });

                    // ২. UID locks
                    for (const coll of ['tournamentPlayerUIDs', 'registeredUIDs']) {
                        try {
                            const s = await getDocs(query(collection(db, coll), where('userId', '==', id)));
                            s.forEach(d => refs.push(d.ref));
                        } catch (e) { /* collection may not exist */ }
                    }

                    // ৩. টাকার রেকর্ড: wallet ledger, withdrawal requests, entry payments
                    const wSnap = await getDocs(query(collection(db, 'walletTransactions'), where('userId', '==', id)));
                    wSnap.forEach(d => { refs.push(d.ref); n.txns++; });
                    const wdSnap = await getDocs(query(collection(db, 'withdrawalRequests'), where('userId', '==', id)));
                    wdSnap.forEach(d => { refs.push(d.ref); n.withdrawals++; });
                    try {
                        const pSnap = await getDocs(query(collection(db, 'paymentRequests'), where('userId', '==', id)));
                        pSnap.forEach(d => { refs.push(d.ref); n.payments++; });
                    } catch (e) { /* legacy collection may not exist */ }

                    // ৪. notifications subcollection
                    const nSnap = await getDocs(collection(db, 'users', id, 'notifications'));
                    nSnap.forEach(d => refs.push(d.ref));

                    // ৫. user doc — সবার শেষে
                    refs.push(doc(db, 'users', id));

                    // chunked delete (Firestore batch limit 500)
                    for (let i = 0; i < refs.length; i += 450) {
                        const batch = writeBatch(db);
                        refs.slice(i, i + 450).forEach(r => batch.delete(r));
                        await batch.commit();
                    }

                    // ৬. confirmed টিম মুছলে টুর্নামেন্টের slot count ফেরত
                    for (const tId of Object.keys(confirmedByTourn)) {
                        try {
                            const tRef = doc(db, 'tournaments', tId);
                            const tSnap = await getDoc(tRef);
                            if (tSnap.exists()) {
                                const td = tSnap.data();
                                const dec = confirmedByTourn[tId];
                                const newFilled = Math.max(0, Number(td.filledTeams || td.filledSlots || 0) - dec);
                                await updateDoc(tRef, {
                                    filledTeams: newFilled,
                                    filledSlots: newFilled,
                                    filledPlayers: newFilled * Number(td.playersPerTeam || 1)
                                });
                            }
                        } catch (e) { /* best-effort */ }
                    }

                    if (window.logAdminAction) logAdminAction('Delete user', 'users',
                        `${displayName} \u2014 ${n.teams} teams, ${n.txns} wallet txns, ${n.withdrawals} withdrawals, ${n.payments} payments removed`);
                    showToast('User data deleted! 🗑️', 'success');
                    loadUsers(false);
                    showActionSheet('\u098fকটা ধাপ বাকি \u23f3', 'Login অ্যাকাউন্টটাও মুছতে হবে:\nFirebase Console \u2192 Authentication \u2192 Users \u2192 এই email-এর row ডিলিট করো।', [{
                        label: '\u09acুঝেছি',
                        style: 'default',
                        action: () => {}
                    }]);
                }
            });
        };

        // ── APPROVE PENDING STAFF (Staff Panel) ──
        // Staff Panel app-এ যারা signup করে (role='pending-staff'),
        // main admin এখান থেকে approve করলে তারা staff হয়ে withdrawal handle করতে পারবে।
        window.approveStaff = function(id, name) {
            showActionSheet('Approve as Staff?', `"${name}" Staff Panel-এ ঢুকে withdrawal approve/reject করতে পারবে।`, [{
                label: 'Approve Staff',
                style: 'default',
                action: async () => {
                    try {
                        await updateDoc(doc(db, 'users', id), {
                            role: 'staff',
                            updatedAt: serverTimestamp()
                        });
                        if (typeof notifyUserWithPush === 'function') {
                            notifyUserWithPush(id, 'Staff Approved ✅', 'You can now login to the Staff Panel.', 'success').catch(() => {});
                        }
                        showToast('Staff approved! ✅', 'success');
                        loadUsers(false);
                    } catch (e) {
                        console.error('approveStaff error:', e);
                        showToast('Failed: ' + (e.message || e), 'error');
                    }
                }
            }]);
        };
        // ── APPROVE PENDING ADMIN ──
        // "Create Admin Account" ফর্মে যারা রেজিস্টার করে (role='pending'),
        // main admin এখান থেকে approve করলে তারা admin হয়ে যায়।
        window.approveAdmin = function(id, name) {
            showActionSheet('Approve as Admin?', `"${name}" প্যানেলে admin হিসেবে ঢুকতে পারবে।`, [{
                label: 'Approve Admin',
                style: 'default',
                action: async () => {
                    try {
                        await updateDoc(doc(db, 'users', id), {
                            role: 'admin',
                            isAdmin: true,
                            updatedAt: serverTimestamp()
                        });
                        if (typeof notifyUserWithPush === 'function') {
                            notifyUserWithPush(id, 'Admin Approved ✅', 'You can now login to the admin panel.', 'success').catch(() => {});
                        }
                        showToast('Admin approved! ✅', 'success');
                        loadUsers(false);
                    } catch (e) {
                        console.error('approveAdmin error:', e);
                        showToast('Failed: ' + (e.message || e), 'error');
                    }
                }
            }]);
        };






// ╔══════════════════════════════════════════════════════════════╗
        // ║ ✅ [ইউজার রিডিজাইন ৩] শুরু — renderUsers() এর জায়গায়              ║
        // ║ (পুরনো "RENDER USERS WITH TOURNAMENT COUNT" কমেন্ট থেকে ফাইলের শেষ)  ║
        // ╚══════════════════════════════════════════════════════════════╝
        function renderUsers(list) {
            const el = document.getElementById('usersList');
            if (!el) return;

            // হেডারের টাইটেল ফাঁকা থাকলে ভরে দেয়
            const hdrTitle = document.querySelector('#screen-users [data-header-title]');
            if (hdrTitle && !hdrTitle.textContent.trim()) hdrTitle.textContent = 'Users';

            if (!list || list.length === 0) { usersShowEmpty(el); return; }

            el.innerHTML = `<div class="us-sec"><h3>${usersSearchQuery ? 'Results' : 'Players'}</h3><span class="us-count">${list.length}${(!usersSearchQuery && list.length % 20 === 0) ? '+' : ''}</span></div>
    <div class="us-list">${list.map(usersCardHTML).join('')}</div>`;

            // প্রতিটা ইউজারের লাইভ টুর্নামেন্ট কাউন্ট (আগের লজিক হুবহু, শুধু সংখ্যা বসায়)
            list.forEach(u => {
                getDocs(query(collection(db, 'tournamentTeams'), where('captainUserId', '==', u.id), where('status', '==', 'confirmed'))).then(snap => {
                    const c = document.getElementById('userTourCount-' + u.id);
                    if (c) c.textContent = snap.size;
                }).catch(() => {
                    const c = document.getElementById('userTourCount-' + u.id);
                    if (c) c.textContent = (u.joinedTournaments || []).length;
                });
            });
        }

        function usersCardHTML(u) {
            const name = u.name || 'Unknown';
            const isAdmin = u.role === 'admin';
            const banned = !!u.isBanned;
            const joinedDate = u.createdAt ? (u.createdAt.toDate ? u.createdAt.toDate() : new Date(u.createdAt)) : null;
            const joinedStr = joinedDate && !isNaN(joinedDate) ? joinedDate.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
            const uid = u.ffUID || '';
            return `<article class="us-card ${isAdmin ? 'is-admin' : ''} ${banned ? 'is-banned' : ''}">
      <div class="us-top">
        <div class="us-avatar">${esc(name.trim().charAt(0).toUpperCase() || '?')}</div>
        <div class="us-who">
          <div class="us-name-row"><span class="us-name">${esc(name)}</span>${isAdmin ? '<span class="us-admin">Admin</span>' : ''}${u.role === 'pending' ? '<span class="us-admin" style="background:rgba(255, 213, 74,.15);color:#ffd54a;border-color:rgba(255, 213, 74,.35);">Pending</span>' : ''}${u.role === 'pending-staff' ? '<span class="us-admin" style="background:rgba(56, 189, 248,.15);color:#38BDF8;border-color:rgba(56, 189, 248,.35);">Pending Staff</span>' : ''}${u.role === 'staff' ? '<span class="us-admin" style="background:rgba(56, 189, 248,.15);color:#38BDF8;border-color:rgba(56, 189, 248,.35);">Staff</span>' : ''}</div>
          <div class="us-email">${esc(u.email || '—')}</div>
        </div>
        <span class="us-pill ${banned ? 'banned' : 'active'}"><i></i>${banned ? 'Banned' : 'Active'}</span>
      </div>

      <div class="us-stats">
        <div><strong>₹${(u.walletBalance || 0).toLocaleString('en-IN')}</strong><span>Wallet</span></div>
        <div><strong id="userTourCount-${esc(u.id)}">–</strong><span>Tournaments</span></div>
        <div><strong>${u.totalWins || 0}</strong><span>Wins</span></div>
      </div>

      <div class="us-meta">
        <span class="us-uid">FF UID <b>${esc(uid || 'No UID')}</b>${uid ? `<button class="us-copy" data-copy="${esc(uid)}" onclick="usersCopy(this)" aria-label="Copy FF UID">${US_ICONS.copy}</button>` : ''}</span>
        <span>Joined ${joinedStr}</span>
      </div>

      <div class="us-actions">
        ${u.role === 'pending' ? `<button class="us-btn us-btn-edit" onclick="usersAct('approve','${esc(u.id)}')">✅ Approve Admin</button>` : ''}
        ${u.role === 'pending-staff' ? `<button class="us-btn us-btn-edit" onclick="usersAct('approveStaff','${esc(u.id)}')">✅ Approve Staff</button>` : ''}
        <button class="us-btn us-btn-edit" onclick="usersAct('edit','${esc(u.id)}')">${US_ICONS.edit}Edit</button>
        <button class="us-btn us-btn-ban ${banned ? 'is-unban' : ''}" onclick="usersAct('ban','${esc(u.id)}')">${banned ? US_ICONS.check + 'Unban' : US_ICONS.ban + 'Ban'}</button>
        <button class="us-btn us-btn-del" onclick="usersAct('delete','${esc(u.id)}')" aria-label="Delete user">${US_ICONS.trash}</button>
      </div>
    </article>`;
        }

        // Edit/Ban/Delete: শুধু id পাঠানো হয়, বাকি ডেটা allUsers থেকে নেয়
        // (আগের বাগ ফিক্স: নামে ' থাকলে onclick ভেঙে যেত)
        window.usersAct = function(kind, id) {
            const u = allUsers.find(x => x.id === id);
            if (!u) { showToast('User not found. Reload the list.', 'error'); return; }
            if (kind === 'edit') openUserSheet({ id: u.id, name: u.name || '', email: u.email || '', ffUID: u.ffUID || '', walletBalance: u.walletBalance || 0, totalWins: u.totalWins || 0, role: u.role || 'user', isBanned: !!u.isBanned });
            else if (kind === 'ban') toggleBan(u.id, !u.isBanned, u.name || '');
            else if (kind === 'delete') deleteUser(u.id, u.name || '');
            else if (kind === 'approve') approveAdmin(u.id, u.name || '');
            else if (kind === 'approveStaff') approveStaff(u.id, u.name || '');
        };

        window.usersCopy = function(btn) {
            const text = btn.dataset.copy || '';
            const done = () => { btn.classList.add('done'); btn.innerHTML = US_ICONS.check; setTimeout(() => { btn.classList.remove('done'); btn.innerHTML = US_ICONS.copy; }, 1400); };
            const fallback = () => {
                const t = document.createElement('textarea');
                t.value = text; t.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
                document.body.appendChild(t); t.select();
                try { document.execCommand('copy') ? done() : showToast('Copy failed', 'error'); } catch (e) { showToast('Copy failed', 'error'); }
                t.remove();
            };
            if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(done).catch(fallback); else fallback();
        };

        function usersShowEmpty(el) {
            const searching = !!usersSearchQuery;
            el.innerHTML = `<div class="us-empty"><div class="us-empty-ic">${US_ICONS.users}</div><h4>${searching ? 'No matching users' : 'No users yet'}</h4><p>${searching ? 'Search needs the exact name, email or FF UID.' : 'New players will show up here after they sign up.'}</p></div>`;
        }
        // ✅ [ইউজার রিডিজাইন ৩] শেষ
