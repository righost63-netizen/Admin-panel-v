// ── TOURNAMENT REMINDER NOTIFICATION ──
        // ══════════════════════════════════════════
        // NEW — TOURNAMENT REMINDER NOTIFICATION
        // ══════════════════════════════════════════
        window.openReminderSheet = async function() {
            // আগের container থাকলে সরাও
            document.getElementById('reminderSheetContainer')?.remove();
            const container = document.createElement('div');
            container.id = 'reminderSheetContainer';
            // upcoming/ongoing tournament লোড
            let tourOptions = '<option value="">— Select Tournament —</option>';
            let tlist = [];
            try {
                let snap;
                try {
                    snap = await getDocs(query(collection(db, 'tournaments'), where('status', 'in', ['upcoming', 'ongoing']), orderBy('createdAt', 'desc'), limit(30)));
                } catch (indexErr) {
                    // FIX: composite index না থাকলে orderBy ছাড়া fallback (আগে ড্রপডাউন ফাঁকা থাকত)
                    console.warn('Reminder: index missing, fallback query:', indexErr.message);
                    snap = await getDocs(query(collection(db, 'tournaments'), where('status', 'in', ['upcoming', 'ongoing']), limit(30)));
                }
                if (!snap.empty) {
                    // FIX: ড্রপডাউনে t.date/t.time দেখাত, কিন্তু টুর্নামেন্টে এখন dateTime/dateString থাকে
                    tlist = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                    const ts = v => (v && v.toMillis) ? v.toMillis() : new Date(v || 0).getTime();
                    tlist.sort((a, b) => ts(b.dateTime) - ts(a.dateTime));
                    tlist.forEach(t => {
                        const when = t.dateString || t.date || '';
                        const wtime = t.timeString || t.time || '';
                        tourOptions += `<option value="${t.id}">${esc(t.name||'Unnamed')} — ${esc(when)} ${esc(wtime)}</option>`;
                    });
                }
            } catch (e) {
                console.error('Reminder: load tournaments error:', e);
                showToast('Could not load tournaments: ' + e.message, 'warning');
            }
            container.innerHTML = `
  <div class="sheet-overlay visible" onclick="document.getElementById('reminderSheetContainer').remove()"></div>
  <div class="bottom-sheet visible rm-sheet" style="max-height:92dvh;">
    <div class="sheet-handle"></div>
    <div class="rm-hero">
      <div class="rm-hero-ic">⏰</div>
      <div class="rm-hero-main">
        <div class="rm-hero-title">Tournament Reminder</div>
        <div class="rm-hero-sub">Send a reminder to players — they'll get it instantly</div>
      </div>
      <button class="sheet-close rm-close" onclick="document.getElementById('reminderSheetContainer').remove()" aria-label="Close">✕</button>
    </div>
    <div class="sheet-body">
      <div class="rm-sec">
        <div class="rm-sec-title"><span class="rm-sec-ic">🏆</span>Tournament</div>
        <div class="form-group" style="margin-bottom:0;">
          <div class="rm-select-wrap">
            <select class="form-select rm-select" id="reminderTournSelect" onchange="rmTournamentChanged()">${tourOptions}</select>
          </div>
          <div class="rm-tourn-meta" id="rmTournMeta" hidden></div>
        </div>
      </div>
      <div class="rm-sec">
        <div class="rm-sec-title"><span class="rm-sec-ic">✉️</span>Message</div>
        <div class="form-group">
          <label class="form-label">Reminder Title</label>
          <input class="form-input rm-input" id="reminderTitle" type="text" placeholder="e.g. ⏰ Tournament শুরু হতে ৩০ মিনিট বাকি!" value="⏰ Tournament Reminder!" oninput="rmPreviewUpdate()">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Reminder Message</label>
          <textarea class="form-textarea rm-msg-area" id="reminderMsg" placeholder="Tournament শুরু হতে আর বেশি সময় নেই। রুম আইডি চেক করুন এবং প্রস্তুত থাকুন!" oninput="rmPreviewUpdate()">Tournament শুরু হতে আর বেশি সময় নেই। রুম আইডি চেক করুন এবং প্রস্তুত থাকুন!</textarea>
          <div class="rm-area-hint">যা লিখবেন, প্লেয়ারদের কাছে হুবহু তাই যাবে</div>
        </div>
      </div>
      <div class="rm-sec">
        <div class="rm-sec-title"><span class="rm-sec-ic">🎯</span>Target Players</div>
        <div class="segmented rm-seg">
          <button class="seg-btn active" id="remBtn-accepted" onclick="selectReminderTarget(this,'accepted')">✅ Accepted</button>
          <button class="seg-btn" id="remBtn-all" onclick="selectReminderTarget(this,'all')">👥 All Players</button>
        </div>
      </div>
      <div class="rm-preview-label">Live Preview <span>— user app-এ এভাবে দেখাবে</span></div>
      <div class="rm-preview">
        <div class="rm-preview-ic">⏰</div>
        <div class="rm-preview-main">
          <div class="rm-preview-title" id="rmPrevTitle">⏰ Tournament Reminder!</div>
          <div class="rm-preview-msg" id="rmPrevMsg">Tournament শুরু হতে আর বেশি সময় নেই। রুম আইডি চেক করুন এবং প্রস্তুত থাকুন!</div>
          <div class="rm-preview-time">now</div>
        </div>
      </div>
      <button class="btn-primary rm-send" id="sendReminderBtn" onclick="sendTournamentReminder()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
        Send Reminder
      </button>
      <div style="height:8px;"></div>
    </div>
  </div>`;
            document.body.appendChild(container);
            window._reminderTarget = 'accepted';
            window._reminderTourns = tlist || [];
            rmPreviewUpdate();
        };

        // Tournament select হলে meta line + preview আপডেট
        window.rmTournamentChanged = function() {
            const sel = document.getElementById('reminderTournSelect');
            const meta = document.getElementById('rmTournMeta');
            if (!sel || !meta) return;
            const t = (window._reminderTourns || []).find(x => x.id === sel.value);
            if (t) {
                meta.hidden = false;
                meta.innerHTML = `<span class="rm-meta-chip">📅 ${esc(t.dateString || t.date || '—')}</span>
                  <span class="rm-meta-chip">⏰ ${esc(t.timeString || t.time || '—')}</span>
                  <span class="rm-meta-chip">🎮 ${esc(t.gameMode || '')}</span>`;
            } else {
                meta.hidden = true;
                meta.innerHTML = '';
            }
        };

        window.rmPreviewUpdate = function() {
            const title = document.getElementById('reminderTitle')?.value.trim();
            const msg = document.getElementById('reminderMsg')?.value.trim();
            const pt = document.getElementById('rmPrevTitle');
            const pm = document.getElementById('rmPrevMsg');
            if (pt) pt.textContent = title || '—';
            if (pm) pm.textContent = msg || '—';
        };

        window.selectReminderTarget = function(btn, target) {
            window._reminderTarget = target;
            document.querySelectorAll('[id^=remBtn-]').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        };

        window.sendTournamentReminder = async function() {
            const tid = document.getElementById('reminderTournSelect')?.value;
            const title = document.getElementById('reminderTitle')?.value.trim();
            const msg = document.getElementById('reminderMsg')?.value.trim();
            if (!tid) {
                showToast('Tournament select করুন', 'warning');
                return;
            }
            if (!title || !msg) {
                showToast('Title ও Message দিন', 'warning');
                return;
            }
            const btn = document.getElementById('sendReminderBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
            try {
                const target = window._reminderTarget || 'accepted';
                // FIX (BUILD 16): dead 'accepted' status সরানো হলো — আসল status 'confirmed'
                // (money-flow contract: pending / confirmed / rejected)
                const wantStatuses = target === 'all' ? ['pending', 'confirmed'] : ['confirmed'];
                let teamDocs;
                try {
                    const snap = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', tid), where('status', 'in', wantStatuses)));
                    teamDocs = snap.docs;
                } catch (indexErr) {
                    // FIX (BUILD 16): composite index (tournamentId + status) না থাকলে
                    // FAILED_PRECONDITION-এ মরত — এখন fallback: শুধু tournamentId দিয়ে এনে client-side filter
                    console.warn('Reminder send: index missing, fallback query:', indexErr.message);
                    const s2 = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', tid)));
                    teamDocs = s2.docs.filter(d => wantStatuses.includes(d.data().status));
                }
                if (!teamDocs.length) {
                    showToast('কোনো player পাওয়া যায়নি', 'warning');
                    btn.disabled = false;
                    btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
        Send Reminder`;
                    return;
                }
                const batch = writeBatch(db);
                let count = 0;
                teamDocs.forEach(d => {
                    const userId = d.data().captainUserId || d.data().userId;
                    if (userId) {
                        const notifRef = doc(collection(db, 'users', userId, 'notifications'));
                        batch.set(notifRef, {
                            title,
                            message: msg,
                            type: 'warning',
                            read: false,
                            createdAt: serverTimestamp()
                        });
                        count++;
                    }
                });
                await batch.commit();
                // Send push notification to players
                // FIX: tournamentTeams ডকে captain-এর id থাকে captainUserId-তে (userId নয়) —
                // আগে reminderPushIds সবসময় ফাঁকা থাকত, push যেত না।
                const reminderPushIds = teamDocs.map(d => d.data().captainUserId || d.data().userId).filter(Boolean);
                // FIX (BUILD 16): honest push result
                let pushRes = null;
                if (reminderPushIds.length) {
                    pushRes = await sendOneSignalPush(title, msg, 'warning', reminderPushIds)
                        .catch(err => ({ ok: false, error: String((err && err.message) || err) }));
                }
                // log
                await addDoc(collection(db, 'notifLog'), {
                    title,
                    message: msg,
                    type: 'warning',
                    target: 'tournament_reminder',
                    tournamentId: tid,
                    sentAt: serverTimestamp(),
                    sentBy: 'admin'
                });
                if (pushRes && !pushRes.ok) {
                    showToast(`⚠️ ${count} জনকে in-app reminder গেছে, কিন্তু push FAILED — OneSignal Settings check করো`, 'warning');
                } else {
                    showToast(`✅ ${count} জন player কে reminder পাঠানো হয়েছে!`, 'success');
                }
                document.getElementById('reminderSheetContainer')?.remove();
            } catch (e) {
                console.error('sendTournamentReminder error:', e);
                showToast(e.message, 'error');
                btn.disabled = false;
                btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
        Send Reminder`;
            }
        };



