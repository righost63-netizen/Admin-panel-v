// 📁 scripts/screens/participants-free.js
function ptCardHTMLFree(item) {
    const teamId = item.teamId || item.id;
    const status = (item.status || 'pending').toLowerCase();
    const isLocked = item.locked === true;
    const pcls = (status === 'confirmed' || status === 'approved') ? 'ok' : status === 'rejected' ? 'bad' : status === 'pending' ? 'wait' : 'neutral';
    const players = item.players || [];

    const rows = players.map((p, idx) => `<div class="pt-player">
        <span class="pt-pav">${esc((p.playerName || 'P').trim().charAt(0).toUpperCase() || 'P')}</span>
        <div class="pt-pmain"><div class="pt-pname">${esc(p.playerName || 'Player')}${(idx === 0 && players.length > 1) ? '<span class="pt-cap">Captain</span>' : ''}</div>
        <div class="pt-puid">UID ${esc(p.ffUID || '—')}</div></div>
        <span class="pt-pid">${esc((p.userId || '').substring(0, 8))}</span></div>`).join('');

    // ✂️ ফ্রী ট্যুরে confirm/reject নেই — অটো-জয়েন হয়ে যায়, এডমিন শুধু চাইলে Remove করবে
    const action = `<div class="pt-acts one">
        <button class="pt-btn pt-btn-bad" onclick="kickParticipant('${item.id}')">${PT_ICONS.x}Remove Player</button>
    </div>`;

    return `<article class="pt-card">
      <div class="pt-top">
        <div><div class="pt-team">${esc(item.teamName || 'Solo Player')}</div><div class="pt-tid">${esc(teamId)}</div></div>
        <span class="pt-pill ${pcls}"><i></i>${esc(ptCap(status))}</span>
      </div>
      <span class="pt-lock ${isLocked ? 'on' : ''}">${isLocked ? PT_ICONS.lock + 'Locked' : PT_ICONS.unlock + 'Open'}</span>
      <div class="pt-players">${rows}</div>
      <div class="pt-slot">
        <span class="pt-slot-tag ${item.roomSlot ? 'has' : ''}">${PT_ICONS.target}${item.roomSlot ? 'Slot ' + String(item.roomSlot).padStart(2, '0') : 'No slot'}</span>
        <div class="pt-slot-btns">
          <button class="pt-mini" onclick="ptAct('slot','${item.id}')">Slot</button>
          <button class="pt-mini ${isLocked ? 'warn' : ''}" onclick="toggleTeamLock('${item.id}', ${!isLocked})">${isLocked ? PT_ICONS.unlock + 'Unlock' : PT_ICONS.lock + 'Lock'}</button>
        </div>
      </div>
      ${action}
    </article>`;
}

// ✂️ Remove Player — টিমকে ট্যুর্নামেন্ট থেকে সম্পূর্ণ ডিলিট করে, স্লট ফ্রি করে, joinedTournaments থেকে সরায়
window.kickParticipant = function(docId) {
    const it = allParticipantsData.find(x => x.id === docId);
    const teamName = it?.teamName || 'this player';
    showActionSheet('Remove Player?', `"${teamName}" will be removed from this tournament and the slot will be freed.`, [{
        label: 'Remove Player',
        style: 'destructive',
        action: async () => {
            try {
                const teamRef = doc(db, 'tournamentTeams', docId);
                const teamSnap = await getDoc(teamRef);
                if (!teamSnap.exists()) { showToast('Participant not found', 'error'); return; }
                const teamData = teamSnap.data();
                const wasConfirmed = (teamData.status || '').toLowerCase() === 'confirmed';
                const tournId = teamData.tournamentId || currentTournForParticipants;
                const captainId = teamData.captainUserId;
                const tourRef = tournId ? doc(db, 'tournaments', tournId) : null;
                const userRef = captainId ? doc(db, 'users', captainId) : null;
                const lockRef = captainId && tournId ? doc(db, 'tournamentCaptains', `${tournId}_${captainId}`) : null;

                await runTransaction(db, async (transaction) => {
                    if (wasConfirmed && tourRef) {
                        const tourSnap = await transaction.get(tourRef);
                        if (tourSnap.exists()) {
                            const tData = tourSnap.data();
                            const filled = Number(tData.filledTeams || tData.filledSlots || 0);
                            const newFilled = Math.max(0, filled - 1);
                            transaction.update(tourRef, { filledTeams: newFilled, filledSlots: newFilled, filledPlayers: newFilled * (tData.playersPerTeam || 1) });
                        }
                    }
                    transaction.delete(teamRef);
                    if (userRef) transaction.update(userRef, { joinedTournaments: arrayRemove(tournId) });
                    if (lockRef) transaction.delete(lockRef);
                    // ✅ FIX: প্লেয়ার UID লকগুলো 'rejected' করা হচ্ছে, যাতে এই FF UID
                    // দিয়ে আবার একই টুর্নামেন্টে জয়েন করা যায়।
                    (teamData.players || []).forEach(p => {
                        const ffUID = String(p?.ffUID || '').trim();
                        if (ffUID && tournId) {
                            transaction.set(
                                doc(db, 'tournamentPlayerUIDs', `${tournId}_${ffUID}`),
                                { status: 'rejected', updatedAt: serverTimestamp() },
                                { merge: true }
                            );
                        }
                    });
                });

                if (captainId) notifyUserWithPush(captainId, 'Removed from Tournament', `You have been removed from "${currentTournObj?.name || 'the tournament'}" by admin.`, 'warning');
                showToast('Player removed from tournament', 'success');
                await refreshParticipants();
            } catch (e) { showToast('Error: ' + e.message, 'error'); }
        }
    }]);
};