        // ══════════════════════════════════════════
        // DASHBOARD — premium redesign (BUILD 13)
        // Read-only overview screen. No approve/reject/send/create actions here —
        // only navigation to other tabs via switchTab().
        // Cost design: aggregations (count/sum) + sessionStorage 5-min cache.
        // Real-time listeners only: pending teams, pending withdrawals, 2 recent feeds.
        // ══════════════════════════════════════════
        function loadDashboard() {
            if (window._dashBooted) { dashEnter(); return; }
            window._dashBooted = true;
            dashBoot();
            dashEnter();
        }

        /* ───────────────────────── boot (once) ───────────────────────── */
        function dashBoot() {
            const el = document.getElementById('dashContent');
            if (!el) return;

            const hr = new Date().getHours();
            const greet = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
            const adminName = currentUser?.name || currentUser?.displayName ||
                (auth.currentUser?.email || '').split('@')[0] || 'Admin';
            const dateStr = new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
            const skel = '<div class="pd-skel"></div><div class="pd-skel"></div><div class="pd-skel"></div>';

            el.innerHTML = `
    <div class="pd pd-dash">
      <header class="pd-top">
        <div>
          <p class="pd-greet-sub">${greet}</p>
          <h2 class="pd-greet-name">${esc(adminName)}</h2>
          <p class="pd-date">${esc(dateStr)}</p>
        </div>
        <button class="pd-bell" onclick="switchTab('notifications')" aria-label="Notifications">
          <svg class="ic"><use href="#i-bell"/></svg>
          <span class="pd-bell-badge" id="dashBellBadge" hidden></span>
        </button>
      </header>

      <div class="pd-range" role="tablist" aria-label="Date range">
        <button data-drange="today" class="on" role="tab">Today</button>
        <button data-drange="7d" role="tab">7 days</button>
        <button data-drange="30d" role="tab">30 days</button>
      </div>

      <section class="pd-hero" aria-label="Revenue">
        <div class="pd-hero-row">
          <span class="pd-hero-label" id="dashRevLabel">Revenue collected</span>
          <span class="pd-delta" id="dashRevDelta" hidden></span>
        </div>
        <div class="pd-hero-value pd-num" id="dashRevenue">—</div>
        <svg class="pd-spark" id="dashSpark" viewBox="0 0 300 64" preserveAspectRatio="none" aria-hidden="true"></svg>
        <div class="pd-hero-stats">
          <div><strong class="pd-num" id="dashCollected">—</strong><span>Collected</span></div>
          <div><strong class="pd-num" id="dashPaidOut">—</strong><span>Paid out</span></div>
          <div><strong class="pd-num" id="dashNet">—</strong><span>Net profit</span></div>
        </div>
      </section>

      <div class="pd-sec"><h3>Needs attention</h3></div>
      <div id="dashAttention">${skel}</div>

      <div class="pd-sec"><h3>Tournaments</h3><button class="pd-link" onclick="switchTab('tournaments')">View all</button></div>
      <div id="dashLive"></div>
      <div id="dashNext"></div>

      <div class="pd-sec"><h3>Key numbers</h3></div>
      <div class="pd-grid" id="dashKeys">${skel}${skel}</div>

      <div class="pd-sec"><h3>Registrations · last 7 days</h3></div>
      <div class="pd-card"><svg class="pd-bars" id="dashBars" viewBox="0 0 320 110" aria-hidden="true"></svg><div class="pd-bars-legend" id="dashBarsLegend"></div></div>

      <div class="pd-sec"><h3>Money flow</h3></div>
      <div id="dashMoney">${skel}</div>

      <div class="pd-sec"><h3>Recent activity</h3></div>
      <div class="pd-chips" id="dashChips" role="tablist" aria-label="Activity filter">
        <button data-dchip="all" class="on">All</button>
        <button data-dchip="team">Teams</button>
        <button data-dchip="money">Money</button>
        <button data-dchip="tour">Tournaments</button>
      </div>
      <div class="pd-list" id="dashFeed">${skel}</div>
    </div>`;

            el.querySelectorAll('[data-drange]').forEach(b => {
                b.addEventListener('click', () => dashSetRange(b.dataset.drange));
            });
            el.querySelectorAll('[data-dchip]').forEach(b => {
                b.addEventListener('click', () => {
                    el.querySelectorAll('[data-dchip]').forEach(x => x.classList.remove('on'));
                    b.classList.add('on');
                    window._dashChip = b.dataset.dchip;
                    dashRenderFeed();
                });
            });
            window._dashChip = 'all';
            window._dashRange = 'today';

            // tournaments cache pub/sub — registered ONCE (no duplicate listeners)
            if (!window._dashStatsReg) {
                window._dashStatsReg = true;
                (window.tournamentsUpdateListeners = window.tournamentsUpdateListeners || []).push(dashOnTournaments);
            }

            // Patch navigation once: unsubscribe + clear timer when leaving dashboard,
            // re-enter cleanly when coming back. Nothing outside dashboard.js is edited.
            if (!window._dashNavPatched) {
                window._dashNavPatched = true;
                const _st = window.switchTab, _ss = window.showScreen;
                if (typeof _st === 'function') {
                    window.switchTab = function (t) {
                        const was = window._dashActive;
                        const r = _st.apply(this, arguments);
                        dashNav(was, t);
                        return r;
                    };
                }
                if (typeof _ss === 'function') {
                    window.showScreen = function (n) {
                        const was = window._dashActive;
                        const r = _ss.apply(this, arguments);
                        dashNav(was, n);
                        return r;
                    };
                }
            }
            window._dashActive = true;
        }

        function dashNav(wasDash, nowTab) {
            const isDash = nowTab === 'dashboard';
            if (wasDash && !isDash) dashLeave();
            else if (!wasDash && isDash && window._dashBooted) dashEnter();
            window._dashActive = isDash;
        }

        /* ─────────────────────── enter / leave ─────────────────────── */
        function dashEnter() {
            if (window._dashEntered) return;
            window._dashEntered = true;
            window._dashActive = true;
            window._dashUnsubs = [];

            const sub = fn => { const u = fn(); window._dashUnsubs.push(u); listeners.push(u); };

            // 1) pending teams — count + oldest wait + expected entry fee (all from these docs)
            // FIX (2026-10-07): limit(200) — unbounded pending listener-এর read কমাতে।
            // 200-এর বেশি pending জমলে badge-এ "200+" দেখাবে; আসল list আলাদা screen-এ page-by-page load হয়।
            sub(() => onSnapshot(query(collection(db, 'tournamentTeams'), where('status', '==', 'pending'), limit(200)), snap => {
                window._dashPendingTeams = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                dashRenderAttention();
                dashRenderMoney();
                const badge = document.getElementById('pendingBadge');
                if (badge) { badge.textContent = snap.size >= 200 ? '200+' : snap.size; badge.style.display = snap.size > 0 ? 'flex' : 'none'; }
            }, err => console.error('dash pending teams:', err)));

            // 2) pending withdrawals — count + total amount
            // FIX (2026-10-07): limit(200) — same reason as above.
            sub(() => onSnapshot(query(collection(db, 'withdrawalRequests'), where('status', '==', 'pending'), limit(200)), snap => {
                window._dashPendingWd = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                dashRenderAttention();
                dashRenderMoney();
                const badge = document.getElementById('withdrawBadge');
                if (badge) { badge.textContent = snap.size >= 200 ? '200+' : snap.size; badge.style.display = snap.size > 0 ? 'flex' : 'none'; }
            }, err => console.error('dash pending withdrawals:', err)));

            // 3) recent teams feed
            sub(() => onSnapshot(query(collection(db, 'tournamentTeams'), orderBy('createdAt', 'desc'), limit(10)), snap => {
                window._dashRecentTeams = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                dashRenderFeed();
            }, err => console.error('dash recent teams:', err)));

            // 4) recent withdrawals feed
            sub(() => onSnapshot(query(collection(db, 'withdrawalRequests'), orderBy('requestedAt', 'desc'), limit(10)), snap => {
                window._dashRecentWd = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                dashRenderFeed();
            }, err => console.error('dash recent withdrawals:', err)));

            // tournaments cache (NO second listener — one-time fallback only)
            if (window.allTournamentsCache && window.allTournamentsCache.length) {
                dashOnTournaments(window.allTournamentsCache);
            } else {
                getDocs(collection(db, 'tournaments')).then(snap => {
                    const all = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                    window.allTournamentsCache = all;
                    dashOnTournaments(all);
                }).catch(e => console.error('dashboard initial tournaments fetch failed:', e));
            }

            dashLoadRange(window._dashRange || 'today');
            dashLoadReg7();
            dashLoadPaidMonth();
            dashLoadUsersTotal();
            dashStartCountdown();
        }

        function dashLeave() {
            window._dashEntered = false;
            window._dashActive = false;
            (window._dashUnsubs || []).forEach(u => { try { u(); } catch (e) {} });
            window._dashUnsubs = [];
            if (window._dashTimer) { clearInterval(window._dashTimer); window._dashTimer = null; }
        }

        function dashOnTournaments(all) {
            window._dashTournCache = all;
            dashRenderTournaments(all);
            dashRenderAttention();
            dashRenderKeys();
            dashRenderFeed();
        }

        /* ─────────────────────── range tabs ─────────────────────── */
        function dashSetRange(r) {
            if (window._dashRange === r) return;
            window._dashRange = r;
            document.querySelectorAll('[data-drange]').forEach(b => b.classList.toggle('on', b.dataset.drange === r));
            dashLoadRange(r);
        }

        function dashRangeBounds(range) {
            const now = new Date();
            const start = new Date(now);
            if (range === 'today') start.setHours(0, 0, 0, 0);
            else { start.setDate(start.getDate() - (range === '7d' ? 6 : 29)); start.setHours(0, 0, 0, 0); }
            const len = now.getTime() - start.getTime();
            const prevEnd = new Date(start.getTime() - 1);
            const prevStart = new Date(start.getTime() - len);
            return {
                start: Timestamp.fromDate(start), end: Timestamp.fromDate(now),
                prevStart: Timestamp.fromDate(prevStart), prevEnd: Timestamp.fromDate(prevEnd),
                startDate: start, endDate: now
            };
        }

        function dashCacheGet(k) {
            try {
                const o = JSON.parse(sessionStorage.getItem(k));
                if (o && Date.now() - o.ts < 5 * 60 * 1000) return o.data;
            } catch (e) {}
            return null;
        }
        function dashCacheSet(k, d) {
            try { sessionStorage.setItem(k, JSON.stringify({ ts: Date.now(), data: d })); } catch (e) {}
        }

        async function dashSum(coll, field, f, t) {
            // f/t: {statusField,statusVal,dateField,from,to} — aggregation, ~1 read
            const snap = await getAggregateFromServer(
                query(collection(db, coll),
                    where(f.statusField, '==', f.statusVal),
                    where(f.dateField, '>=', f.from), where(f.dateField, '<=', f.to)),
                { total: sum(field) });
            return Number(snap.data().total) || 0;
        }
        async function dashCount(coll, dateField, from, to) {
            const q = dateField
                ? query(collection(db, coll), where(dateField, '>=', from), where(dateField, '<=', to))
                : collection(db, coll);
            const snap = await getCountFromServer(q);
            return Number(snap.data().count) || 0;
        }

        async function dashLoadRange(range) {
            const b = dashRangeBounds(range);
            const key = 'dash_range_' + range;
            const cached = dashCacheGet(key);
            if (cached) { dashRenderRange(range, cached); return; }
            dashRangeSkeleton(true);
            try {
                // Revenue collected = approved payments by reviewedAt (real money in).
                let revenue = 0, revenuePrev = 0, estimated = false;
                try {
                    [revenue, revenuePrev] = await Promise.all([
                        dashSum('paymentRequests', 'amount', { statusField: 'status', statusVal: 'approved', dateField: 'reviewedAt', from: b.start, to: b.end }),
                        dashSum('paymentRequests', 'amount', { statusField: 'status', statusVal: 'approved', dateField: 'reviewedAt', from: b.prevStart, to: b.prevEnd })
                    ]);
                } catch (e) {
                    // Fallback (e.g. index missing): estimate from cached tournaments.
                    console.warn('dash revenue sum failed, using estimate:', e.message);
                    estimated = true;
                    const all = window._dashTournCache || window.allTournamentsCache || [];
                    const inR = t => { const d = dashTsToDate(t.createdAt); return d && d >= b.startDate && d <= b.endDate; };
                    revenue = all.filter(inR).reduce((a, t) => a + (t.filledSlots || t.filledTeams || 0) * (t.entryFee || 0), 0);
                    revenuePrev = 0;
                }
                const [paid, paidPrev, regs, regsPrev, newUsers, newUsersPrev] = await Promise.all([
                    dashSum('withdrawalRequests', 'amount', { statusField: 'status', statusVal: 'approved', dateField: 'resolvedAt', from: b.start, to: b.end }).catch(e => (console.warn('dash paid sum failed:', e.message), 0)),
                    dashSum('withdrawalRequests', 'amount', { statusField: 'status', statusVal: 'approved', dateField: 'resolvedAt', from: b.prevStart, to: b.prevEnd }).catch(() => 0),
                    dashCount('tournamentTeams', 'createdAt', b.start, b.end).catch(() => 0),
                    dashCount('tournamentTeams', 'createdAt', b.prevStart, b.prevEnd).catch(() => 0),
                    dashCount('users', 'createdAt', b.start, b.end).catch(() => 0),
                    dashCount('users', 'createdAt', b.prevStart, b.prevEnd).catch(() => 0)
                ]);
                // sparkline buckets (parallel — one aggregate read each)
                const buckets = range === 'today' ? 6 : range === '7d' ? 7 : 10;
                const span = b.endDate.getTime() - b.startDate.getTime();
                const pts = await Promise.all(Array.from({ length: buckets }, (_, i) => {
                    const bs = new Date(b.startDate.getTime() + (span / buckets) * i);
                    const be = new Date(b.startDate.getTime() + (span / buckets) * (i + 1));
                    return dashSum('paymentRequests', 'amount',
                        { statusField: 'status', statusVal: 'approved', dateField: 'reviewedAt', from: Timestamp.fromDate(bs), to: Timestamp.fromDate(be) })
                        .catch(() => 0);
                }));
                const data = { revenue, revenuePrev, paid, paidPrev, regs, regsPrev, newUsers, newUsersPrev, pts, estimated };
                dashCacheSet(key, data);
                dashRenderRange(range, data);
            } catch (e) {
                console.error('dashLoadRange:', e);
                dashRangeSkeleton(false);
                const lbl = document.getElementById('dashRevLabel');
                if (lbl) lbl.textContent = 'Revenue — failed to load';
            }
        }

        function dashRenderRange(range, d) {
            const set = (id, v) => { const n = document.getElementById(id); if (n) n.textContent = v; };
            const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
            set('dashRevenue', inr(d.revenue));
            set('dashCollected', inr(d.revenue));
            set('dashPaidOut', inr(d.paid));
            const net = d.revenue - d.paid;
            const netEl = document.getElementById('dashNet');
            if (netEl) { netEl.textContent = (net < 0 ? '−₹' : '₹') + Math.round(Math.abs(net)).toLocaleString('en-IN'); netEl.classList.toggle('neg', net < 0); }
            const lbl = document.getElementById('dashRevLabel');
            if (lbl) lbl.textContent = d.estimated ? 'Estimated revenue' : 'Revenue collected';
            // delta pill vs previous period
            const deltaEl = document.getElementById('dashRevDelta');
            if (deltaEl) {
                const pct = dashPct(d.revenue, d.revenuePrev);
                deltaEl.hidden = pct === null;
                if (pct !== null) {
                    deltaEl.textContent = (pct >= 0 ? '▲ ' : '▼ ') + Math.abs(pct).toFixed(0) + '%';
                    deltaEl.className = 'pd-delta ' + (pct >= 0 ? 'up' : 'down');
                }
            }
            dashSpark(d.pts || []);
            dashRenderKeys(d);
        }

        function dashRangeSkeleton(on) {
            ['dashRevenue', 'dashCollected', 'dashPaidOut', 'dashNet'].forEach(id => {
                const n = document.getElementById(id); if (n && on) n.textContent = '…';
            });
        }

        function dashPct(cur, prev) {
            if (!prev || prev <= 0) return cur > 0 ? null : 0;
            return ((cur - prev) / prev) * 100;
        }

        /* ─────────────────────── sparkline (inline SVG) ─────────────────────── */
        function dashSpark(pts) {
            const svg = document.getElementById('dashSpark');
            if (!svg) return;
            const W = 300, H = 64, P = 4;
            const max = Math.max(...pts, 1);
            const step = pts.length > 1 ? (W - P * 2) / (pts.length - 1) : 0;
            const xy = pts.map((v, i) => [P + step * i, H - P - ((v / max) * (H - P * 2))]);
            const line = xy.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
            const area = line + ` L${(W - P).toFixed(1)} ${H} L${P} ${H} Z`;
            const last = xy[xy.length - 1] || [W - P, H - P];
            svg.innerHTML = `
                <defs><linearGradient id="dashSparkG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stop-color="#f5c518" stop-opacity=".45"/>
                    <stop offset="1" stop-color="#f5c518" stop-opacity="0"/>
                </linearGradient></defs>
                <path d="${area}" fill="url(#dashSparkG)"/>
                <path d="${line}" fill="none" stroke="#f5c518" stroke-width="2" stroke-linecap="round"/>
                <circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="3.5" fill="#f5c518"/>`;
        }

        /* ─────────────────────── needs attention ─────────────────────── */
        function dashRenderAttention() {
            const box = document.getElementById('dashAttention');
            if (!box) return;
            const rows = [];
            const all = window._dashTournCache || window.allTournamentsCache || [];
            const now = Date.now(), SOON = 12 * 3600 * 1000;

            // 1) room not set for tournament starting soon (red)
            const noRoom = all.filter(t => {
                const dt = dashTsToDate(t.dateTime);
                return dt && (t.status === 'upcoming' || t.status === 'ongoing') &&
                    dt.getTime() > now - 3600 * 1000 && dt.getTime() - now < SOON && t.roomSet !== true;
            });
            if (noRoom.length) {
                const first = noRoom.slice().sort((a, b) => dashTsToDate(a.dateTime) - dashTsToDate(b.dateTime))[0];
                rows.push({ cls: 'red', icon: 'i-shield', num: noRoom.length, label: 'Room ID not set', sub: '“' + (first.name || 'Tournament') + '” starts ' + dashRel(dashTsToDate(first.dateTime)), go: "switchTab('tournaments')" });
            }

            // 2) teams awaiting approval (orange) + oldest wait
            const pt = window._dashPendingTeams || [];
            if (pt.length) {
                const oldest = pt.reduce((m, t) => { const d = dashTsToDate(t.createdAt); return d && (!m || d < m) ? d : m; }, null);
                rows.push({ cls: 'orange', icon: 'i-user-plus', num: pt.length, label: 'Teams awaiting approval', sub: oldest ? 'Oldest waiting ' + dashRel(oldest) : '', go: "switchTab('players')" });
            }

            // 3) withdrawals pending (gold) + total amount
            const pw = window._dashPendingWd || [];
            if (pw.length) {
                const total = pw.reduce((a, w) => a + (Number(w.amount) || 0), 0);
                rows.push({ cls: 'gold', icon: 'i-banknote', num: pw.length, label: 'Withdrawals pending', sub: '₹' + Math.round(total).toLocaleString('en-IN') + ' to pay out', go: "switchTab('wallet')" });
            }

            // 3b) player reports pending (red) — live count from player-reports.js listener
            const pr = window._dashPendingReports || 0;
            if (pr > 0) {
                rows.push({ cls: 'red', icon: 'i-shield', num: pr, label: 'Player reports pending', sub: 'Review & take action', go: "switchTab('reports')" });
            }

            // bell badge = total attention items
            const bell = document.getElementById('dashBellBadge');
            if (bell) {
                const n = noRoom.length + pt.length + pw.length + pr;
                bell.hidden = n === 0;
                bell.textContent = n > 99 ? '99+' : n;
            }

            if (!rows.length) {
                box.innerHTML = '<div class="pd-calm"><span class="pd-calm-ic">✅</span><div><b>All caught up</b><span>Nothing needs your attention right now.</span></div></div>';
                return;
            }
            box.innerHTML = rows.map(r => `
                <button class="pd-attn2 ${r.cls}" onclick="${r.go}">
                    <span class="pd-chip pd-chip-${r.cls === 'red' ? 'err' : r.cls === 'orange' ? 'warn' : 'gold'}"><svg class="ic"><use href="#${r.icon}"/></svg></span>
                    <span class="pd-attn2-main"><b class="pd-num">${r.num}</b><span>${esc(r.label)}</span><small>${esc(r.sub)}</small></span>
                    <svg class="ic pd-attn-go"><use href="#i-chevron"/></svg>
                </button>`).join('');
        }

        /* ─────────────────────── tournaments section ─────────────────────── */
        function dashRenderTournaments(all) {
            const liveBox = document.getElementById('dashLive');
            const nextBox = document.getElementById('dashNext');
            if (!liveBox || !nextBox) return;
            const now = Date.now();
            const live = all.filter(t => t.status === 'ongoing').slice(0, 3);

            liveBox.innerHTML = live.length ? live.map(t => {
                const filled = t.filledTeams ?? t.filledSlots ?? 0;
                const max = t.maxTeams ?? t.maxSlots ?? t.totalSlots ?? 0;
                const pct = max > 0 ? Math.min(100, Math.round((filled / max) * 100)) : 0;
                return `<button class="pd-tcard" onclick="switchTab('tournaments')">
                    <span class="pd-live"><i></i>LIVE</span>
                    <b>${esc(t.name || 'Tournament')}</b>
                    <small>${esc(t.gameMode || t.mode || '—')} • ₹${Number(t.prizePool || 0).toLocaleString('en-IN')} prize</small>
                    <span class="pd-fill"><i style="width:${pct}%"></i></span>
                    <small class="pd-fill-lbl pd-num">${filled}/${max} slots</small>
                </button>`;
            }).join('') : '<div class="pd-empty"><svg class="ic"><use href="#i-gamepad"/></svg>No tournament live right now</div>';

            const upcoming = all
                .map(t => ({ t, dt: dashTsToDate(t.dateTime) }))
                .filter(x => x.dt && x.dt.getTime() > now && (x.t.status === 'upcoming' || !x.t.status))
                .sort((a, b) => a.dt - b.dt)[0];
            window._dashNext = upcoming || null;
            if (upcoming) {
                nextBox.innerHTML = `<button class="pd-ncard" onclick="switchTab('tournaments')">
                    <span class="pd-ncard-top"><span>Next tournament</span><svg class="ic"><use href="#i-chevron"/></svg></span>
                    <b>${esc(upcoming.t.name || 'Tournament')}</b>
                    <span class="pd-countdown pd-num" id="dashCountdown">--:--:--</span>
                    <small>${esc(upcoming.t.gameMode || upcoming.t.mode || '—')} • ${upcoming.dt.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })} ${upcoming.dt.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}</small>
                </button>`;
            } else {
                nextBox.innerHTML = '<div class="pd-empty"><svg class="ic"><use href="#i-trophy"/></svg>No upcoming tournament scheduled</div>';
            }
            dashTickCountdown();
        }

        function dashStartCountdown() {
            if (window._dashTimer) clearInterval(window._dashTimer);
            window._dashTimer = setInterval(dashTickCountdown, 1000);
        }
        function dashTickCountdown() {
            const n = document.getElementById('dashCountdown');
            if (!n) return;
            const nx = window._dashNext;
            if (!nx || !nx.dt) { n.textContent = '--:--:--'; return; }
            let s = Math.max(0, Math.floor((nx.dt.getTime() - Date.now()) / 1000));
            const h = String(Math.floor(s / 3600)).padStart(2, '0');
            const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
            const ss = String(s % 60).padStart(2, '0');
            n.textContent = h + ':' + m + ':' + ss;
        }

        /* ─────────────────────── key numbers ─────────────────────── */
        function dashRenderKeys(rangeData) {
            const box = document.getElementById('dashKeys');
            if (!box) return;
            const all = window._dashTournCache || window.allTournamentsCache || [];
            const d = rangeData || dashCacheGet('dash_range_' + (window._dashRange || 'today'));
            const b = dashRangeBounds(window._dashRange || 'today');

            const inR = (t, f) => { const dt = dashTsToDate(t[f || 'createdAt']); return dt && dt >= b.startDate && dt <= b.endDate; };
            const inPrev = (t, f) => { const dt = dashTsToDate(t[f || 'createdAt']); const ps = b.prevStart.toDate(), pe = b.prevEnd.toDate(); return dt && dt >= ps && dt <= pe; };

            const tours = all.filter(t => inR(t)).length;
            const toursPrev = all.filter(t => inPrev(t)).length || 0;
            const prize = all.filter(t => inR(t)).reduce((a, t) => a + (Number(t.prizePool) || 0), 0);
            const prizePrev = all.filter(t => inPrev(t)).reduce((a, t) => a + (Number(t.prizePool) || 0), 0);
            const activeT = all.filter(t => t.status === 'ongoing' || t.status === 'upcoming');
            const activePlayers = activeT.reduce((a, t) => {
                const teams = t.filledTeams ?? t.filledSlots ?? 0;
                return a + (t.filledPlayers ?? teams * (t.playersPerTeam || 1));
            }, 0);
            const fills = activeT.map(t => {
                const f = t.filledTeams ?? t.filledSlots ?? 0, m = t.maxTeams ?? t.maxSlots ?? t.totalSlots ?? 0;
                return m > 0 ? f / m : null;
            }).filter(v => v !== null);
            const avgFill = fills.length ? Math.round((fills.reduce((a, v) => a + v, 0) / fills.length) * 100) : 0;

            const card = (icon, val, label, pct) => `
                <div class="pd-key">
                    <span class="pd-chip"><svg class="ic"><use href="#${icon}"/></svg></span>
                    <b class="pd-num">${val}</b><span>${label}</span>
                    ${pct === null || pct === undefined ? '' : `<small class="${pct >= 0 ? 'up' : 'down'}">${pct >= 0 ? '▲' : '▼'} ${Math.abs(pct).toFixed(0)}%</small>`}
                </div>`;

            const usersTotal = window._dashUsersTotal;
            box.innerHTML =
                card('i-user', usersTotal === undefined ? '…' : Number(usersTotal).toLocaleString('en-IN'), 'Total users', d ? dashPct(d.newUsers, d.newUsersPrev) : null) +
                card('i-user-plus', d ? d.regs.toLocaleString('en-IN') : '…', 'Registrations', d ? dashPct(d.regs, d.regsPrev) : null) +
                card('i-trophy', tours, 'Tournaments', dashPct(tours, toursPrev)) +
                card('i-players', activePlayers.toLocaleString('en-IN'), 'Active players', null) +
                card('i-banknote', '₹' + Math.round(prize).toLocaleString('en-IN'), 'Prize pool', dashPct(prize, prizePrev)) +
                card('i-gamepad', avgFill + '%', 'Avg fill rate', null);
        }

        /* ─────────────────────── 7-day registrations chart ─────────────────────── */
        async function dashLoadReg7() {
            const key = 'dash_reg7';
            const cached = dashCacheGet(key);
            if (cached) { dashRenderBars(cached); return; }
            try {
                const days = await Promise.all(Array.from({ length: 7 }, async (_, k) => {
                    const i = 6 - k;
                    const s = new Date(); s.setDate(s.getDate() - i); s.setHours(0, 0, 0, 0);
                    const e = new Date(s); e.setHours(23, 59, 59, 999);
                    const n = await dashCount('tournamentTeams', 'createdAt', Timestamp.fromDate(s), Timestamp.fromDate(e)).catch(() => 0);
                    return { label: s.toLocaleDateString('en-IN', { weekday: 'narrow' }), n };
                }));
                dashCacheSet(key, days);
                dashRenderBars(days);
            } catch (e) { console.error('dashLoadReg7:', e); }
        }
        function dashRenderBars(days) {
            const svg = document.getElementById('dashBars');
            const legend = document.getElementById('dashBarsLegend');
            if (!svg || !days) return;
            const W = 320, H = 110, PT = 18, PB = 22;
            const max = Math.max(...days.map(x => x.n), 1);
            const bw = (W / days.length);
            const peak = days.reduce((m, x, i) => x.n > days[m].n ? i : m, 0);
            svg.innerHTML = days.map((x, i) => {
                const h = Math.max(3, ((H - PT - PB) * x.n) / max);
                const cx = bw * i + bw / 2;
                return `<g>
                    <rect x="${(cx - 14).toFixed(1)}" y="${(H - PB - h).toFixed(1)}" width="28" height="${h.toFixed(1)}" rx="7"
                        fill="${i === peak ? '#f5c518' : 'rgba(76,141,255,.45)'}"/>
                    <text x="${cx.toFixed(1)}" y="${(H - 7).toFixed(1)}" text-anchor="middle" class="pd-bars-lbl">${esc(x.label)}</text>
                    ${x.n > 0 ? `<text x="${cx.toFixed(1)}" y="${(H - PB - h - 5).toFixed(1)}" text-anchor="middle" class="pd-bars-val">${x.n}</text>` : ''}
                </g>`;
            }).join('');
            if (legend) {
                const tot = days.reduce((a, x) => a + x.n, 0);
                legend.innerHTML = `<span><b class="pd-num">${tot}</b> registrations this week</span><span>Peak: <b class="pd-num">${days[peak].n}</b> ${esc(days[peak].label)}</span>`;
            }
        }

        /* ─────────────────────── money flow ─────────────────────── */
        async function dashLoadPaidMonth() {
            const key = 'dash_paidmonth';
            const cached = dashCacheGet(key);
            if (cached !== null && cached !== undefined) { dashRenderMoney(cached); return; }
            try {
                const s = new Date(); s.setDate(1); s.setHours(0, 0, 0, 0);
                const v = await dashSum('withdrawalRequests', 'amount',
                    { statusField: 'status', statusVal: 'approved', dateField: 'resolvedAt', from: Timestamp.fromDate(s), to: Timestamp.fromDate(new Date()) }).catch(() => 0);
                dashCacheSet(key, v);
                dashRenderMoney(v);
            } catch (e) { console.error('dashLoadPaidMonth:', e); }
        }
        async function dashLoadUsersTotal() {
            const key = 'dash_userstotal';
            const cached = dashCacheGet(key);
            if (cached !== null && cached !== undefined) { window._dashUsersTotal = cached; dashRenderKeys(); return; }
            try {
                const v = await dashCount('users').catch(() => 0);
                window._dashUsersTotal = v;
                dashCacheSet(key, v);
                dashRenderKeys();
            } catch (e) { console.error('dashLoadUsersTotal:', e); }
        }
        function dashRenderMoney(paidMonth) {
            const box = document.getElementById('dashMoney');
            if (!box) return;
            const pt = window._dashPendingTeams || [];
            const pw = window._dashPendingWd || [];
            const all = window._dashTournCache || window.allTournamentsCache || [];
            const feeOf = tid => { const t = all.find(x => x.id === tid); return Number(t?.entryFee) || 0; };
            const expected = pt.reduce((a, t) => a + feeOf(t.tournamentId), 0);
            const toPay = pw.reduce((a, w) => a + (Number(w.amount) || 0), 0);
            const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
            const row = (icon, label, val, go, gold) => `
                <button class="pd-mrow" onclick="${go}">
                    <span class="pd-chip ${gold ? 'pd-chip-gold' : ''}"><svg class="ic"><use href="#${icon}"/></svg></span>
                    <span class="pd-mrow-main"><span>${esc(label)}</span><small>${esc(go === "switchTab('players')" ? pt.length + ' teams' : pw.length + ' requests')}</small></span>
                    <b class="pd-num ${gold ? 'gold' : ''}">${val}</b>
                    <svg class="ic pd-attn-go"><use href="#i-chevron"/></svg>
                </button>`;
            box.innerHTML =
                row('i-user-plus', 'Expected from pending teams', inr(expected), "switchTab('players')", false) +
                row('i-banknote', 'Withdrawals to pay out', inr(toPay), "switchTab('wallet')", true) +
                `<div class="pd-mrow static"><span class="pd-chip"><svg class="ic"><use href="#i-wallet"/></svg></span>
                    <span class="pd-mrow-main"><span>Paid out this month</span></span>
                    <b class="pd-num">${paidMonth === undefined ? '…' : inr(paidMonth)}</b></div>`;
        }

        /* ─────────────────────── recent activity feed ─────────────────────── */
        function dashRenderFeed() {
            const box = document.getElementById('dashFeed');
            if (!box) return;
            const items = [];
            (window._dashRecentTeams || []).forEach(r => items.push({
                kind: 'team', time: dashTsToDate(r.createdAt),
                icon: 'i-user-plus', cls: 'warn',
                title: r.teamName || r.captainName || 'Team',
                sub: (r.tournamentName || '—') + ' • ' + (r.teamFormat || 'SOLO'),
                end: '<span class="badge badge-' + (r.status || 'pending') + '">' + esc(r.status || 'pending') + '</span>'
            }));
            (window._dashRecentWd || []).forEach(r => items.push({
                kind: 'money', time: dashTsToDate(r.requestedAt),
                icon: 'i-banknote', cls: 'gold',
                title: r.userName || 'Unknown',
                sub: (r.method || '—'),
                end: '<span class="badge badge-' + (r.status || 'pending') + '">₹' + (Number(r.amount) || 0).toLocaleString('en-IN') + '</span>'
            }));
            const all = window._dashTournCache || window.allTournamentsCache || [];
            all.filter(t => t.status === 'completed' || t.status === 'cancelled')
                .map(t => ({ t, dt: dashTsToDate(t.dateTime) })).filter(x => x.dt)
                .sort((a, b) => b.dt - a.dt).slice(0, 5)
                .forEach(x => items.push({
                    kind: 'tour', time: x.dt, icon: 'i-trophy', cls: x.t.status === 'completed' ? 'info' : 'err',
                    title: x.t.name || 'Tournament',
                    sub: (x.t.gameMode || x.t.mode || '—') + ' • ₹' + Number(x.t.prizePool || 0).toLocaleString('en-IN'),
                    end: '<span class="badge badge-' + x.t.status + '">' + esc(x.t.status) + '</span>'
                }));
            items.sort((a, b) => (b.time || 0) - (a.time || 0));
            const chip = window._dashChip || 'all';
            const list = items.filter(i => chip === 'all' || i.kind === chip).slice(0, 10);
            if (!list.length) {
                box.innerHTML = '<div class="pd-empty"><svg class="ic"><use href="#i-inbox"/></svg>No activity yet</div>';
                return;
            }
            box.innerHTML = list.map(i => `
                <div class="pd-row">
                    <span class="pd-chip pd-chip-${i.cls || 'info'} pd-chip-sm"><svg class="ic"><use href="#${i.icon}"/></svg></span>
                    <div class="pd-row-main">
                        <div class="pd-row-title">${esc(i.title)}</div>
                        <div class="pd-row-sub">${esc(i.sub)}</div>
                    </div>
                    <div class="pd-row-end">${i.end}<span class="pd-row-time">${i.time ? dashRel(i.time) : '—'}</span></div>
                </div>`).join('');
        }

        /* ─────────────────────── helpers ─────────────────────── */
        function dashTsToDate(v) {
            if (!v) return null;
            if (v.toDate) { try { return v.toDate(); } catch (e) { return null; } }
            const d = new Date(v);
            return isNaN(d) ? null : d;
        }
        function dashRel(d) {
            if (!d) return '—';
            const s = Math.floor((Date.now() - d.getTime()) / 1000);
            if (s < 0) return 'soon';
            if (s < 60) return 'just now';
            if (s < 3600) return Math.floor(s / 60) + 'm ago';
            if (s < 86400) return Math.floor(s / 3600) + 'h ago';
            if (s < 86400 * 7) return Math.floor(s / 86400) + 'd ago';
            return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
        }
