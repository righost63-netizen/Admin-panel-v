// ══════════════════════════════════════════
// BANNERS MODULE — FULL FILE
// ══════════════════════════════════════════

const BANNER_TAGS = ['Featured', 'New', 'Promo', 'Popular', 'Limited'];

// FIX (apostrophe/XSS): কার্ড থেকে আর JSON string পাঠানো হয় না —
// শুধু doc id যায়, ডাটা _bannerCache থেকে দেখা হয়।
let _bannerCache = [];

// FIX (2026-10-07): banner list-এ full-size image না লোড করে Cloudinary-র
// ছোট version (w_800, auto quality/format) লোড হবে + lazy loading।
// দেখতে একই লাগবে, slow net-এ দ্রুত খুলবে। DB-তে full-res URL অপরিবর্তিত থাকে।
function bannerThumb(url) {
    if (!url || typeof url !== 'string') return url || '';
    var m = url.match(/^(https:\/\/res\.cloudinary\.com\/[^/]+\/image\/upload\/)(.+)$/);
    if (!m) return url;
    // আগে থেকেই transform থাকলে (w_/h_/c_/q_/f_...) — double-add করো না
    if (/^(w_|h_|c_|q_|f_|e_|a_|dpr_|fl_)/.test(m[2])) return url;
    return m[1] + 'w_800,q_auto,f_auto/' + m[2];
}

// ── Stats Bar (Total / Active / Paused) ──
function bannerStatsHTML(total, active, paused) {
    return `
    <div class="banner-stats-grid">
        <div class="stat-card" style="--accent-color:#4FA8E8">
            <div class="stat-icon" style="background: rgba(79, 168, 232, 0.15); color: #4FA8E8;">🖼️</div>
            <div class="stat-value">${total}</div>
            <div class="stat-label">Total</div>
        </div>
        <div class="stat-card" style="--accent-color:#3B82F6">
            <div class="stat-icon" style="background: rgba(59, 130, 246, 0.15); color: #3B82F6;">✅</div>
            <div class="stat-value">${active}</div>
            <div class="stat-label">Active</div>
        </div>
        <div class="stat-card" style="--accent-color:#FFA733">
            <div class="stat-icon" style="background: rgba(255, 167, 51, 0.15); color: #FFA733;">⏸️</div>
            <div class="stat-value">${paused}</div>
            <div class="stat-label">Paused</div>
        </div>
    </div>
    <button class="banner-add-btn" onclick="openBannerSheet(null)">
        <span>+</span> Add Banner
    </button>`;
}

// ── Single Banner Card (iOS Style — 2nd Screenshot) ──
function bannerCardHTML(b, idx) {
    const active = b.isActive !== false;
    const colorClass = 'c' + (idx % 5);
    const hasLink = !!b.redirectLink;
    const tag = active ? BANNER_TAGS[idx % BANNER_TAGS.length] : 'Paused';
    const statusText = active ? 'Active' : 'Paused';
    const statusColor = active ? '#3B82F6' : '#9AA0A6';

    return `
    <div class="banner-card">
        <!-- Left: Image Container -->
        <div class="banner-card-image ${colorClass}">
            ${b.imageUrl ? `<img src="${bannerThumb(b.imageUrl)}" alt="${esc(b.title)}" loading="lazy">` : ''}
            <div class="banner-card-image-overlay">
                <span class="banner-card-tag">${tag}</span>
            </div>
        </div>

        <!-- Right: Content -->
        <div class="banner-card-content">
            <div class="banner-card-header">
                <div style="display:flex; align-items:center; font-size:11px; font-weight:600; color:${statusColor};">
                    <span class="banner-status-dot ${active ? 'active' : 'paused'}"></span>
                    ${statusText}
                </div>
                <!-- Three Dots Menu for Edit/Delete -->
                <button class="banner-menu-btn" onclick='openBannerOptions("${b.id}")'>⋮</button>
            </div>
            
            <div class="banner-card-title">${esc(b.title || 'Untitled')}</div>
            <div class="banner-card-sub">${hasLink ? esc(b.redirectLink) : 'No link added'}</div>
            
            <div class="banner-card-actions">
                <button class="banner-cta ${active ? 'active-cta' : ''}" 
                    ${hasLink ? `onclick="window.open('${b.redirectLink}','_blank')"` : 'disabled'}>
                    ${hasLink ? 'Visit Link' : 'No Link'} 
                    ${hasLink ? '<span style="font-size:10px;">↗</span>' : ''}
                </button>
            </div>
        </div>
    </div>`;
}

// ── Load & Render Banners ──
function loadBanners() {
    const u = onSnapshot(query(collection(db, 'banners'), limit(200)), snap => {
        const el = document.getElementById('bannerContent');
        if (!el) return;

        if (snap.empty) {
            el.innerHTML = `${bannerStatsHTML(0, 0, 0)}
            <div class="empty-state">
                <div class="empty-icon">🖼️</div>
                <div class="empty-title">No Banners</div>
                <div class="empty-subtitle">Tap + to add your first banner</div>
            </div>`;
            return;
        }

        const items = snap.docs.map(d => ({
            id: d.id,
            ...d.data()
        }));
        _bannerCache = items;

        const activeItems = items.filter(b => b.isActive !== false);
        const pausedItems = items.filter(b => b.isActive === false);

        el.innerHTML = `${bannerStatsHTML(items.length, activeItems.length, pausedItems.length)}
        
        ${activeItems.length ? `
        <div class="banner-section-header">
            <div class="banner-section-header-left">
                <span>Active Banners</span>
                <span class="banner-count-badge">${activeItems.length}</span>
            </div>
            <button class="banner-section-action">See All →</button>
        </div>
        <div class="banner-list">${activeItems.map((b, i) => bannerCardHTML(b, i)).join('')}</div>` : ''}
        
        ${pausedItems.length ? `
        <div class="banner-section-header">
            <div class="banner-section-header-left">
                <span>Paused</span>
                <span class="banner-count-badge banner-count-badge-muted">${pausedItems.length}</span>
            </div>
            <button class="banner-section-action">Manage →</button>
        </div>
        <div class="banner-list">${pausedItems.map((b, i) => bannerCardHTML(b, i + activeItems.length)).join('')}</div>` : ''}`;
    });
    listeners.push(u);
}

// ── Toggle Active/Paused ──
window.toggleBannerActive = async function(id, isActive) {
    try {
        await setDoc(doc(db, 'banners', id), {
            isActive,
            updatedAt: serverTimestamp()
        }, {
            merge: true
        });
        await touchCache('banners');
        showToast(isActive ? 'Banner activated' : 'Banner paused', 'success');
    } catch (e) {
        showToast(e.message, 'error');
    }
};

// ── Open Options Menu (Edit / Delete) ──
// ── Open Options Menu (Edit / Delete) — Premium Action Sheet ──
window.openBannerOptions = function(id, bannerData) {
    // FIX: bannerData আর onclick থেকে আসে না — id দিয়ে ক্যাশ থেকে নেওয়া হয়।
    if (!bannerData) bannerData = (_bannerCache || []).find(x => x.id === id) || { id };
    // Create a custom styled action sheet overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed; inset: 0; background: rgba(0, 0, 0,0.5); 
        backdrop-filter: blur(4px); z-index: 9999;
        display: flex; align-items: flex-end; justify-content: center;
        padding: 20px; box-sizing: border-box;
    `;
    
    const sheet = document.createElement('div');
    sheet.style.cssText = `
        background: #1C1C1E; width: 100%; max-width: 400px;
        border-radius: 20px; padding: 20px; box-sizing: border-box;
        display: flex; flex-direction: column; gap: 12px;
        animation: slideUp 0.3s ease-out;
    `;

    // Add keyframes for animation
    if (!document.getElementById('sheet-anim-style')) {
        const style = document.createElement('style');
        style.id = 'sheet-anim-style';
        style.textContent = `@keyframes slideUp { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`;
        document.head.appendChild(style);
    }

    const title = document.createElement('div');
    title.style.cssText = `font-size: 13px; font-weight: 600; color: #8E8E93; text-align: center; text-transform: uppercase; margin-bottom: 8px;`;
    title.textContent = 'Banner Options';

    const btnEdit = document.createElement('button');
    btnEdit.style.cssText = `
        padding: 16px; border: none; border-radius: 12px; background: #2C2C2E; color: #fff;
        font-size: 16px; font-weight: 600; cursor: pointer; width: 100%; text-align: center;
    `;
    btnEdit.textContent = '✏️ Edit Banner';
    btnEdit.onclick = () => { document.body.removeChild(overlay); openBannerSheet(bannerData); };

    const btnDelete = document.createElement('button');
    btnDelete.style.cssText = `
        padding: 16px; border: none; border-radius: 12px; background: #FF453A; color: #fff;
        font-size: 16px; font-weight: 600; cursor: pointer; width: 100%; text-align: center;
    `;
    btnDelete.textContent = '🗑️ Delete Banner';
    btnDelete.onclick = () => {
        document.body.removeChild(overlay);
        // Reuse existing delete logic
        showActionSheet('Delete Banner', 'This action cannot be undone.', [{
            label: 'Delete Banner', style: 'destructive',
            action: async () => {
                try {
                    await deleteDoc(doc(db, 'banners', id));
                    await touchCache('banners');
                    showToast('Banner deleted', 'success');
                } catch (e) { showToast(e.message, 'error'); }
            }
        }]);
    };

    const btnCancel = document.createElement('button');
    btnCancel.style.cssText = `
        padding: 16px; border: none; border-radius: 12px; background: transparent; color: #0A84FF;
        font-size: 16px; font-weight: 600; cursor: pointer; width: 100%; text-align: center; margin-top: 8px;
    `;
    btnCancel.textContent = 'Cancel';
    btnCancel.onclick = () => document.body.removeChild(overlay);

    sheet.appendChild(title);
    sheet.appendChild(btnEdit);
    sheet.appendChild(btnDelete);
    sheet.appendChild(btnCancel);
    overlay.appendChild(sheet);
    
    // Close on overlay click
    overlay.onclick = (e) => { if (e.target === overlay) document.body.removeChild(overlay); };
    
    document.body.appendChild(overlay);
};

// ── Open Add/Edit Banner Sheet (1st Screenshot Design) ──
window.openBannerSheet = function(banner) {
    editingBannerId = banner?.id || null;
    bannerImgUrl = banner?.imageUrl || null;

    document.getElementById('bannerSheetTitle').textContent = banner ? 'Edit Banner' : 'Add Banner';
    document.getElementById('bs_title').value = banner?.title || '';
    document.getElementById('bs_link').value = banner?.redirectLink || '';
    document.getElementById('bs_active').checked = banner?.isActive !== false;

    const up = document.getElementById('bannerImgUpload');
    if (banner?.imageUrl) {
        up.innerHTML = `<img src="${banner.imageUrl}" class="img-upload-preview">`;
    } else {
        up.innerHTML = `<div class="img-upload-icon">🖼️</div>`;
    }

    showSheet('bannerSheet', 'bannerSheetOverlay');
};

window.closeBannerSheet = function() {
    hideSheet('bannerSheet', 'bannerSheetOverlay');
};

// ── Upload Image to Cloudinary ──
window.uploadBannerImg = async function(input) {
    if (!input.files[0]) return;
    const up = document.getElementById('bannerImgUpload');
    if (!up) {
        console.error('uploadBannerImg: #bannerImgUpload not found in DOM');
        return;
    }

    // Show spinner while uploading
    up.innerHTML = '<div class="spinner spinner-accent" style="width:20px; height:20px; border-width:2px;"></div>';

    try {
        const url = await uploadToCloudinary(input.files[0]);
        bannerImgUrl = url;
        up.innerHTML = `<img src="${url}" class="img-upload-preview">`;
        showToast('Image uploaded!', 'success');
    } catch (e) {
        console.error('Banner image upload failed:', e);
        up.innerHTML = `<div class="img-upload-icon">🖼️</div>`;
        showToast('Upload failed: ' + e.message, 'error');
    }
};

// ── Save Banner (Add or Edit) ──
window.saveBanner = async function() {
    const btn = document.getElementById('saveBannerBtn');
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';

    try {
        const title = document.getElementById('bs_title').value.trim();
        const redirectLink = document.getElementById('bs_link').value.trim();
        const isActive = document.getElementById('bs_active').checked;

        if (editingBannerId) {
            // Update existing banner
            await setDoc(doc(db, 'banners', editingBannerId), {
                imageUrl: bannerImgUrl || '',
                title,
                redirectLink,
                isActive,
                updatedAt: serverTimestamp()
            }, {
                merge: true
            });
        } else {
            // Create new banner
            await addDoc(collection(db, 'banners'), {
                imageUrl: bannerImgUrl || '',
                title,
                redirectLink,
                isActive,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
        }

        await touchCache('banners');
        closeBannerSheet();
        showToast('Banner saved!', 'success');
    } catch (e) {
        showToast(e.message, 'error');
    }

    btn.disabled = false;
    btn.textContent = 'Save Banner';
};