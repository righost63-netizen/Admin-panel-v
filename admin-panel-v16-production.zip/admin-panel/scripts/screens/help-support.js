        // ══════════════════════════════════════════
        // HELP & SUPPORT — DYNAMIC CONTACT MANAGEMENT
        // Collection: supportContacts
        // Fields: appName, platform, value, icon (auto), order, createdAt
        // User app এই collection থেকে পড়বে (সর্বনিম্ন ৩টি দেখাবে — user app-এর লজিক)।
        // ══════════════════════════════════════════════════════════════

        const HS_PLATFORMS = [
            { id: 'whatsapp',  label: 'WhatsApp',  icon: '📱', hint: '+91XXXXXXXXXX' },
            { id: 'telegram',  label: 'Telegram',  icon: '✈️', hint: '@username' },
            { id: 'messenger', label: 'Messenger', icon: '💬', hint: 'username or m.me link' },
            { id: 'email',     label: 'Email',     icon: '✉️', hint: 'support@example.com' },
            { id: 'phone',     label: 'Phone',     icon: '📞', hint: '+91XXXXXXXXXX' },
            { id: 'facebook',  label: 'Facebook',  icon: '📘', hint: 'page/profile link' },
            { id: 'instagram', label: 'Instagram', icon: '📸', hint: '@username' },
            { id: 'youtube',   label: 'YouTube',   icon: '▶️', hint: 'channel link' },
            { id: 'discord',   label: 'Discord',   icon: '🎮', hint: 'invite link' },
            { id: 'website',   label: 'Website',   icon: '🌐', hint: 'https://…' },
            { id: 'other',     label: 'Other',     icon: '🔗', hint: 'value' },
        ];

        function hsPlatformMeta(pid) {
            return HS_PLATFORMS.find(p => p.id === pid) || HS_PLATFORMS[HS_PLATFORMS.length - 1];
        }

        let _hsCache = [];
        let _hsEditingId = null;

        // Contact link বানানো (user app-এ ব্যবহারের জন্য reference)
        window.hsBuildLink = function(platform, value) {
            const v = String(value || '').trim();
            if (platform === 'whatsapp' || platform === 'phone') return 'https://wa.me/' + v.replace(/[^0-9]/g, '');
            if (platform === 'telegram') return 'https://t.me/' + v.replace(/^@/, '');
            if (platform === 'messenger') return v.startsWith('http') ? v : 'https://m.me/' + v;
            if (platform === 'email') return 'mailto:' + v;
            if (platform === 'instagram') return 'https://instagram.com/' + v.replace(/^@/, '');
            return v; // website/facebook/youtube/discord/other — raw link
        };

        window.openHelpSettings = function() {
            document.getElementById('helpSettingsContainer')?.remove();
            const sheet = document.createElement('div');
            sheet.id = 'helpSettingsContainer';
            sheet.innerHTML = `
      <div class="sheet-overlay visible" id="helpOverlay" onclick="document.getElementById('helpSettingsContainer').remove()"></div>
      <div class="bottom-sheet visible" id="helpSheet" style="max-height:92dvh;">
        <div class="sheet-handle"></div>
        <div class="hs-hero">
          <div class="hs-hero-ic">💬</div>
          <div class="hs-hero-main">
            <div class="hs-hero-title">Help & Support</div>
            <div class="hs-hero-sub">যতগুলো কন্টাক্ট অ্যাড করবেন, user app-এ ততগুলোই দেখাবে (সর্বনিম্ন ৩টি)</div>
          </div>
          <button class="sheet-close rm-close" onclick="document.getElementById('helpSettingsContainer').remove()" aria-label="Close">✕</button>
        </div>
        <div class="sheet-body">
          <div class="hs-sec-label"><span id="hsCount">0</span> contacts</div>
          <div id="hsContactList"><div class="loading-center"><div class="spinner spinner-accent"></div></div></div>
          <button class="hs-add-btn" id="hsAddBtn" onclick="openContactEditor(null)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
            <span>Add Contact</span>
          </button>
          <div style="height:10px;"></div>
        </div>
      </div>
      <div id="hsEditorMount"></div>`;
            document.body.appendChild(sheet);
            hsLoadContacts();
        };

        async function hsLoadContacts() {
            const el = document.getElementById('hsContactList');
            if (!el) return;
            try {
                const snap = await getDocs(query(collection(db, 'supportContacts'), orderBy('order', 'asc'), limit(50)));
                _hsCache = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                // order ফিল্ড না থাকলে createdAt দিয়ে সাজাও
                _hsCache.sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
                const cnt = document.getElementById('hsCount');
                if (cnt) cnt.textContent = _hsCache.length;
                if (!_hsCache.length) {
                    el.innerHTML = `<div class="hs-empty">
                        <div class="hs-empty-ic">💬</div>
                        <h4>No contacts yet</h4>
                        <p>Add WhatsApp, Telegram, Email… — user app-এ এগুলোই দেখাবে।</p>
                      </div>`;
                    return;
                }
                el.innerHTML = `<div class="hs-list">` + _hsCache.map((c, i) => {
                    const meta = hsPlatformMeta(c.platform);
                    return `<div class="hs-card">
                      <div class="hs-ic">${esc(c.icon || meta.icon)}</div>
                      <div class="hs-main">
                        <div class="hs-app">${esc(c.appName || meta.label)}</div>
                        <div class="hs-plat">${esc(meta.label)} · <span class="hs-val">${esc(c.value || '—')}</span></div>
                      </div>
                      <div class="hs-actions">
                        <button class="icon-btn icon-btn-edit" onclick="openContactEditor('${c.id}')" aria-label="Edit contact">✏️</button>
                        <button class="icon-btn icon-btn-delete" onclick="deleteContact('${c.id}')" aria-label="Delete contact">🗑️</button>
                      </div>
                    </div>`;
                }).join('') + `</div>`;
            } catch (e) {
                console.error('hsLoadContacts error:', e);
                const isPerm = /permission/i.test(e.message || '');
                el.innerHTML = `<div class="hs-empty hs-err">
                        <div class="hs-empty-ic">🔐</div>
                        <h4>${isPerm ? 'Permission denied' : 'Failed to load'}</h4>
                        <p>${isPerm
                          ? 'Firestore rules এখনো deploy হয়নি।<br>Firebase Console → Firestore → <b>Rules</b> ট্যাবে admin-panel-v4.zip-এর <b>firestore.rules</b> পেস্ট করে <b>Publish</b> করুন।'
                          : esc(e.message)}</p>
                      </div>`;
            }
        }

        // Add / Edit contact editor (modal)
        window.openContactEditor = function(id) {
            _hsEditingId = id || null;
            const c = id ? (_hsCache.find(x => x.id === id) || {}) : {};
            const mount = document.getElementById('hsEditorMount');
            const platOpts = HS_PLATFORMS.map(p =>
                `<option value="${p.id}" ${(c.platform || 'whatsapp') === p.id ? 'selected' : ''}>${p.icon} ${p.label}</option>`
            ).join('');
            mount.innerHTML = `
      <div class="sheet-overlay visible hse-overlay" onclick="closeContactEditor()"></div>
      <div class="bottom-sheet visible hse-sheet" style="max-height:84dvh;">
        <div class="sheet-handle"></div>
        <div class="hse-hero">
          <div class="hse-hero-ic" id="hs_iconPreview">${esc(hsPlatformMeta(c.platform || 'whatsapp').icon)}</div>
          <div class="hse-hero-main">
            <div class="hse-hero-title">${id ? 'Edit Contact' : 'Add Contact'}</div>
            <div class="hse-hero-sub">user app-এ এই কন্টাক্টটাই দেখাবে</div>
          </div>
          <button class="sheet-close hse-close" onclick="closeContactEditor()" aria-label="Close">✕</button>
        </div>
        <div class="sheet-body">
          <div class="form-group">
            <label class="form-label" for="hs_appName">App / Label Name *</label>
            <input class="form-input hse-input" id="hs_appName" type="text" placeholder="e.g. Support WhatsApp" value="${esc(c.appName || '')}" maxlength="40" autocomplete="off">
          </div>
          <div class="form-group">
            <label class="form-label" for="hs_platform">Platform *</label>
            <select class="form-select hse-select" id="hs_platform" onchange="hsPlatformChanged()">${platOpts}</select>
          </div>
          <div class="form-group">
            <label class="form-label" for="hs_value">Contact Value *</label>
            <input class="form-input hse-input" id="hs_value" type="text" placeholder="${esc(hsPlatformMeta(c.platform || 'whatsapp').hint)}" value="${esc(c.value || '')}" autocomplete="off">
            <div class="hse-link-preview" id="hs_linkPreview"></div>
          </div>
          <button class="btn-primary hse-save" id="hsSaveBtn" onclick="saveContact()">Save Contact</button>
          <div style="height:8px;"></div>
        </div>
      </div>`;
            hsPlatformChanged();
            document.getElementById('hs_value')?.addEventListener('input', hsPlatformChanged);
        };

        window.hsPlatformChanged = function() {
            const p = document.getElementById('hs_platform')?.value || 'whatsapp';
            const v = document.getElementById('hs_value')?.value.trim() || '';
            const meta = hsPlatformMeta(p);
            const inp = document.getElementById('hs_value');
            if (inp && !inp.placeholder) inp.placeholder = meta.hint;
            if (inp) inp.placeholder = meta.hint;
            const prev = document.getElementById('hs_linkPreview');
            if (prev) prev.textContent = v ? ('🔗 ' + hsBuildLink(p, v)) : (meta.icon + ' Icon auto-selected: ' + meta.label);
            // ✅ Icon preview tile (display-only)
            const icPrev = document.getElementById('hs_iconPreview');
            if (icPrev) icPrev.textContent = meta.icon;
        };

        window.closeContactEditor = function() {
            document.getElementById('hsEditorMount').innerHTML = '';
        };

        window.saveContact = async function() {
            const appName = document.getElementById('hs_appName')?.value.trim();
            const platform = document.getElementById('hs_platform')?.value || 'whatsapp';
            const value = document.getElementById('hs_value')?.value.trim();
            if (!appName || !value) { showToast('App name and contact value are required', 'warning'); return; }
            const btn = document.getElementById('hsSaveBtn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
            try {
                const meta = hsPlatformMeta(platform);
                const data = {
                    appName, platform, value,
                    icon: meta.icon, // auto — platform থেকে
                    link: hsBuildLink(platform, value),
                    updatedAt: serverTimestamp()
                };
                if (_hsEditingId) {
                    await updateDoc(doc(db, 'supportContacts', _hsEditingId), data);
                } else {
                    data.order = _hsCache.length;
                    data.createdAt = serverTimestamp();
                    await addDoc(collection(db, 'supportContacts'), data);
                }
                await touchCache('help');
                closeContactEditor();
                showToast('Contact saved! ✅', 'success');
                hsLoadContacts();
            } catch (e) {
                console.error('saveContact error:', e);
                showToast(e.message, 'error');
            }
            btn.disabled = false;
            btn.textContent = 'Save Contact';
        };

        window.deleteContact = function(id) {
            const c = _hsCache.find(x => x.id === id) || {};
            showActionSheet('Delete Contact?', `"${c.appName || 'this contact'}" মুছে যাবে।`, [{
                label: 'Delete',
                style: 'destructive',
                action: async () => {
                    try {
                        await deleteDoc(doc(db, 'supportContacts', id));
                        await touchCache('help');
                        showToast('Contact deleted', 'success');
                        hsLoadContacts();
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };

        // ── OneSignal API Key ম্যানেজমেন্ট (অ্যাডমিন ছাড়া কেউ দেখতে পাবে না) ──
