        // ══════════════════════════════════════════
        // NOTIFICATIONS
        // ══════════════════════════════════════════



        // loadNotifHistory and deleteNotifLogConfirm defined below in NEW FEATURE 3 section

        window.openNotifSheet = function() {
            document.getElementById('ns_title').value = '';
            document.getElementById('ns_message').value = '';
            document.querySelectorAll('#notifSheet .ntf-type-btn').forEach(b => b.classList.toggle('active', b.id === 'ntType-info'));
            notifType = 'info';
            ntfPreviewUpdate();
            selectedNotifUserId = null;
            document.getElementById('specificUserSearch').style.display = 'none';
            document.getElementById('notif_userSearch').value = '';
            document.getElementById('notif_userResults').innerHTML = '';
            showSheet('notifSheet', 'notifSheetOverlay');
        };

        window.closeNotifSheet = function() {
            hideSheet('notifSheet', 'notifSheetOverlay');
        };

        // FIX (2026-10-06): ntfPreviewUpdate() was called by openNotifSheet + the title/message
        // inputs but NEVER defined — opening the notification sheet threw ReferenceError and the
        // sheet never opened. Now defined: live preview + char count + type icon.
        window.ntfPreviewUpdate = function() {
            const title = document.getElementById('ns_title')?.value || '';
            const msg = document.getElementById('ns_message')?.value || '';
            const tEl = document.getElementById('ntfPrevTitle');
            const mEl = document.getElementById('ntfPrevMsg');
            const cEl = document.getElementById('ntfCharNum');
            const iEl = document.getElementById('ntfPrevIc');
            if (tEl) tEl.textContent = title.trim() || 'Title';
            if (mEl) mEl.textContent = msg.trim() || 'Message preview…';
            if (cEl) cEl.textContent = String(msg.length);
            if (iEl) {
                const active = document.querySelector('#notifSheet .ntf-type-btn.active');
                const icons = { info: 'ℹ️', success: '✅', warning: '⚠️', prize: '🏆' };
                const key = active ? active.id.replace('ntType-', '') : 'info';
                iEl.textContent = icons[key] || 'ℹ️';
            }
        };

        window.selectNotifTarget = function(btn, target) {
            notifTarget = target;
            document.querySelectorAll('[id^=ntBtn-]').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById('specificUserSearch').style.display = target === 'specific' ? 'block' : 'none';
        };

        window.selectNotifType = function(btn, type) {
            notifType = type;
            document.querySelectorAll('[id^=ntType-]').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            if (typeof window.ntfPreviewUpdate === 'function') window.ntfPreviewUpdate();
        };

        // FIX: সার্চের ফলাফল ক্যাশে রাখা — onclick-এ নাম পাঠালে ' থাকলে ভাঙত
        let _notifSearchCache = [];
        window.searchNotifUser = async function() {
            const qRaw = document.getElementById('notif_userSearch').value.trim();
            const q = qRaw.toLowerCase();
            const el = document.getElementById('notif_userResults');
            if (!q) {
                el.innerHTML = '';
                return;
            }
            let found = allUsers.filter(u => (u.name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q));
            // FIX: Users ট্যাবের লোড হওয়া ২০ জনে না পেলে Firestore-এ খোঁজো
            if (!found.length) {
                try {
                    let pool;
                    if (qRaw.includes('@')) {
                        const snap = await getDocs(query(collection(db, 'users'), where('email', '==', qRaw), limit(5)));
                        pool = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                    } else {
                        const snap = await getDocs(query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(200)));
                        pool = snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(u =>
                            (u.name || '').toLowerCase().includes(q) ||
                            (u.email || '').toLowerCase().includes(q) ||
                            String(u.ffUID || u.ffUid || '').toLowerCase().includes(q));
                    }
                    found = pool;
                } catch (e) { console.warn('notif user search fallback failed:', e.message); }
            }
            found = found.slice(0, 5);
            _notifSearchCache = found;
            el.innerHTML = found.map(u => `<div style="padding:10px;background:var(--bg-tertiary);border-radius:10px;margin-bottom:6px;cursor:pointer;border:1px solid ${selectedNotifUserId===u.id?'var(--accent)':'transparent'};" onclick="selectNotifUser('${u.id}')">
    <div style="font-size:14px;font-weight:600;">${esc(u.name||'Unknown')}</div>
    <div style="font-size:12px;color:var(--text-secondary);">${esc(u.email||'—')}</div>
  </div>`).join('');
        };

        window.selectNotifUser = function(uid) {
            const u = (_notifSearchCache || []).find(x => x.id === uid) || (allUsers || []).find(x => x.id === uid) || {};
            const name = u.name || u.email || '';
            selectedNotifUserId = uid;
            document.getElementById('notif_userSearch').value = name;
            document.getElementById('notif_userResults').innerHTML = '';
        };



// ── FIX 5: BATCH NOTIFICATION SEND ──
        // ══════════════════════════════════════════
        // FIX 5 — BATCH NOTIFICATION SEND
        // ══════════════════════════════════════════
        async function sendNotificationToAllUsers(title, message, type) {
            const usersSnap = await getDocs(collection(db, 'users'));
            const users = usersSnap.docs;
            const total = users.length;
            let sent = 0;
            const btn = document.getElementById('sendNotifBtn');
            for (let i = 0; i < users.length; i += 450) {
                const batch = writeBatch(db);
                const chunk = users.slice(i, i + 450);
                chunk.forEach(userDoc => {
                    const notifRef = doc(collection(db, 'users', userDoc.id, 'notifications'));
                    batch.set(notifRef, {
                        title,
                        message,
                        type,
                        read: false,
                        createdAt: serverTimestamp()
                    });
                });
                await batch.commit();
                sent += chunk.length;
                if (btn) btn.innerHTML = `<div class="spinner" style="margin:auto;"></div><span style="margin-left:8px;">${sent}/${total}</span>`;
            }
            // Log to notifLog
            await addDoc(collection(db, 'notifLog'), {
                title,
                message,
                type,
                target: 'all',
                sentAt: serverTimestamp(),
                sentBy: 'admin'
            });
            showToast(`Notification sent to ${total} users`, 'success');
        }


// ── FIX 7: addNotification ──
        // ══════════════════════════════════════════
        // FIX 7 — addNotification with notifLog sync
        // ══════════════════════════════════════════
        async function addNotification(userId, title, message, type = 'info') {
            if (!userId) return;
            const notifRef = doc(collection(db, 'users', userId, 'notifications'));
            await setDoc(notifRef, {
                title,
                message,
                type,
                read: false,
                createdAt: serverTimestamp()
            });
            addDoc(collection(db, 'notifLog'), {
                userId,
                title,
                message,
                type,
                sentAt: serverTimestamp(),
                sentBy: 'system'
            }).catch(err => console.error('notifLog write failed:', err));
        }


        // userIds omitted/empty -> broadcasts to every subscribed player ("Total Subscriptions")
        // userIds array -> targets those specific players via their OneSignal external_id
        // (your player-facing app must call OneSignal.login(firebaseUid) / setExternalUserId
        //  so these ids match — otherwise specific-user sends will silently reach nobody)

// ── SHARED HELPER: PUSH + IN-APP ──
        // ══════════════════════════════════════════
        // SHARED HELPER — PUSH + IN-APP NOTIFICATIONS (OneSignal + Firestore)
        // ══════════════════════════════════════════
        async function notifyUserWithPush(userId, title, message, type = 'info') {
            if (!userId) return { ok: false, skipped: 'no_targets' };
            await addNotification(userId, title, message, type);
            try {
                return await sendOneSignalPush(title, message, type, [userId]);
            } catch (e) {
                console.warn('Push notification failed (in-app notification already sent):', e);
                return { ok: false, error: e.message || 'unknown' };
            }
        }
        window.notifyUserWithPush = notifyUserWithPush;


// ── NOTIFICATION HISTORY DELETE ──
        // ══════════════════════════════════════════
        // NEW FEATURE 3 — NOTIFICATION HISTORY DELETE (realtime)
        // ══════════════════════════════════════════
        // Override loadNotifHistory with realtime onSnapshot + delete button
        function loadNotifHistory() {
            const el = document.getElementById('notifHistoryList');
            if (!el) return;
            el.innerHTML = '<div class="loading-center"><div class="spinner spinner-accent"></div></div>';
            const unsubscribe = onSnapshot(
                query(collection(db, 'notifLog'), orderBy('sentAt', 'desc'), limit(50)),
                snap => {
                    if (!el) return;
                    if (snap.empty) {
                        el.innerHTML = '<div class="empty-state"><div class="empty-icon">🔔</div><div class="empty-title">No notifications sent</div></div>';
                        return;
                    }
                    const icons = {
                        info: 'ℹ️',
                        success: '✅',
                        warning: '⚠️',
                        prize: '🏆',
                        error: '❌'
                    };
                    el.innerHTML = snap.docs.map(d => {
                        const n = d.data();
                        const t = n.sentAt?.toDate?.();
                        const type = n.type || 'info';
                        return `<div class="ntf-card fade-in">
          <div class="ntf-ic ntf-ic-${type}">${icons[type]||'ℹ️'}</div>
          <div class="ntf-main">
            <div class="ntf-top"><span class="ntf-title">${esc(n.title||'—')}</span><span class="ntf-time">${t?formatDate(t):'—'}</span></div>
            <div class="ntf-msg">${esc(n.message||'—')}</div>
            <div class="ntf-foot">
              <span class="ntf-target">${n.target==='all'?'👥 All Users':'🎯 ' + esc(n.targetName||n.target||'—')}</span>
              <span class="ntf-type ntf-type-${type}">${type}</span>
            </div>
          </div>
          <button class="ntf-del" onclick="deleteNotifLogConfirm('${d.id}')" aria-label="Delete notification">🗑️</button>
        </div>`;
                    }).join('');
                },
                err => {
                    if (el) el.innerHTML = '<div class="empty-state"><div class="empty-icon">🔔</div><div class="empty-subtitle">Could not load history</div></div>';
                }
            );
            // Store unsubscribe so it gets cleaned up
            listeners.push(unsubscribe);
        }

        window.deleteNotifLogConfirm = function(id) {
            showActionSheet('Delete Notification?', 'This action cannot be undone.', [{
                label: 'Delete',
                style: 'destructive',
                action: async () => {
                    try {
                        await deleteDoc(doc(db, 'notifLog', id));
                        showToast('Notification deleted', 'success');
                        // realtime listener auto-updates the list
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };


// ── FIX (BUILD 16): _ntfResetSendBtn() was called by sendNotification() but NEVER
// defined — every send threw ReferenceError and left the Send button disabled
// with a spinner. Now defined: restores the button to its original state.
// ── FIX 5: sendNotification BATCH ──
        // ══════════════════════════════════════════
        // FIX 5 — Updated sendNotification with batch
        // ══════════════════════════════════════════
        // FIX (BUILD 16): _ntfResetSendBtn was called but never defined (ReferenceError
        // on every send → button stuck disabled with spinner). Defined here as a bare
        // global function, restoring the button's original label + enabled state.
        function _ntfResetSendBtn() {
            const btn = document.getElementById('sendNotifBtn');
            if (!btn) return;
            btn.disabled = false;
            btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>\nSend Notification';
        }
        window.sendNotification = async function() {
            const title = document.getElementById('ns_title').value.trim();
            const msg = document.getElementById('ns_message').value.trim();
            if (!title || !msg) {
                showToast('Enter title and message', 'warning');
                return;
            }
            const btn = document.getElementById('sendNotifBtn');
            btn.disabled = true;
            try {
                if (notifTarget === 'specific') {
                    if (!selectedNotifUserId) {
                        showToast('Select a user', 'warning');
                        _ntfResetSendBtn();
                        return;
                    }
                    const pushRes = await notifyUserWithPush(selectedNotifUserId, title, msg, notifType);
                    closeNotifSheet();
                    // FIX (BUILD 16): honest toast — push fail/skip হলে সেটাই জানাবে
                    pushToast(pushRes, 'Notification sent! 📲');
                } else {
                    btn.innerHTML = '<div class="spinner" style="margin:auto;"></div>';
                    await sendNotificationToAllUsers(title, msg, notifType);
                    // Broadcast push via OneSignal (Total Subscriptions = every subscribed player)
                    let pushRes = null;
                    try {
                        pushRes = await sendOneSignalPush(title, msg, notifType, null);
                    } catch (pushErr) {
                        console.warn('Broadcast push failed (in-app notifications delivered):', pushErr);
                        pushRes = { ok: false, error: pushErr.message || 'unknown' };
                    }
                    closeNotifSheet();
                    // FIX (BUILD 16): honest toast for broadcast push too
                    pushToast(pushRes, 'Broadcast sent! 📲');
                }
                // ✅ ফিক্স: loadNotifHistory() কল সরানো হলো — এই ফাংশনটা নিজেই
                // notifLog কালেকশনের উপর onSnapshot বসায় (নিচে দেখুন), তাই এটা প্রতিবার
                // নোটিফিকেশন পাঠানোর পর আবার কল করলে একটা নতুন duplicate লিসেনার জমতে
                // থাকতো। মূল লিসেনার এমনিতেই রিয়েলটাইমে নতুন লগ দেখিয়ে দেবে।
            } catch (e) {
                showToast(e.message, 'error');
            }
            _ntfResetSendBtn();
        };



