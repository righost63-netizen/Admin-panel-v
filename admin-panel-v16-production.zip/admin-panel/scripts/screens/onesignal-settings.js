        window.openOneSignalSettings = async function() {
            let curKey = ONESIGNAL_REST_API_KEY || "";
            try {
                const snap = await getDoc(doc(db, 'settings', 'notifications'));
                if (snap.exists()) curKey = snap.data().restApiKey || curKey;
            } catch (e) {}

            const newKey = prompt("Enter OneSignal REST API Key:", curKey);
            if (!newKey || !newKey.trim()) return;

            try {
                await setDoc(doc(db, 'settings', 'notifications'), {
                    restApiKey: newKey.trim(),
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });
                ONESIGNAL_REST_API_KEY = newKey.trim();
                showToast("OneSignal API Key saved securely! 🔐", "success");
            } catch (e) {
                showToast("Failed to save: " + e.message, "error");
            }
        };



