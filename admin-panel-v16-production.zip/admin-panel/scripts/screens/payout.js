// ╔══════════════════════════════════════════════════════════════════════╗
// ║ ফাইল: scripts/screens/payout.js                                        ║
// ║ PAYOUT — verifies manual payouts done via the Staff Panel.            ║
// ║ READ-ONLY screen: reads withdrawalRequests (+ledger/optional logs),  ║
// ║ changes ZERO money-flow logic.                                       ║
// ║ Contract: window.loadPayout, screenLoaders 'payout' → 'loadPayout',   ║
// ║ drawer button switchTab('payout') with id="tab-payout".                ║
// ╚══════════════════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════
// PAYOUT
// ══════════════════════════════════════════
let payoutTab = 'paid';          // 'paid' | 'pending'
let allPayoutRows = [];          // all approved withdrawalRequests (paid + pending-verify)
let payoutIndexNoteShown = false;

// Fixed CSV column list (14 columns) — export builds headers from this array only.
const PAYOUT_CSV_COLUMNS = [
    'Requested',
    'Approved At',
    'User',
    'FF UID',
    'Amount Requested (INR)',
    'Payment Status',
    'Paid To',
    'Amount Paid (INR)',
    'UTR / Txn ID',
    'Payment App',
    'Paid By',
    'Paid At',
    'Approved By',
    'Note'
];

// ── Timestamp → JS Date (Firestore Timestamp / Date / string / number সব ফরম্যাট) ──
function payoutTsToDate(val) {
    if (!val) return null;
    if (typeof val.toDate === 'function') return val.toDate();
    if (val instanceof Date) return isNaN(val) ? null : val;
    if (typeof val === 'object' && typeof val.seconds === 'number') return new Date(val.seconds * 1000);
    if (typeof val === 'string' || typeof val === 'number') {
        const d = new Date(val);
        return isNaN(d) ? null : d;
    }
    return null;
}

// ── তারিখ ফরম্যাট (CSV + কার্ড দুটোতেই ব্যবহার হয়) ──
function payoutFmt(d) {
    if (!d) return '';
    const opts = { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
    return d.toLocaleString('en-IN', opts);
}

function payoutShortFmt(d) {
    if (!d) return '—';
    const opts = { day: '2-digit', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true };
    if (d.getFullYear() !== new Date().getFullYear()) opts.year = 'numeric';
    return d.toLocaleString('en-IN', opts);
}

function payoutMoney(n) {
    return '₹' + (Number(n) || 0).toLocaleString('en-IN');
}

// ══════════════════════════════════════════
// ENTRY — window.loadPayout (classic script, global)
// ══════════════════════════════════════════
window.loadPayout = function() {
    const el = document.getElementById('payoutContent');
    if (!el) return;

    // হেডারের টাইটেল ফাঁকা থাকলে ভরে দেয় (wallet.html প্যাটার্ন)
    const hdrTitle = document.querySelector('#screen-payout [data-header-title]');
    if (hdrTitle && !hdrTitle.textContent.trim()) hdrTitle.textContent = 'Payout';

    payoutTab = 'paid';
    allPayoutRows = [];

    el.innerHTML = `
<div class="po">
  <!-- ১) হেডার -->
  <section class="po-hero">
    <div class="po-eyebrow">PRODUCTION CONSOLE</div>
    <h2 class="po-title">Payout</h2>
    <p class="po-sub">Verify manual payouts done via the Staff Panel — which approved requests have actually been paid, and which are still awaiting payment.</p>
  </section>

  <!-- ২) সামারি কার্ড -->
  <section class="po-cards">
    <div class="po-card po-card-total">
      <div class="po-card-label">Total paid out</div>
      <div class="po-card-value" id="poTotalPaid">₹0</div>
    </div>
    <div class="po-card">
      <div class="po-card-label">Paid count</div>
      <div class="po-card-value" id="poPaidCount">0</div>
    </div>
    <div class="po-card">
      <div class="po-card-label">Pending verification</div>
      <div class="po-card-value po-warn" id="poPendingCount">0</div>
    </div>
    <div class="po-card">
      <div class="po-card-label">Pending amount</div>
      <div class="po-card-value po-warn" id="poPendingAmount">₹0</div>
    </div>
  </section>

  <!-- ৩) টুলবার: Export -->
  <div class="po-toolbar">
    <div class="po-toolbar-hint" id="poNote" hidden></div>
    <button class="po-btn-export" onclick="exportPayoutCSV()" id="poExportBtn">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
      Export CSV
    </button>
  </div>

  <!-- ৪) সেগমেন্ট: Paid / Pending Verification -->
  <div class="po-seg" role="tablist">
    <button role="tab" data-t="paid" class="active" onclick="setPayoutTab('paid')">Paid <span class="po-seg-count" id="poSegPaid">0</span></button>
    <button role="tab" data-t="pending" onclick="setPayoutTab('pending')">Pending Verification <span class="po-seg-count" id="poSegPending">0</span></button>
  </div>

  <!-- ৫) লিস্ট -->
  <div id="payoutList">${payoutSkeletonHTML()}</div>
</div>`;

    fetchPayouts();
};

// ══════════════════════════════════════════
// FETCH — status=='approved', orderBy requestedAt desc, limit 500
// composite index না থাকলে unordered query + client-side sort
// ══════════════════════════════════════════
window.fetchPayouts = async function() {
    const list = document.getElementById('payoutList');
    if (list) list.innerHTML = payoutSkeletonHTML();

    try {
        let snap;
        try {
            const q = query(
                collection(db, 'withdrawalRequests'),
                where('status', '==', 'approved'),
                orderBy('requestedAt', 'desc'),
                limit(500)
            );
            snap = await getDocs(q);
        } catch (indexErr) {
            // Composite index (status + requestedAt) না থাকলে fallback
            console.warn('Payout index missing, fallback query:', indexErr);
            payoutShowNote('Sorted client-side — create the composite index (status + requestedAt) for faster ordering.');
            const q2 = query(
                collection(db, 'withdrawalRequests'),
                where('status', '==', 'approved'),
                limit(500)
            );
            snap = await getDocs(q2);
        }

        allPayoutRows = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        // ফলব্যাক query unordered এলে client-side sort
        allPayoutRows.sort((a, b) => {
            const ta = payoutTsToDate(a.requestedAt);
            const tb = payoutTsToDate(b.requestedAt);
            return (tb ? tb.getTime() : 0) - (ta ? ta.getTime() : 0);
        });

        renderPayoutSummary();
        renderPayoutList();
    } catch (e) {
        console.error('fetchPayouts error:', e);
        showToast('Failed to load payouts: ' + e.message, 'error');
        if (list) list.innerHTML = `<div class="po-empty"><h4>Couldn't load payouts</h4><p>${esc(e.message || 'Please try again.')}</p></div>`;
    }
};

// ── ছোট নোট বার (index fallback বার্তার জন্য) ──
function payoutShowNote(msg) {
    const n = document.getElementById('poNote');
    if (!n) return;
    n.textContent = msg;
    n.hidden = false;
    payoutIndexNoteShown = true;
}

// ══════════════════════════════════════════
// SUMMARY — total paid (paymentAmount where paidAt), counts
// ══════════════════════════════════════════
function payoutSplit() {
    const paid = allPayoutRows.filter(r => !!r.paidAt);
    const pending = allPayoutRows.filter(r => !r.paidAt);
    return { paid, pending };
}

function renderPayoutSummary() {
    const { paid, pending } = payoutSplit();
    const totalPaid = paid.reduce((s, r) => s + (Number(r.paymentAmount) || 0), 0);
    const pendingAmt = pending.reduce((s, r) => s + (Number(r.amount) || 0), 0);

    const set = (id, txt) => { const e = document.getElementById(id); if (e) e.textContent = txt; };
    set('poTotalPaid', payoutMoney(totalPaid));
    set('poPaidCount', String(paid.length));
    set('poPendingCount', String(pending.length));
    set('poPendingAmount', payoutMoney(pendingAmt));
    set('poSegPaid', String(paid.length));
    set('poSegPending', String(pending.length));
}

// ══════════════════════════════════════════
// TABS
// ══════════════════════════════════════════
window.setPayoutTab = function(t) {
    payoutTab = t;
    document.querySelectorAll('#payoutContent .po-seg button').forEach(b => {
        b.classList.toggle('active', b.dataset.t === t);
    });
    renderPayoutList();
};

// ══════════════════════════════════════════
// RENDER — Paid কার্ড (royal blue) / Pending কার্ড (amber)
// ══════════════════════════════════════════
function renderPayoutList() {
    const el = document.getElementById('payoutList');
    if (!el) return;
    const { paid, pending } = payoutSplit();
    const rows = payoutTab === 'paid' ? paid : pending;

    if (!rows.length) {
        const emptyTitle = payoutTab === 'paid' ? 'No payouts yet' : 'Nothing awaiting payment';
        const emptySub = payoutTab === 'paid'
            ? 'Approved requests appear here once staff mark them as paid.'
            : 'Approved requests move here until staff complete the manual payment.';
        el.innerHTML = `<div class="po-empty"><div class="po-empty-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 13l3-8h12l3 8v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Z"/><path d="M3 13h5l1 3h6l1-3h5"/></svg></div><h4>${esc(emptyTitle)}</h4><p>${esc(emptySub)}</p></div>`;
        return;
    }

    el.innerHTML = '<div class="po-list">' + rows.map(r => payoutTab === 'paid' ? payoutPaidCardHTML(r) : payoutPendingCardHTML(r)).join('') + '</div>';
}

// ── Paid কার্ড (premium royal-blue dark) ──
function payoutPaidCardHTML(r) {
    const name = r.userName || 'Unknown';
    const ffUid = r.ffUid || r.ffUID || '';
    const paidAmt = payoutMoney(r.paymentAmount);
    const paidTo = String(r.paymentTo || '—');
    const utr = String(r.paymentUTR || '—');
    const app = String(r.paymentApp || '—');
    const paidBy = String(r.paidBy || '—');
    const paidAt = payoutShortFmt(payoutTsToDate(r.paidAt));
    const reqAt = payoutShortFmt(payoutTsToDate(r.requestedAt));

    return `<article class="po-pcard">
  <div class="po-pcard-top">
    <div>
      <div class="po-pcard-amount">${esc(paidAmt)}</div>
      <div class="po-pcard-when">${paidAt !== '—' ? 'Paid ' + esc(paidAt) : 'Paid date unavailable'}</div>
    </div>
    <span class="po-badge po-badge-paid">Paid ✓</span>
  </div>
  <div class="po-user">
    <div class="po-avatar">${esc(name.trim().charAt(0).toUpperCase() || '?')}</div>
    <div class="po-user-main">
      <div class="po-name">${esc(name)}</div>
      <div class="po-uid">${ffUid ? 'FF UID ' + esc(ffUid) : 'No FF UID'}</div>
    </div>
  </div>
  <dl class="po-rows">
    <div class="po-row"><dt>Paid To</dt><dd>${esc(paidTo)}</dd></div>
    <div class="po-row"><dt>UTR / Txn ID</dt><dd>${esc(utr)}</dd></div>
    <div class="po-row"><dt>App</dt><dd>${esc(app)}</dd></div>
    <div class="po-row"><dt>Paid By</dt><dd>${esc(paidBy)}</dd></div>
    <div class="po-row"><dt>Requested</dt><dd>${esc(reqAt)}</dd></div>
  </dl>
</article>`;
}

// ── Pending Verification কার্ড (amber) ──
function payoutPendingCardHTML(r) {
    const name = r.userName || 'Unknown';
    const ffUid = r.ffUid || r.ffUID || '';
    const amount = payoutMoney(r.amount);
    const reqAt = payoutShortFmt(payoutTsToDate(r.requestedAt));
    const approvedBy = String(r.approvedBy || '—');

    return `<article class="po-pcard po-pcard-pending">
  <div class="po-pcard-top">
    <div>
      <div class="po-pcard-amount">${esc(amount)}</div>
      <div class="po-pcard-when">${reqAt !== '—' ? 'Requested ' + esc(reqAt) : 'Request time unavailable'}</div>
    </div>
    <span class="po-badge po-badge-pending">Awaiting payment</span>
  </div>
  <div class="po-user">
    <div class="po-avatar">${esc(name.trim().charAt(0).toUpperCase() || '?')}</div>
    <div class="po-user-main">
      <div class="po-name">${esc(name)}</div>
      <div class="po-uid">${ffUid ? 'FF UID ' + esc(ffUid) : 'No FF UID'}</div>
    </div>
  </div>
  <dl class="po-rows">
    <div class="po-row"><dt>Approved By</dt><dd>${esc(approvedBy)}</dd></div>
    <div class="po-row"><dt>Status</dt><dd>Approved — money already deducted from wallet</dd></div>
  </dl>
  <p class="po-pend-note">Amount was deducted from the user's wallet at approval time. Staff must complete the manual payment and record the proof in the Staff Panel.</p>
</article>`;
}

function payoutSkeletonHTML() {
    return '<div class="po-list"><div class="po-skel"></div><div class="po-skel"></div></div>';
}

// ══════════════════════════════════════════
// CSV EXPORT — UTF-8 BOM, সব cell double-quote-এ, inner quote escape
// (staff panel-এর quoting প্যাটার্ন অনুসরণ করে)
// ══════════════════════════════════════════
function payoutCsvCell(v) {
    const s = v === null || v === undefined ? '' : String(v);
    return '"' + s.replace(/"/g, '""') + '"';
}

window.exportPayoutCSV = function() {
    try {
        if (!allPayoutRows.length) {
            showToast('No payout rows to export yet.', 'warning');
            return;
        }

        // হেডার: fixed column list থেকে তৈরি
        const lines = [PAYOUT_CSV_COLUMNS.map(payoutCsvCell).join(',')];

        allPayoutRows.forEach(r => {
            const isPaid = !!r.paidAt;
            const row = [
                payoutFmt(payoutTsToDate(r.requestedAt)),
                payoutFmt(payoutTsToDate(r.resolvedAt)),
                r.userName || '',
                r.ffUid || r.ffUID || '',
                Number(r.amount) || 0,
                isPaid ? 'Paid' : 'Pending',
                r.paymentTo || '',
                isPaid ? (Number(r.paymentAmount) || 0) : '',
                r.paymentUTR || '',
                r.paymentApp || '',
                r.paidBy || '',
                payoutFmt(payoutTsToDate(r.paidAt)),
                r.approvedBy || '',
                r.paymentNote || ''
            ];
            lines.push(row.map(payoutCsvCell).join(','));
        });

        const csv = '\uFEFF' + lines.join('\r\n');   // UTF-8 BOM — Excel এ বাংলা/স্পেশাল ক্যারেক্টার ঠিকমতো খুলবে
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);

        const d = new Date();
        const pad = n => String(n).padStart(2, '0');
        const fname = `payouts-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}.csv`;

        const a = document.createElement('a');
        a.href = url;
        a.download = fname;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1500);

        showToast(`Exported ${allPayoutRows.length} payout rows.`, 'success');
    } catch (e) {
        console.error('exportPayoutCSV error:', e);
        showToast('Export failed: ' + e.message, 'error');
    }
};
