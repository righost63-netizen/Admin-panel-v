// ── NEW TOURNAMENT CREATION & MANAGEMENT ENGINE ──
        // ══════════════════════════════════════════════════════════════
        // NEW TOURNAMENT CREATION & MANAGEMENT ENGINE (SPEC-COMPLIANT)
        // ══════════════════════════════════════════════════════════════
        let editingTournId = null;
        // FIX: এডিট-গার্ডের জন্য মূল টুর্নামেন্টের filledTeams/teamFormat মনে রাখা
        let editingOriginal = null;
        let tournState = {
            status: 'upcoming',
            gameMode: '',
            teamFormat: 'SOLO',
            playersPerTeam: 1,
            entryType: 'free',
            entryFee: 0,
            maxTeams: 50,
            maxPlayers: 50,
            map: '',
            prizeType: 'fixed',
            prizePool: 0,
            perKill: 0,
            bannerUrl: '',
            prizeDistribution: []
        };

        // ── Per-Kill Budget Multiplier (Max players in a full FF lobby, by format) ──
        // Solo: 48 players • Duo: 24 teams • Squad: 12 teams
        window.getKillMultiplier = function(format) {
            if (format === 'SOLO') return 48;
            if (format === 'DUO') return 24;
            return 12; // SQUAD
        };

        // ── Total Prize Budget Calculator (Section 6 Fix) ──
        // fixed      => sum of rank prizes only
        // perkill    => perKillAmount × killMultiplier(format)
        // both       => (perKillAmount × killMultiplier(format)) + sum of rank prizes
        window.calcTotalPrizeBudget = function(prizeType, perKill, rankingTotal, format) {
            const mult = getKillMultiplier(format);
            const perKillBudget = (prizeType === 'fixed') ? 0 : (Number(perKill) || 0) * mult;
            if (prizeType === 'perkill') return perKillBudget;
            if (prizeType === 'both') return perKillBudget + (Number(rankingTotal) || 0);
            return Number(rankingTotal) || 0; // fixed
        };

        // ── Status Selector ──
        window.setTournStatus = function(status, btn) {
            tournState.status = status;
            document.getElementById('tf_status').value = status;
            document.querySelectorAll('#tournamentModal [id^="statusBtn-"]').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');
            updateReviewSummary();
        };

        // ── Schedule: iOS-style DateTimePickerSheet wiring ──
        // Hidden inputs (tf_date='YYYY-MM-DD', tf_time='HH:MM') keep the EXACT previous
        // format — data flow / payload unchanged. Only the visible labels render here.
        var SCHED_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        window.renderScheduleFields = function() {
            var d = document.getElementById('tf_date')?.value || '';
            var t = document.getElementById('tf_time')?.value || '';
            var dEl = document.getElementById('tf_date_display');
            var tEl = document.getElementById('tf_time_display');
            if (dEl) {
                if (d) {
                    var dp = d.split('-').map(Number);
                    dEl.textContent = String(dp[2]).padStart(2, '0') + ' ' +
                        SCHED_MONTHS[(dp[1] || 1) - 1] + ' ' + dp[0];
                    dEl.classList.remove('placeholder');
                } else {
                    dEl.textContent = 'Select date';
                    dEl.classList.add('placeholder');
                }
            }
            if (tEl) {
                if (t) {
                    tEl.textContent = (typeof formatTimeTo12h === 'function') ? formatTimeTo12h(t) : t;
                    tEl.classList.remove('placeholder');
                } else {
                    tEl.textContent = 'Select time';
                    tEl.classList.add('placeholder');
                }
            }
        };
        window.openSchedulePicker = function(tab) {
            if (typeof DateTimePickerSheet === 'undefined') return;
            DateTimePickerSheet.open({
                date: document.getElementById('tf_date')?.value || '',
                time: document.getElementById('tf_time')?.value || '',
                tab: tab === 'time' ? 'time' : 'date',
                onSet: function (res) {
                    document.getElementById('tf_date').value = res.date;
                    document.getElementById('tf_time').value = res.time;
                    renderScheduleFields();
                    updateReviewSummary();
                }
            });
        };

        // ── Game Mode Selector (native select — iPhone-এ iOS wheel dropdown খোলে) ──
        // FIX (2026-10-06): custom bottom-sheet picker modal-এর পেছনে (z-801 < z-850) খুলতো বলে
        // দেখাই যেত না। এখন native <select> — সব ডিভাইসে গ্যারান্টি কাজ করবে।
        window.setGameMode = function(mode) {
            tournState.gameMode = mode || '';
            const sel = document.getElementById('tf_gameMode');
            if (sel && sel.value !== tournState.gameMode) sel.value = tournState.gameMode;
            updateReviewSummary();
        };

        // Game Modes collection থেকে active মোডগুলো select-এ লোড করে।
        // কোনো hardcoded fallback নেই।
        window.loadGameModeOptions = async function(selected) {
            const sel = document.getElementById('tf_gameMode');
            if (!sel) return;
            sel.innerHTML = '<option value="">Select game mode</option>';
            let modes = [];
            try {
                const snap = await getDocs(query(collection(db, 'gameModes'), limit(100)));
                const seen = new Set();
                modes = snap.docs.map(d => ({ id: d.id, ...d.data() }))
                    .filter(m => m.isActive !== false && m.name && String(m.name).trim())
                    .map(m => String(m.name).trim())
                    .filter(n => (seen.has(n) ? false : (seen.add(n), true)));
            } catch (e) {
                console.warn('loadGameModeOptions failed:', e.message);
            }
            modes.forEach(m => {
                const opt = document.createElement('option');
                opt.value = m;
                opt.textContent = m;
                sel.appendChild(opt);
            });
            const want = selected || tournState.gameMode || '';
            if (want) {
                if (!modes.includes(want)) {
                    // সেভ করা মোড এখন inactive/deleted — তবু সিলেক্টেবল রাখো
                    const opt = document.createElement('option');
                    opt.value = want;
                    opt.textContent = want + ' (inactive)';
                    sel.appendChild(opt);
                }
                sel.value = want;
            }
        };

        // Quick-add: native prompt → validation + duplicate check + DB save + auto-select.
        // (পুরনো bottom-sheet picker সরিয়ে native select করা হয়েছে — z-index বাগ ফিক্স।)
        window.quickAddGameModePrompt = async function() {
            const name = (prompt('New game mode name:') || '').trim();
            if (!name) return;
            const sel = document.getElementById('tf_gameMode');
            const existing = sel ? Array.from(sel.options).map(o => o.value.toLowerCase()) : [];
            if (existing.includes(name.toLowerCase())) {
                showToast('This mode already exists', 'warning');
                setGameMode(name);
                return;
            }
            try {
                await addDoc(collection(db, 'gameModes'), {
                    name: name, icon: '🎮', isActive: true, createdAt: serverTimestamp()
                });
                if (typeof touchCache === 'function') await touchCache('gameModes');
                await loadGameModeOptions(name);
                setGameMode(name);
                showToast('Game mode added & selected ✅', 'success');
                if (window.logAdminAction) logAdminAction('Create game mode', 'game-modes', name);
            } catch (e) {
                showToast('Failed to add mode: ' + (e.message || e), 'error');
            }
        };

        // Map এখন free-text input (tf_map) + datalist suggestions — কোনো hardcoded list নেই
        window.onMapInput = function(val) {
            tournState.map = (val || '').trim();
            updateReviewSummary();
        };

        // আগের টুর্নামেন্টগুলোর map থেকে unique suggestion বানানো (datalist)
        async function populateMapSuggestions(selectedMap) {
            try {
                const dl = document.getElementById('mapSuggest');
                if (!dl) return;
                const snap = await getDocs(query(collection(db, 'tournaments'), limit(200)));
                const seen = new Set();
                snap.docs.forEach(d => {
                    const m = String(d.data().map || '').trim();
                    if (m && !seen.has(m.toLowerCase())) { seen.add(m.toLowerCase()); }
                });
                // selectedMap সবসময় সাজেশনে থাকবে (ডিলিট হওয়া পুরনো ম্যাপ হলেও)
                if (selectedMap && !seen.has(String(selectedMap).toLowerCase())) seen.add(String(selectedMap).toLowerCase());
                const names = [];
                snap.docs.forEach(d => {
                    const m = String(d.data().map || '').trim();
                    if (m && !names.some(n => n.toLowerCase() === m.toLowerCase())) names.push(m);
                });
                if (selectedMap && !names.some(n => n.toLowerCase() === String(selectedMap).toLowerCase())) names.unshift(selectedMap);
                dl.innerHTML = names.slice(0, 30).map(m => `<option value="${esc(m)}">`).join('');
            } catch (e) { /* suggestions optional — form works without them */ }
        }

        // ── Team Format & Slot Capacity ──
        window.setTeamFormat = function(format, btn) {
            tournState.teamFormat = format;
            document.getElementById('tf_teamFormat').value = format;
            document.querySelectorAll('#tournamentModal [id^="tfFormat-"]').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');

            const slotInput = document.getElementById('tf_slots');
            const lblSlots = document.getElementById('lbl_slotCount');

            if (format === 'SOLO') {
                tournState.playersPerTeam = 1;
                lblSlots.textContent = 'Maximum Players *';
                if (!slotInput.value || slotInput.value === '12' || slotInput.value === '25') slotInput.value = '50';
            } else if (format === 'DUO') {
                tournState.playersPerTeam = 2;
                lblSlots.textContent = 'Maximum Teams *';
                if (!slotInput.value || slotInput.value === '50') slotInput.value = '25';
            } else if (format === 'SQUAD') {
                tournState.playersPerTeam = 4;
                lblSlots.textContent = 'Maximum Teams *';
                if (!slotInput.value || slotInput.value === '50' || slotInput.value === '25') slotInput.value = '12';
            }

            calculateCapacityAndReview();
        };

        window.calculateCapacityAndReview = function() {
            const slots = parseInt(document.getElementById('tf_slots').value) || 0;
            const chip = document.getElementById('capacityChip');
            const chipCalc = document.getElementById('capacityCalcText');

            if (tournState.teamFormat === 'SOLO') {
                tournState.maxTeams = slots;
                tournState.maxPlayers = slots;
                chip.firstElementChild.textContent = `Format: SOLO (1 Player)`;
                chipCalc.textContent = `Max Players: ${slots}`;
            } else if (tournState.teamFormat === 'DUO') {
                tournState.maxTeams = slots;
                tournState.maxPlayers = slots * 2;
                chip.firstElementChild.textContent = `Format: DUO (2 Players/Team)`;
                chipCalc.textContent = `${slots} Teams = ${tournState.maxPlayers} Players`;
            } else if (tournState.teamFormat === 'SQUAD') {
                tournState.maxTeams = slots;
                tournState.maxPlayers = slots * 4;
                chip.firstElementChild.textContent = `Format: SQUAD (4 Players/Team)`;
                chipCalc.textContent = `${slots} Teams = ${tournState.maxPlayers} Players`;
            }
            updateReviewSummary();
        };

        // ── Free / Paid Entry ──
        window.setEntryType = function(type, btn) {
            tournState.entryType = type;
            document.getElementById('tf_entryType').value = type;
            document.querySelectorAll('#tournamentModal [id^="typeBtn-"]').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');

            const feeGroup = document.getElementById('feeGroup');
            const feeInput = document.getElementById('tf_fee');
            if (type === 'paid') {
                feeGroup.style.display = 'block';
                if (!feeInput.value || feeInput.value === '0') feeInput.value = '50';
                tournState.entryFee = parseFloat(feeInput.value) || 50;
            } else {
                feeGroup.style.display = 'none';
                feeInput.value = '0';
                tournState.entryFee = 0;
            }
            updateReviewSummary();
        };

        // ── Prize Mode (Fixed, PerKill, Both) ──
        window.setPrizeType = function(type, btn) {
            tournState.prizeType = type;
            document.getElementById('tf_prizeType').value = type;
            document.querySelectorAll('#tournamentModal [id^="ptBtn-"]').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');

            const poolGroup = document.getElementById('prizePoolGroup');
            const perKillGroup = document.getElementById('perKillGroup');
            const distSection = document.getElementById('prizeDistSection');

            if (type === 'fixed') {
                poolGroup.style.display = 'block';
                perKillGroup.style.display = 'none';
                distSection.style.display = 'block';
                document.getElementById('tf_perkill').value = '0';
            } else if (type === 'perkill') {
                poolGroup.style.display = 'none';
                perKillGroup.style.display = 'block';
                distSection.style.display = 'none';
                document.getElementById('tf_prize').value = '0';
            } else if (type === 'both') {
                poolGroup.style.display = 'block';
                perKillGroup.style.display = 'block';
                distSection.style.display = 'block';
            }
            validatePrizeDistribution();
            updateReviewSummary();
        };

        // ── Dynamic Rank Prize Distribution (Single Source of Truth) ──
        window.addNewPrizeRow = function(rank = null, label = '', amount = '') {
            const container = document.getElementById('dynamicPrizeContainer');
            const rowCount = container.children.length + 1;
            const currentRank = rank || rowCount;
            const defaultLabel = label || (currentRank === 1 ? '1st' : currentRank === 2 ? '2nd' : currentRank === 3 ? '3rd' : `${currentRank}th`);
            const rowId = 'prow_' + Date.now() + '_' + Math.floor(Math.random() * 1000);

            const row = document.createElement('div');
            row.className = 'row fade-in';
            row.id = rowId;
            row.style.cssText = 'align-items:flex-end; gap:6px; margin-bottom:6px;';
            row.innerHTML = `
                <div style="flex:0.6;">
                    <label class="form-label" style="font-size:11px;">Rank #</label>
                    <input class="form-input p-rank" type="number" value="${currentRank}" min="1" style="height:44px; text-align:center; padding:0;" oninput="validatePrizeDistribution()">
                </div>
                <div style="flex:1.4;">
                    <label class="form-label" style="font-size:11px;">Title (e.g. 1st)</label>
                    <input class="form-input p-label" type="text" value="${esc(defaultLabel)}" style="height:44px;" oninput="validatePrizeDistribution()">
                </div>
                <div style="flex:1.2;">
                    <label class="form-label" style="font-size:11px;">Prize (₹)</label>
                    <input class="form-input p-amount" type="number" value="${amount}" placeholder="0" min="1" style="height:44px;" oninput="validatePrizeDistribution()">
                </div>
                <button type="button" class="btn-sm btn-error" style="height:44px; flex:0.4;" onclick="removePrizeRow('${rowId}')">🗑️</button>
            `;
            container.appendChild(row);
            validatePrizeDistribution();
        };

        window.removePrizeRow = function(rowId) {
            const el = document.getElementById(rowId);
            if (el) {
                el.remove();
                validatePrizeDistribution();
            }
        };

        window.getPrizeDistributionList = function() {
            const rows = document.querySelectorAll('#dynamicPrizeContainer .row');
            const list = [];
            rows.forEach(r => {
                const rank = parseInt(r.querySelector('.p-rank')?.value) || list.length + 1;
                const label = r.querySelector('.p-label')?.value.trim() || `Rank ${rank}`;
                const amount = parseFloat(r.querySelector('.p-amount')?.value) || 0;
                if (amount > 0) {
                    list.push({
                        rank,
                        label,
                        amount
                    });
                }
            });
            list.sort((a, b) => a.rank - b.rank);
            return list;
        };

        window.validatePrizeDistribution = function() {
            const notice = document.getElementById('prizeValidationNotice');
            if (tournState.prizeType === 'perkill') {
                notice.style.display = 'none';
                updateReviewSummary();
                return true;
            }
            notice.style.display = 'block';
            const declaredPool = parseFloat(document.getElementById('tf_prize').value) || 0;
            const dist = getPrizeDistributionList();
            const sum = dist.reduce((acc, cur) => acc + cur.amount, 0);

            if (declaredPool <= 0) {
                notice.className = 'prize-calc-notice error';
                notice.textContent = '⚠️ Total prize pool must be greater than ₹0.';
                updateReviewSummary();
                return false;
            }
            if (sum !== declaredPool) {
                notice.className = 'prize-calc-notice error';
                notice.textContent = `⚠️ Prize distribution total (₹${sum}) does not match Total Prize Pool (₹${declaredPool}). Difference: ₹${Math.abs(declaredPool - sum)}`;
                updateReviewSummary();
                return false;
            }
            notice.className = 'prize-calc-notice success';
            notice.textContent = `✅ Prize distribution valid: ${dist.length} ranks total ₹${sum} (Matches pool 100%).`;
            updateReviewSummary();
            return true;
        };

        // ── Cloudinary Banner Upload (grid layout + progress + drag&drop) ──
        window.uploadTournBanner = async function(input) {
            if (!input.files || !input.files[0]) return;
            const file = input.files[0];
            const allowed = ['image/jpeg', 'image/png', 'image/webp'];
            if (!allowed.includes(file.type)) {
                showToast('Please upload JPG, PNG, or WEBP image', 'warning');
                input.value = '';
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                showToast('Image must be under 5MB', 'warning');
                input.value = '';
                return;
            }
            _tournBannerSetProgress(true);
            try {
                const url = await uploadToCloudinary(file);
                tournState.bannerUrl = url;
                _tournBannerSetProgress(false);
                renderTournBannerUI(file.name);
                showToast('Banner uploaded successfully!', 'success');
                updateReviewSummary();
            } catch (e) {
                _tournBannerSetProgress(false);
                showToast('Upload failed: ' + e.message, 'error');
            }
            input.value = '';
        };

        function _tournBannerSetProgress(show) {
            const p = document.getElementById('tournBannerProgress');
            const drop = document.getElementById('tournBannerDrop');
            const prev = document.getElementById('tournBannerPreview');
            if (p) p.hidden = !show;
            if (drop) drop.style.display = show ? 'none' : '';
            if (prev && show) prev.hidden = true;
            if (show) {
                // indeterminate shimmer (Cloudinary SDK-এ progress callback নেই)
                const bar = document.getElementById('tournBannerProgressBar');
                if (bar) bar.style.width = '70%';
            }
        }

        // Banner UI render — modal open + upload success দুই জায়গা থেকে
        window.renderTournBannerUI = function(fileName) {
            const drop = document.getElementById('tournBannerDrop');
            const prev = document.getElementById('tournBannerPreview');
            const img = document.getElementById('tournBannerImg');
            const nameEl = document.getElementById('tournBannerName');
            if (tournState.bannerUrl) {
                if (drop) drop.style.display = 'none';
                if (prev) prev.hidden = false;
                if (img) img.src = tournState.bannerUrl;
                if (nameEl) nameEl.textContent = fileName || 'Tournament banner';
            } else {
                if (drop) drop.style.display = '';
                if (prev) prev.hidden = true;
                if (img) img.removeAttribute('src');
            }
        };

        window.removeTournBanner = function(e) {
            if (e) e.stopPropagation();
            tournState.bannerUrl = '';
            renderTournBannerUI();
            updateReviewSummary();
            showToast('Banner removed', 'info');
        };

        // Drag & drop — modal HTML boot-এই লোড হয়ে থাকে, তাই সরাসরি bind
        (function _bindTournBannerDnD() {
            const drop = document.getElementById('tournBannerDrop');
            if (!drop || drop.dataset.dndBound) return;
            drop.dataset.dndBound = '1';
            ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, (e) => {
                e.preventDefault(); drop.classList.add('dragging');
            }));
            ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => {
                e.preventDefault(); drop.classList.remove('dragging');
            }));
            drop.addEventListener('drop', (e) => {
                const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
                if (f) _tournBannerDirectUpload(f);
            });
        })();
        async function _tournBannerDirectUpload(file) {
            const allowed = ['image/jpeg', 'image/png', 'image/webp'];
            if (!allowed.includes(file.type) || file.size > 5 * 1024 * 1024) {
                showToast('JPG/PNG/WEBP under 5MB only', 'warning'); return;
            }
            _tournBannerSetProgress(true);
            try {
                const url = await uploadToCloudinary(file);
                tournState.bannerUrl = url;
                _tournBannerSetProgress(false);
                renderTournBannerUI(file.name);
                showToast('Banner uploaded successfully!', 'success');
                updateReviewSummary();
            } catch (e) {
                _tournBannerSetProgress(false);
                showToast('Upload failed: ' + e.message, 'error');
            }
        }

        // ── Rules helpers ──
        window.updateRuleCount = function() {
            const ta = document.getElementById('tf_rules');
            const c = document.getElementById('ruleCount');
            if (!ta || !c) return;
            const lines = ta.value.split('\n').map(s => s.trim()).filter(Boolean);
            c.textContent = lines.length;
        };
        window.insertRuleTemplate = function() {
            const ta = document.getElementById('tf_rules');
            if (!ta) return;
            ta.value = `1. Emulators are not allowed — mobile only\n2. Teaming with enemies = instant disqualification\n3. Join the room 10 minutes before start time\n4. No hacking, mods, or exploits\n5. Room ID & password will be shared 15 min before the match\n6. Admin's decision is final`;
            updateRuleCount(); updateReviewSummary();
        };
        window.clearRules = function() {
            const ta = document.getElementById('tf_rules');
            if (!ta) return;
            ta.value = ''; updateRuleCount(); updateReviewSummary();
        };

        // ── Review Box Live Update ──
        window.updateReviewSummary = function() {
            const name = document.getElementById('tf_name')?.value.trim() || '—';
            document.getElementById('rev_name').textContent = name;

            let mapVal = document.getElementById('tf_map')?.value.trim() || '';
            tournState.map = mapVal;
            document.getElementById('rev_mode_map').textContent = `${tournState.gameMode || '—'} • ${mapVal}`;

            document.getElementById('rev_format').textContent = `${tournState.teamFormat} (${tournState.playersPerTeam} player${tournState.playersPerTeam > 1 ? 's' : ''}/team)`;
            document.getElementById('rev_capacity').textContent = `${tournState.maxTeams} Teams • Max ${tournState.maxPlayers} Players`;

            if (tournState.entryType === 'paid') {
                const fee = parseFloat(document.getElementById('tf_fee')?.value) || 0;
                document.getElementById('rev_entry').textContent = `💰 PAID (₹${fee}/team)`;
            } else {
                document.getElementById('rev_entry').textContent = '🆓 FREE ENTRY';
            }

            const dStr = document.getElementById('tf_date')?.value || '';
            const tStr = document.getElementById('tf_time')?.value || '';
            document.getElementById('rev_schedule').textContent = (dStr && tStr) ? `${dStr} at ${formatTimeTo12h(tStr)} (IST)` : 'Not set';

            const revRankingTotal = (typeof getPrizeDistributionList === 'function') ?
                getPrizeDistributionList().reduce((a, c) => a + (c.amount || 0), 0) : 0;
            const revPerKill = parseFloat(document.getElementById('tf_perkill')?.value) || 0;
            const revMult = getKillMultiplier(tournState.teamFormat || 'SOLO');
            const revTotalBudget = calcTotalPrizeBudget(tournState.prizeType, revPerKill, revRankingTotal, tournState.teamFormat || 'SOLO');

            let prizeSummary = '';
            if (tournState.prizeType === 'fixed') {
                prizeSummary = `Fixed Pool: ₹${revRankingTotal} (Ranking Only)`;
            } else if (tournState.prizeType === 'perkill') {
                prizeSummary = `Per Kill: ₹${revPerKill} × ${revMult} = ₹${revTotalBudget} (Max Budget)`;
            } else {
                prizeSummary = `Ranking ₹${revRankingTotal} + Kill (₹${revPerKill} × ${revMult}) = ₹${revTotalBudget} Total`;
            }
            document.getElementById('rev_prize').textContent = prizeSummary;
            document.getElementById('rev_status').textContent = (tournState.status || 'upcoming').toUpperCase();
        };

        window.validateAndReviewTournament = function() {
            const name = document.getElementById('tf_name').value.trim();
            if (!name) {
                showToast('Please enter tournament name', 'warning');
                document.getElementById('tf_name').focus();
                return;
            }
            const slots = parseInt(document.getElementById('tf_slots').value) || 0;
            if (slots <= 0) {
                showToast('Please define tournament capacity', 'warning');
                document.getElementById('tf_slots').focus();
                return;
            }
            const dVal = document.getElementById('tf_date').value;
            const tVal = document.getElementById('tf_time').value;
            if (!dVal || !tVal) {
                showToast('Please set tournament Date and Time', 'warning');
                return;
            }
            updateReviewSummary();
            const box = document.getElementById('tournamentReviewBox');
            if (box) box.scrollIntoView({
                behavior: 'smooth'
            });
        };

        // ── Edit বাটন থেকে ID দিয়ে Tournament খোঁজা (quote/apostrophe সেফ) ──
        window.openTournamentModalById = function(id) {
            const t = allTournaments.find(x => x.id === id);
            if (!t) {
                showToast('Tournament not found', 'error');
                return;
            }
            openTournamentModal(t);
        };

        // ── Open Modal for Create / Edit (Room Conflicted Fixed) ──
        window.openTournamentModal = async function(t = null) {
            editingTournId = t?.id || null;
            // FIX: এডিট-গার্ড — মূল filledTeams ও teamFormat সংরক্ষণ
            editingOriginal = t ? {
                filledTeams: Number(t.filledTeams || t.filledSlots || 0),
                teamFormat: (t.teamFormat || 'SOLO').toUpperCase()
            } : null;
            document.getElementById('tournamentModalTitle').textContent = t ? 'Edit Tournament' : 'Create Tournament';

            // Reset state
            tournState.status = t?.status || 'upcoming';
            tournState.gameMode = t?.gameMode || '';
            tournState.teamFormat = t?.teamFormat || 'SOLO';
            tournState.playersPerTeam = t?.playersPerTeam || (tournState.teamFormat === 'SOLO' ? 1 : tournState.teamFormat === 'DUO' ? 2 : 4);
            tournState.entryType = (t?.entryType) || (t?.isPaid ? 'paid' : 'free');
            tournState.entryFee = t?.entryFee || 0;
            tournState.maxTeams = t?.maxTeams || t?.totalSlots || 50;
            tournState.maxPlayers = t?.maxPlayers || (tournState.maxTeams * tournState.playersPerTeam);
            tournState.map = t?.map || '';
            tournState.prizeType = t?.prizeType || (t?.perKill > 0 && t?.prizePool > 0 ? 'both' : t?.perKill > 0 ? 'perkill' : 'fixed');
            tournState.prizePool = t?.prizePool || 0;
            tournState.perKill = t?.perKill || 0;
            tournState.bannerUrl = t?.bannerUrl || '';

            // Fields populate
            document.getElementById('tf_name').value = t?.name || '';
            document.getElementById('tf_slots').value = tournState.maxTeams;
            document.getElementById('tf_fee').value = tournState.entryFee;
            document.getElementById('tf_prize').value = tournState.prizePool;
            document.getElementById('tf_perkill').value = tournState.perKill;
            document.getElementById('tf_rules').value = t?.rules || '';

            // 🛡️ Single Source of Truth: রুম ক্রেডেনশিয়ালস সবসময় roomCredentials কালেকশন থেকে লোড হবে
            document.getElementById('tf_roomid').value = '';
            document.getElementById('tf_roompw').value = '';
            document.getElementById('tf_roomVisible').checked = Boolean(t?.roomVisible);

            if (editingTournId) {
                try {
                    const roomSnap = await getDoc(doc(db, 'roomCredentials', editingTournId));
                    if (roomSnap.exists()) {
                        const rData = roomSnap.data();
                        document.getElementById('tf_roomid').value = rData.roomId || '';
                        document.getElementById('tf_roompw').value = rData.roomPassword || '';
                        document.getElementById('tf_roomVisible').checked = Boolean(rData.isPublished || rData.roomVisible || t?.roomVisible);
                    }
                } catch (e) {
                    console.warn('[RoomSync] Could not read roomCredentials:', e.message);
                }
            }

            // Set UI Selectors
            setTournStatus(tournState.status, document.getElementById('statusBtn-' + tournState.status));
            // Game-mode options Firestore থেকে লোড (async) — তারপর সেভ করা/ডিফল্ট মান সিলেক্ট
            loadGameModeOptions(tournState.gameMode);
            setTeamFormat(tournState.teamFormat, document.getElementById('tfFormat-' + tournState.teamFormat));
            setEntryType(tournState.entryType, document.getElementById('typeBtn-' + tournState.entryType));
            setPrizeType(tournState.prizeType, document.getElementById('ptBtn-' + tournState.prizeType));

            // Map Setup — free-text input, datalist-এ পুরনো ম্যাপের suggestion
            const mapInput = document.getElementById('tf_map');
            if (mapInput) mapInput.value = tournState.map || '';
            populateMapSuggestions(tournState.map);

            // Schedule Date & Time populate
            // FIX: timeString আগে থেকেই format করা ("10:00 AM") — সেটা formatTimeTo12h()-এ
            // গেলে NaN হয়। শুধু raw 24h ফরম্যাট (t.time, যেমন "14:30") ব্যবহার করো।
            let dateVal = '';
            let timeVal = t?.time || '';
            const rawDate = t?.dateTime || t?.date;
            const parsedDate = tsToDate(rawDate);
            if (parsedDate) {
                // FIX (BUILD 16): save path ইনপুটকে Asia/Kolkata wall time ধরে (line ~778) —
                // তাই prefill-ও IST-তেই দেখাতে হবে। আগে device-local getter ব্যবহার হতো,
                // ফলে +06 (Dhaka) ফোনে edit→save-এ ৩০ মিনিট skew হতো।
                try {
                    const parts = new Intl.DateTimeFormat('en-CA', {
                        timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit',
                        hour: '2-digit', minute: '2-digit', hour12: false
                    }).formatToParts(parsedDate);
                    const p = {};
                    parts.forEach(x => { p[x.type] = x.value; });
                    dateVal = `${p.year}-${p.month}-${p.day}`;
                    if (!timeVal) timeVal = `${p.hour === '24' ? '00' : p.hour}:${p.minute}`;
                } catch (e) {
                    const yyyy = parsedDate.getFullYear();
                    const mm = String(parsedDate.getMonth() + 1).padStart(2, '0');
                    const dd = String(parsedDate.getDate()).padStart(2, '0');
                    dateVal = `${yyyy}-${mm}-${dd}`;
                    if (!timeVal) {
                        timeVal = `${String(parsedDate.getHours()).padStart(2, '0')}:${String(parsedDate.getMinutes()).padStart(2, '0')}`;
                    }
                }
            }
            // FIX 4: create mode-এ date/time খালি থাকলে Asia/Kolkata "এখন" auto-default
            // (edit mode-এ আগের মানই থাকে — উপরের parsedDate সেটাই বসিয়েছে)
            if (!editingTournId && (!dateVal || !timeVal)) {
                try {
                    const parts = new Intl.DateTimeFormat('en-CA', {
                        timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit',
                        hour: '2-digit', minute: '2-digit', hour12: false
                    }).formatToParts(new Date());
                    const p = {};
                    parts.forEach(x => { p[x.type] = x.value; });
                    if (!dateVal) dateVal = `${p.year}-${p.month}-${p.day}`;
                    if (!timeVal) timeVal = `${p.hour === '24' ? '00' : p.hour}:${p.minute}`;
                } catch (e) { /* Intl fail হলে খালিই থাকবে */ }
            }
            document.getElementById('tf_date').value = dateVal;
            document.getElementById('tf_time').value = timeVal;
            renderScheduleFields();

            // Dynamic Prize Rows populate
            const prizeContainer = document.getElementById('dynamicPrizeContainer');
            prizeContainer.innerHTML = '';
            if (Array.isArray(t?.prizeDistribution) && t.prizeDistribution.length > 0) {
                t.prizeDistribution.forEach(p => addNewPrizeRow(p.rank, p.label, p.amount));
            } else if (t?.firstPrize || t?.secondPrize || t?.thirdPrize) {
                if (t.firstPrize) addNewPrizeRow(1, '1st', Number(t.firstPrize));
                if (t.secondPrize) addNewPrizeRow(2, '2nd', Number(t.secondPrize));
                if (t.thirdPrize) addNewPrizeRow(3, '3rd', Number(t.thirdPrize));
            } else {
                addNewPrizeRow(1, '1st', Math.round(tournState.prizePool * 0.5) || 250);
                addNewPrizeRow(2, '2nd', Math.round(tournState.prizePool * 0.3) || 150);
                addNewPrizeRow(3, '3rd', Math.round(tournState.prizePool * 0.2) || 100);
            }

            // Banner image
            renderTournBannerUI();
            updateRuleCount();

            validatePrizeDistribution();
            updateReviewSummary();
            showFullModal('tournamentModal');
        };

        // ── SAVE TO FIREBASE (CRASH-PROOF & REFERENCE-ERROR FIXED) ──
        window.saveTournament = async function() {
            const nameInput = document.getElementById('tf_name');
            const name = nameInput ? nameInput.value.trim() : '';

            if (!name) {
                showToast('Tournament Name is required', 'warning');
                if (nameInput) nameInput.focus();
                return;
            }

            if (!tournState.gameMode) {
                showToast('Please select a Game Mode', 'warning');
                document.getElementById('tf_gameMode')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                document.getElementById('tf_gameMode')?.focus();
                return;
            }

            const slotsInput = document.getElementById('tf_slots');
            const slots = parseInt(slotsInput?.value) || 0;
            if (slots <= 0) {
                showToast('Slot capacity must be greater than 0', 'warning');
                if (slotsInput) slotsInput.focus();
                return;
            }

            // Entry Validation
            const isPaid = (tournState.entryType === 'paid');
            const feeInput = document.getElementById('tf_fee');
            const entryFee = isPaid ? (parseFloat(feeInput?.value) || 0) : 0;
            if (isPaid && entryFee <= 0) {
                showToast('Paid tournament must have Entry Fee > ₹0', 'warning');
                if (feeInput) feeInput.focus();
                return;
            }

            // FIX: জয়েনের পর টুর্নামেন্ট এডিটে গার্ড —
            // maxTeams filledTeams-এর নিচে নামানো যাবে না, আর প্লেয়ার ঢুকে গেলে ফরম্যাট বদলানো যাবে না
            if (editingTournId && editingOriginal) {
                const newMaxTeams = Number(tournState.maxTeams || slots);
                if (newMaxTeams < editingOriginal.filledTeams) {
                    showToast(`Cannot reduce slots below ${editingOriginal.filledTeams} (already joined)`, 'error');
                    return;
                }
                const newFormat = (tournState.teamFormat || 'SOLO').toUpperCase();
                if (editingOriginal.filledTeams > 0 && newFormat !== editingOriginal.teamFormat) {
                    showToast('Cannot change format after players have joined', 'error');
                    return;
                }
            }

            // Schedule Validation
            const dateStr = document.getElementById('tf_date')?.value;
            const timeStr = document.getElementById('tf_time')?.value;
            if (!dateStr || !timeStr) {
                showToast('Please select both Tournament Date & Time', 'warning');
                return;
            }

            // FIX: ইনপুটকে Asia/Kolkata wall time ধরে নেওয়া হলো (আগে ডিভাইস-লোকাল ধরা হতো, কিন্তু লেবেল ছিল IST)
            const _dp = dateStr.split('-').map(Number);
            const _tp = timeStr.split(':').map(Number);
            const matchDateTime = new Date(Date.UTC(_dp[0], _dp[1] - 1, _dp[2], _tp[0], _tp[1] || 0, 0) - (5.5 * 3600 * 1000));
            if (isNaN(matchDateTime.getTime())) {
                showToast('Invalid Date/Time format selected', 'error');
                return;
            }

            // Prize Validation
            const prizeType = tournState.prizeType || 'fixed';
            const prizeInput = document.getElementById('tf_prize');
            const perkillInput = document.getElementById('tf_perkill');

            const prizePool = (prizeType === 'perkill') ? 0 : (parseFloat(prizeInput?.value) || 0);
            const perKill = (prizeType === 'fixed') ? 0 : (parseFloat(perkillInput?.value) || 0);

            // getPrizeDistributionList নিরাপদভাবে কল করা
            let prizeDist = [];
            if (typeof getPrizeDistributionList === 'function') {
                prizeDist = (prizeType === 'perkill') ? [] : getPrizeDistributionList();
            }

            // Map Determination — free text, validation সহ
            const mapInputEl = document.getElementById('tf_map');
            let mapName = mapInputEl ? mapInputEl.value.trim() : '';
            if (!mapName) {
                showToast('Please enter the Map name', 'warning');
                if (mapInputEl) mapInputEl.focus();
                return;
            }

            // Optional Room Credentials
            const roomId = document.getElementById('tf_roomid')?.value.trim() || '';
            const roomPassword = document.getElementById('tf_roompw')?.value.trim() || '';
            const roomVisible = Boolean(document.getElementById('tf_roomVisible')?.checked);

            // Time formatting fallback
            let formattedTimeStr = timeStr;
            if (typeof formatTimeTo12h === 'function') {
                formattedTimeStr = formatTimeTo12h(timeStr);
            }

            const btn = document.getElementById('saveTournBtn');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<div class="spinner" style="margin:auto;"></div> Saving...';
            }

            try {
                // 🛡️ UNIFIED PUBLIC MODEL
                const tourData = {
                    name: name,
                    gameMode: tournState.gameMode,
                    teamFormat: tournState.teamFormat || 'SOLO',
                    playersPerTeam: Number(tournState.playersPerTeam || 1),
                    entryType: tournState.entryType || 'free',
                    isPaid: isPaid,
                    entryFee: entryFee,
                    maxTeams: Number(tournState.maxTeams || slots),
                    maxPlayers: Number(tournState.maxPlayers || (slots * (tournState.playersPerTeam || 1))),
                    totalSlots: Number(tournState.maxTeams || slots),
                    dateTime: Timestamp.fromDate(matchDateTime),
                    // FIX: ডিভাইস টাইমজোন যাই হোক, তারিখ সবসময় IST-তে দেখাবে
                    dateString: matchDateTime.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'long', year: 'numeric' }),
                    timeString: formattedTimeStr,
                    time: timeStr,
                    timezone: 'Asia/Kolkata',
                    status: tournState.status || 'upcoming',
                    map: mapName,
                    prizeType: prizeType,
                    prizePool: prizePool,
                    perKill: perKill,
                    prizeDistribution: prizeDist,
                    killMultiplier: getKillMultiplier(tournState.teamFormat || 'SOLO'),
                    totalPrizeBudget: calcTotalPrizeBudget(prizeType, perKill, prizeDist.reduce((a, c) => a + (c.amount || 0), 0), tournState.teamFormat || 'SOLO'),
                    rules: document.getElementById('tf_rules')?.value.trim() || '',
                    bannerUrl: tournState.bannerUrl || '',
                    roomVisible: roomVisible,
                    updatedAt: serverTimestamp()
                };

                let targetTournId = editingTournId;

                if (targetTournId) {
                    await updateDoc(doc(db, 'tournaments', targetTournId), tourData);
                } else {
                    tourData.filledTeams = 0;
                    tourData.filledPlayers = 0;
                    tourData.filledSlots = 0;
                    tourData.createdAt = serverTimestamp();
                    const newRef = await addDoc(collection(db, 'tournaments'), tourData);
                    targetTournId = newRef.id;
                }

                // রুম ক্রেডেনশিয়ালস থাকলে সিক্রেট কালেকশনে সেভ
                if (roomId || roomPassword) {
                    await setDoc(doc(db, 'roomCredentials', targetTournId), {
                        roomId: roomId,
                        roomPassword: roomPassword,
                        isPublished: roomVisible,
                        roomVisible: roomVisible,
                        roomPublishedAt: roomVisible ? serverTimestamp() : null,
                        updatedAt: serverTimestamp()
                    }, { merge: true });
                }

                if (typeof touchCache === 'function') {
                    await touchCache('tournaments');
                }

                closeTournamentModal();
                showToast(editingTournId ? 'Tournament updated! ✅' : 'Tournament published! 🚀', 'success');
                if (window.logAdminAction) logAdminAction(editingTournId ? 'Update tournament' : 'Create tournament', 'tournaments', name);
                
                // ✅ ফিক্স: loadTournaments() এখানে আর কল করা হয় না — সেটা 'tournaments'
                // কালেকশনের উপর নতুন একটা onSnapshot লিসেনার বসিয়ে দিত, প্রতিবার সেভ করলেই।
                // মূল লিসেনার (নিচের loadTournaments ফাংশনে) এমনিতেই রিয়েলটাইমে আপডেট হয়ে
                // যায়, তাই আলাদা করে রিফ্রেশ করার দরকার নেই।

            } catch (err) {
                console.error('[saveTournament Error]:', err);
                showToast('Failed to save: ' + (err.message || err), 'error');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = '🚀 Save & Publish Tournament';
                }
            }
        };
// ── CLOSE TOURNAMENT MODAL & RETURN TO EVENTS TAB ──
        window.closeTournamentModal = function() {
            // ১. ফুল স্ক্রিন মডাল হাইড করা
            if (typeof hideFullModal === 'function') {
                hideFullModal('tournamentModal');
            } else {
                const modal = document.getElementById('tournamentModal');
                if (modal) {
                    modal.classList.remove('visible');
                    setTimeout(() => { modal.style.display = 'none'; }, 350);
                }
            }

            // ২. পেছনের স্ক্রিনের পুশ ইফেক্ট দূর করা
            const root = document.querySelector('.app-root');
            if (root) root.classList.remove('modal-pushed');

            // ৩. সরাসরি Events (Tournaments) ট্যাবে নিয়ে আসা
            if (typeof switchTab === 'function') {
                switchTab('tournaments');
            }

            // ৪. টুর্নামেন্ট কার্ডের তালিকা তাৎক্ষণিক রিফ্রেশ করা
            // ✅ ফিক্স: loadTournaments() fallback সরানো হলো — এটা কখনো ব্যবহার না হলেও
            // (renderTournaments সবসময় ডিফাইন থাকে) এটা রেখে দিলে ভুলবশত নতুন একটা
            // duplicate onSnapshot লিসেনার তৈরি হওয়ার ঝুঁকি থেকে যেত।
            if (typeof renderTournaments === 'function') {
                renderTournaments();
            }
        };

// ── TOURNAMENTS DASHBOARD & STATUS ENGINE ──
        // ══════════════════════════════════════════════════════════════
        // TOURNAMENTS DASHBOARD & STATUS ENGINE (SPEC SECTION 7, 9, 37, 38, 40)
        // ══════════════════════════════════════════════════════════════
        let tourFilter = 'all';
        let allTournaments = [];

        function loadTournaments() {
            const el = document.getElementById('tournamentsContent');
            // ✅ পারফরম্যান্স ফিক্স: এই listener-ই এখন 'tournaments' collection-এর একমাত্র
            // owner — dashboard.js আর participants-common.js আগে নিজেদের আলাদা আলাদা
            // onSnapshot চালাতো (একই collection-এ ৩টা duplicate লাইভ listener, প্রতিটা
            // লেখায় তিনগুণ Firestore read + তিনগুণ re-render)। এখন ওই দুই ফাইল নিজেদের
            // listener সরিয়ে window.tournamentsUpdateListeners array-এ রেজিস্টার করে রাখে —
            // এখানে fresh data পাওয়ার সাথে সাথে সেই সব রেজিস্টার্ড ফাংশনকে কল করা হচ্ছে।
            // FIX: createdAt ছাড়া পুরনো টুর্নামেন্ট orderBy-তে আসে না —
            // স্ন্যাপশট ফাঁকা এলে orderBy ছাড়া আবার শুনে client-side sort করা হয়।
            let _tournFallbackDone = false;
            const u = onSnapshot(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc')), snap => {
                let docs = snap.docs;
                if (docs.length === 0 && !_tournFallbackDone) {
                    _tournFallbackDone = true;
                    u(); // পুরনো listener বন্ধ
                    const u2 = onSnapshot(query(collection(db, 'tournaments')), snap2 => {
                        handleTournSnap(snap2.docs);
                    }, err => {
                        console.error('loadTournaments error:', err);
                        if (el) el.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><div class="empty-title">Error Loading Tournaments</div><div class="empty-subtitle">${err.message}</div></div>`;
                    });
                    listeners.push(u2);
                    return;
                }
                handleTournSnap(docs);
            }, err => {
                console.error('loadTournaments error:', err);
                if (el) el.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><div class="empty-title">Error Loading Tournaments</div><div class="empty-subtitle">${err.message}</div></div>`;
            });
            listeners.push(u);

            function handleTournSnap(docs) {
                allTournaments = docs.map(d => ({
                    id: d.id,
                    ...d.data()
                }));
                // orderBy ছাড়া এলে dateTime দিয়ে client-side sort (নতুন আগে)
                if (_tournFallbackDone) {
                    const ts = v => (v && v.toMillis) ? v.toMillis() : new Date(v || 0).getTime();
                    allTournaments.sort((a, b) => ts(b.dateTime) - ts(a.dateTime));
                }
                window.allTournamentsCache = allTournaments;
                renderTournaments();
                (window.tournamentsUpdateListeners || []).forEach(fn => {
                    try { fn(allTournaments); } catch (e) { console.error('tournamentsUpdateListener error:', e); }
                });
            }
        }

        window.setTourFilter = function(f) {
            tourFilter = f;
            renderTournaments();
        };

        function renderTournaments() {
            const el = document.getElementById('tournamentsContent');
            if (!el) return;

            const list = tourFilter === 'all' ? allTournaments : allTournaments.filter(t => (t.status || 'upcoming') === tourFilter);

            const countFor = f => f === 'all' ? allTournaments.length : allTournaments.filter(t => (t.status || 'upcoming') === f).length;
            const pad2 = n => String(n).padStart(2, '0');
            const filterTabs = `
                <div class="tcon-tabs">
                    ${['all','upcoming','ongoing','completed','cancelled'].map(f => `
                        <button class="tcon-tab ${tourFilter === f ? 'active' : ''}" onclick="setTourFilter('${f}')">
                            <span class="tcon-tab-label">${f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}</span>
                            <span class="tcon-tab-count">${pad2(countFor(f))}</span>
                        </button>
                    `).join('')}
                </div>
            `;

            if (list.length === 0) {
                el.innerHTML = filterTabs + `
                    <div class="empty-state">
                        <div class="empty-icon">🏆</div>
                        <div class="empty-title">No ${tourFilter === 'all' ? '' : tourFilter.toUpperCase()} Tournaments</div>
                        <div class="empty-subtitle">${tourFilter === 'all' ? 'Tap + to create your first tournament' : 'No tournaments match this status'}</div>
                    </div>
                `;
                return;
            }

            const cardsHTML = list.map(t => {
                const isSolo = (t.teamFormat || 'SOLO') === 'SOLO';
                const maxTeams = t.maxTeams || t.totalSlots || 0;
                const maxPlayers = t.maxPlayers || (maxTeams * (t.playersPerTeam || 1));
                const filledTeams = t.filledTeams || t.filledSlots || 0;
                const filledPlayers = t.filledPlayers || (filledTeams * (t.playersPerTeam || 1));
                const capTotal = isSolo ? maxPlayers : maxTeams;
                const capFilled = isSolo ? filledPlayers : filledTeams;
                const fillPct = capTotal > 0 ? Math.min(100, Math.round((capFilled / capTotal) * 100)) : 0;

                // Date & Time display
                const dateParsed = tsToDate(t.dateTime || t.date);
                const dateFormatted = dateParsed ? dateParsed.toLocaleDateString('en-IN', {
                    day: '2-digit',
                    month: 'short'
                }) : (t.dateString || '—');
                const timeFormatted = t.timeString || (t.time ? formatTimeTo12h(t.time) : '—');

                // Prize display (Section 6 Fix: total includes per-kill max budget)
                const cardTotalBudget = t.totalPrizeBudget !== undefined ? t.totalPrizeBudget :
                    calcTotalPrizeBudget(t.prizeType || 'fixed', t.perKill || 0, t.prizePool || 0, t.teamFormat || 'SOLO');
                let prizeSummary = '';
                if (t.prizeType === 'perkill') {
                    prizeSummary = `₹${cardTotalBudget} Total (₹${t.perKill || 0}/kill)`;
                } else if (t.prizeType === 'both') {
                    prizeSummary = `₹${cardTotalBudget} Total (₹${t.prizePool || 0} + ₹${t.perKill || 0}/kill)`;
                } else {
                    prizeSummary = `₹${cardTotalBudget}`;
                }

                const status = (t.status || 'upcoming').toLowerCase();

                // Status-Based Dynamic Actions (Section 40)
                let actionButtons = '';
                // Delete সব status-এর কার্ডেই থাকবে — admin যেকোনো সময় full cascade delete করতে পারবে
                const delBtn = `<button class="tc2-btn tc2-btn-danger tc2-btn-del-full" onclick="deleteTournament('${t.id}')">🗑️ Delete</button>`;
                if (status === 'upcoming') {
                    actionButtons = `
                        <button class="tc2-btn" onclick="openTournamentModalById('${t.id}')">Edit</button>
                        <button class="tc2-btn" onclick="openRoomManageSheet('${t.id}')">Room</button>
                        <button class="tc2-btn tc2-btn-go" onclick="quickChangeStatus('${t.id}', 'ongoing')">Start</button>
                        <button class="tc2-btn tc2-btn-danger" onclick="openCancelTournModal('${t.id}')">Cancel</button>
                        ${delBtn}
                    `;
                } else if (status === 'ongoing') {
                    actionButtons = `
                        <button class="tc2-btn" onclick="openViewPlayers('${t.id}')">Participants</button>
                        <button class="tc2-btn" onclick="openRoomManageSheet('${t.id}')">Room</button>
                        <button class="tc2-btn tc2-btn-go" onclick="openUpdateResults('${t.id}')">Results</button>
                        <button class="tc2-btn tc2-btn-danger" onclick="openCancelTournModal('${t.id}')">Cancel</button>
                        ${delBtn}
                    `;
                } else if (status === 'completed') {
                    actionButtons = `
                        <button class="tc2-btn" onclick="openPublishResult('${t.id}')">Leaderboard</button>
                        <button class="tc2-btn" onclick="openUpdateResults('${t.id}')">Results</button>
                        ${delBtn}
                    `;
                } else if (status === 'cancelled') {
                    actionButtons = `
                        <button class="tc2-btn" onclick="viewCancellationDetails('${t.id}')">Reason</button>
                        <button class="tc2-btn tc2-btn-go" onclick="quickChangeStatus('${t.id}', 'upcoming')">Re-open</button>
                        ${delBtn}
                    `;
                }

                // ── Display-only derivations (visual redesign; no logic change) ──
                const fmtRaw = (t.teamFormat || 'SOLO');
                const fmtLabel = fmtRaw.charAt(0).toUpperCase() + fmtRaw.slice(1).toLowerCase();
                const entryLabel = Number(t.entryFee || 0) > 0 ? '₹' + t.entryFee + ' entry' : 'Free entry';

                return `
                    <div class="tc2-card fade-in">
                        <div class="tc2-top">
                            <div class="tc2-trophy"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8"/><path d="M12 17v4"/><path d="M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M7 6H4a1 1 0 0 0-1 1c0 2.5 2 4.5 4.5 4.5"/><path d="M17 6h3a1 1 0 0 1 1 1c0 2.5-2 4.5-4.5 4.5"/></svg></div>
                            <span class="tc2-status st-${status}">${status.toUpperCase()}</span>
                        </div>
                        <div class="tc2-eyebrow">FREE FIRE · ${esc((t.gameMode || 'BR RANKED').toUpperCase())}</div>
                        <h3 class="tc2-name">${esc(t.name)}</h3>
                        <div class="tc2-datetime">
                            <span class="tc2-dt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4"/><path d="M8 3v4"/><path d="M3 10h18"/></svg>${dateFormatted}</span>
                            <span class="tc2-dt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>${timeFormatted}</span>
                        </div>
                        <div class="tc2-cells">
                            <div class="tc2-cell"><span class="tc2-cell-label">PRIZE POOL</span><span class="tc2-cell-val">₹${cardTotalBudget}</span></div>
                            <div class="tc2-cell"><span class="tc2-cell-label">FORMAT</span><span class="tc2-cell-val">${esc(fmtLabel)}</span></div>
                            <div class="tc2-cell"><span class="tc2-cell-label">SLOTS</span><span class="tc2-cell-val">${capFilled}/${capTotal}</span></div>
                        </div>
                        <div class="tc2-fill">
                            <div class="tc2-fill-row"><span class="tc2-fill-label">Registration fill</span><span class="tc2-fill-pct">${fillPct}%</span></div>
                            <div class="tc2-bar"><i style="width:${fillPct}%"></i></div>
                        </div>
                        <div class="tc2-meta">${esc(t.map || '—')} · ${esc(t.gameMode || 'BR Ranked')} · ${entryLabel}</div>
                        <div class="tc2-actions">
                            ${actionButtons}
                        </div>
                    </div>
                `;
            }).join('');

            el.innerHTML = filterTabs + cardsHTML;
        }

        // ── Quick Status Changer (Upcoming -> Ongoing etc) ──
        window.quickChangeStatus = async function(id, newStatus) {
            showActionSheet(`Mark Tournament as ${newStatus.toUpperCase()}?`, `This will update tournament state for all users.`, [{
                label: `Set to ${newStatus.toUpperCase()}`,
                style: 'default',
                action: async () => {
                    try {
                        await updateDoc(doc(db, 'tournaments', id), {
                            status: newStatus,
                            updatedAt: serverTimestamp()
                        });
                        await touchCache('tournaments');
                        showToast(`Status changed to ${newStatus}! ✅`, 'success');
                    } catch (e) {
                        showToast(e.message, 'error');
                    }
                }
            }]);
        };

        // ── Cancellation & Reschedule System (Section 37 & 38) ──
        // FIX (apostrophe): onclick থেকে আর নাম পাঠানো হয় না — id দিয়ে ক্যাশ থেকে দেখা হয়।
        window.openCancelTournModal = function(id, name, isPaid) {
            const t = (window.allTournamentsCache || []).find(x => x.id === id) || {};
            name = name || t.name || '';
            if (isPaid === undefined) isPaid = !!(t.isPaid || (t.entryType === 'paid') || Number(t.entryFee) > 0);
            document.getElementById('ct_id').value = id;
            document.getElementById('ct_tournName').textContent = name;
            // FIX: পেইড টুর্নামেন্ট হলে রিফান্ডের কথা আগে থেকেই জানিয়ে দেওয়া হয়
            const hint = document.getElementById('ct_refund_hint');
            if (hint) {
                if (isPaid && Number(t.entryFee) > 0) {
                    hint.style.display = 'block';
                    hint.textContent = `💸 Paid tournament — entry fee ₹${Number(t.entryFee)} will be refunded to each paid team's captain wallet on cancellation.`;
                } else {
                    hint.style.display = 'none';
                    hint.textContent = '';
                }
            }
            document.getElementById('ct_reason').value = '';
            document.getElementById('ct_reschedule_date').value = '';
            document.getElementById('ct_reschedule_time').value = '';
            showSheet('cancelTournSheet', 'cancelTournOverlay');
            if (window.sheetA11y) window.sheetA11y('cancelTournSheet', 'cancelTournOverlay', 'ct_reason');
        };

        window.closeCancelTournModal = function() {
            hideSheet('cancelTournSheet', 'cancelTournOverlay');
        };

        // ✅ FIX: deleteTournament was called from the tournament card (Delete button on
        // completed/cancelled tournaments) but was never defined — clicking it did nothing.
        //
        // ── এই ফাংশনে আরও ২টা সমস্যা ফিক্স করা হলো ──
        // ১. Firestore-এর একটা batch-এ সর্বোচ্চ ৫০০টা write অপারেশন করা যায়। টুর্নামেন্টে
        //    অনেক টিম থাকলে (৫০০+) আগের কোড একটা মাত্র batch-এ সব delete করতে গিয়ে fail করত।
        //    এখন সব docRef গুলো ৪৫০টা করে chunk-এ ভাগ করে আলাদা আলাদা batch commit করা হচ্ছে।
        // ২. আগে শুধু tournamentTeams, roomCredentials, tournamentResults, tournaments ডিলিট
        //    হতো — paymentRequests, joinRequests (legacy), তোর tournamentCaptains lock ডকুমেন্ট
        //    রয়ে যেত। এখন এই related collections গুলোও clean করা হচ্ছে।
        async function deleteRefsInChunks(refs, chunkSize = 450) {
            for (let i = 0; i < refs.length; i += chunkSize) {
                const chunk = refs.slice(i, i + chunkSize);
                const batch = writeBatch(db);
                chunk.forEach(ref => batch.delete(ref));
                await batch.commit();
            }
        }

        // FIX 9 — FULL tournament delete: type-to-confirm + সব related data cascade
        // (teams, UID locks, room, results, payments, legacy joins) — DB + admin + user app
        // থেকে মুছে যায় (tournaments ডকুমেন্ট ডিলিট হলেই user app থেকে অদৃশ্য হয়)।
        window.deleteTournament = function(id) {
            const t = (window.allTournamentsCache || []).find(x => x.id === id) || {};
            const name = (t.name || 'Tournament').trim();
            openTypeConfirm({
                eyebrow: 'Danger zone',
                title: 'Delete Tournament Completely?',
                target: name,
                desc: 'This will <b>permanently delete</b> the tournament and <b>all related data</b> — team registrations, UID locks, room credentials, results, payment records and join requests — from the admin panel, the database <b>and</b> the user app. This cannot be undone.',
                expect: name,
                confirmLabel: 'Delete Everything',
                onConfirm: async () => {
                    const refs = [];
                    let teamCount = 0, payCount = 0;

                    // ১. টিম রেজিস্ট্রেশন + প্রতিটা captain-এর tournamentCaptains lock
                    const teamsSnap = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', id)));
                    teamCount = teamsSnap.size;
                    teamsSnap.forEach(d => {
                        refs.push(d.ref);
                        const captainId = d.data().captainUserId || d.data().userId;
                        if (captainId) refs.push(doc(db, 'tournamentCaptains', `${id}_${captainId}`));
                    });

                    // ২. UID locks (tournamentPlayerUIDs + registeredUIDs)
                    const puSnap = await getDocs(query(collection(db, 'tournamentPlayerUIDs'), where('tournamentId', '==', id)));
                    puSnap.forEach(d => refs.push(d.ref));
                    const regSnap = await getDocs(query(collection(db, 'registeredUIDs'), where('tournamentId', '==', id)));
                    regSnap.forEach(d => refs.push(d.ref));

                    // ৩. পেমেন্ট রেকর্ড + legacy join requests
                    const paySnap = await getDocs(query(collection(db, 'paymentRequests'), where('tournamentId', '==', id)));
                    payCount = paySnap.size;
                    paySnap.forEach(d => refs.push(d.ref));
                    const joinSnap = await getDocs(query(collection(db, 'joinRequests'), where('tournamentId', '==', id)));
                    joinSnap.forEach(d => refs.push(d.ref));

                    // ৪. রুম, রেজাল্ট, আর সবার শেষে মূল টুর্নামেন্ট ডকুমেন্ট
                    refs.push(doc(db, 'roomCredentials', id));
                    refs.push(doc(db, 'tournamentResults', id));
                    refs.push(doc(db, 'tournaments', id));

                    await deleteRefsInChunks(refs, 450);
                    await touchCache('tournaments');

                    if (window.logAdminAction) logAdminAction('Delete tournament', 'tournaments',
                        `${name} — ${teamCount} teams, ${payCount} payment records and all related data removed`);
                    showToast('Tournament and all related data deleted 🗑️', 'success');
                    // onSnapshot লিসেনার ডিলিটটা নিজে থেকেই ধরে ফেলবে — loadTournaments() দরকার নেই
                }
            });
        };
        

        // ✅ FIX: openPublishResult was called from the "📢 Leaderboard" button on completed
        // tournaments but was never defined. It reuses the existing, tested Results/Publish
        // sheet (openUpdateResults) which already has the Publish Leaderboard toggle inside it.
        window.openPublishResult = function(id, name) {
            openUpdateResults(id, name);
        };

        // ✅ FIX: viewCancellationDetails was called from the "ℹ️ Reason" button on cancelled
        // tournaments but was never defined — clicking it did nothing.
        window.viewCancellationDetails = async function(id) {
            const body = document.getElementById('cancelDetailsBody');
            body.innerHTML = '<div class="loading-page"><div class="spinner spinner-accent"></div></div>';
            showSheet('cancelDetailsSheet', 'cancelDetailsOverlay');

            try {
                const snap = await getDoc(doc(db, 'tournaments', id));
                if (!snap.exists()) {
                    body.innerHTML = '<div style="text-align:center;color:var(--color-text-secondary);padding:20px;">Tournament not found.</div>';
                    return;
                }
                const t = snap.data();
                const cancelledAt = tsToDate(t.cancelledAt);

                body.innerHTML = `
                    <div style="font-size:15px; font-weight:800; color:var(--color-text-primary); margin-bottom:14px;">${esc(t.name || 'Tournament')}</div>

                    <div class="form-group">
                        <label class="form-label">Reason</label>
                        <div style="background:var(--color-bg-control); border-radius:12px; padding:12px; font-size:13px; color:var(--color-text-primary); line-height:1.5;">${esc(t.cancellationReason || 'No reason provided')}</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">New Schedule</label>
                        <div style="background:var(--color-bg-control); border-radius:12px; padding:12px; font-size:13px; color:var(--color-text-primary);">${esc(t.rescheduledInfo || 'Not rescheduled')}</div>
                    </div>

                    <div style="font-size:11px; color:var(--color-text-tertiary); margin-top:4px;">
                        Cancelled at: ${cancelledAt ? formatDate(cancelledAt) : '—'}
                    </div>
                `;
            } catch (e) {
                console.error('viewCancellationDetails error:', e);
                body.innerHTML = `<div style="text-align:center;color:var(--color-error);padding:20px;">Failed to load: ${esc(e.message)}</div>`;
            }
        };

        window.closeCancellationDetails = function() {
            hideSheet('cancelDetailsSheet', 'cancelDetailsOverlay');
        };

        // ── Cancellation & Reschedule System (No Refunds - Winning Wallet Only) ──
        window.confirmCancelTournament = async function() {
            const id = document.getElementById('ct_id').value;
            const reason = document.getElementById('ct_reason').value.trim();
            if (!reason) {
                showToast('Please provide cancellation/reschedule reason', 'warning');
                document.getElementById('ct_reason').focus();
                return;
            }

            const resDate = document.getElementById('ct_reschedule_date').value;
            const resTime = document.getElementById('ct_reschedule_time').value;
            let rescheduleText = "Rescheduled date will be announced soon.";
            if (resDate && resTime) {
                rescheduleText = `${resDate} at ${formatTimeTo12h(resTime)} (IST)`;
            } else if (resDate) {
                rescheduleText = `${resDate} (Time will be announced)`;
            }

            const btn = document.getElementById('btnConfirmCancel');
            btn.disabled = true;
            btn.textContent = 'Updating Tournament...';

            try {
                // ১. টুর্নামেন্টের অরিজিনাল ডাটা ফেচ করা
                const tRef = doc(db, 'tournaments', id);
                const tSnap = await getDoc(tRef);
                if (!tSnap.exists()) throw new Error('Tournament not found');
                const tData = tSnap.data();

                const batch = writeBatch(db);
                const notificationsToSend = [];

                // ২. সমস্ত কনফার্মড টিম ফেচ করা
                const teamsSnap = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', id), where('status', '==', 'confirmed')));

                // FIX: পেইড টুর্নামেন্ট বাতিল হলে এন্ট্রি ফি ফেরত যাবে (আগে টাকা আটকে থাকত)
                const entryFee = Number(tData.entryFee || 0);
                const isPaidTourn = entryFee > 0;
                let refundedCount = 0;

                teamsSnap.docs.forEach(teamDoc => {
                    const teamData = teamDoc.data();
                    const captainId = teamData.captainUserId;

                    // পেইড + পেমেন্ট-করা টিমের ক্যাপ্টেনকে এন্ট্রি ফি রিফান্ড (idempotent ledger id)
                    const pStatus = (teamData.paymentStatus || '').toLowerCase();
                    const shouldRefund = isPaidTourn && captainId && (pStatus === 'approved' || pStatus === 'confirmed');
                    if (shouldRefund) {
                        const refundRef = doc(db, 'walletTransactions', `refund_cancel_${id}_${teamDoc.id}`);
                        batch.set(refundRef, {
                            userId: captainId,
                            userName: teamData.teamName || '',
                            type: 'refund',
                            title: `Refund — ${tData.name} cancelled`,
                            description: `Entry fee refund for cancelled tournament "${tData.name}"`,
                            amount: entryFee,
                            status: 'completed',
                            referenceType: 'tournament_cancel',
                            referenceId: id,
                            createdAt: serverTimestamp()
                        });
                        batch.update(doc(db, 'users', captainId), { walletBalance: increment(entryFee) });
                        refundedCount++;
                    }

                    // প্লেয়ারদের স্ট্যাটাস 'confirmed' ই থাকবে, শুধু নোটিফিকেশন যাবে
                    if (captainId) {
                        // ইন-অ্যাপ নোটিফিকেশন
                        const notifRef = doc(collection(db, 'users', captainId, 'notifications'));
                        const notifMsg = `"${tData.name}" has been postponed/rescheduled. Reason: ${reason}. New Schedule: ${rescheduleText}. You are still joined in this tournament.` + (shouldRefund ? ` Entry fee ₹${entryFee} refunded to your wallet.` : '');

                        batch.set(notifRef, {
                            title: '📅 Tournament Rescheduled',
                            message: notifMsg,
                            type: 'warning',
                            read: false,
                            createdAt: serverTimestamp()
                        });

                        notificationsToSend.push(captainId);
                    }
                });

                // ৩. টুর্নামেন্ট স্ট্যাটাস আপডেট করা
                batch.update(tRef, {
                    status: 'cancelled', // User panel इसे 'Cancelled'/'Postponed' হিসেবে দেখাবে
                    cancellationReason: reason,
                    rescheduledInfo: rescheduleText,
                    rescheduledDate: resDate || null,
                    rescheduledTime: resTime || null,
                    cancelledAt: serverTimestamp(),
                    'roomSettings.roomVisible': false,
                    roomVisible: false,
                    updatedAt: serverTimestamp()
                });

                // সিক্রেট কালেকশনে রুম হাইড করা (Security Fix এর সাথে সামঞ্জস্য রেখে)
                const roomCredRef = doc(db, 'roomCredentials', id);
                batch.set(roomCredRef, {
                    isPublished: false,
                    roomVisible: false,
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });

                // ৪. ব্যাচ কমিট করা
                await batch.commit();

                // ৫. পুশ নোটিফিকেশন পাঠানো
                // FIX (BUILD 16): honest result — push fail হলে toast-এ সত্যিটা জানাবে
                let pushRes = null;
                if (notificationsToSend.length > 0) {
                    const uniqueIds = [...new Set(notificationsToSend)];
                    const pushMsg = `"${tData.name}" is rescheduled. New Time: ${rescheduleText}. Check app for details.`;
                    pushRes = await sendOneSignalPush('📅 Tournament Rescheduled', pushMsg, 'warning', uniqueIds)
                        .catch(() => ({ ok: false, error: 'unknown' }));
                }

                await touchCache('tournaments');
                closeCancelTournModal();
                const updMsg = `Tournament updated!` + (refundedCount > 0 ? ` ₹${entryFee} refunded to ${refundedCount} paid teams. 💸` : '');
                if (pushRes && !pushRes.ok) {
                    showToast(updMsg + ` ⚠️ In-app notifications sent to ${notificationsToSend.length} players, but push FAILED.`, 'warning');
                } else {
                    showToast(updMsg + ` ${notificationsToSend.length} players notified. 📅`, 'success');
                }
                if (window.logAdminAction) logAdminAction('Cancel tournament', 'tournaments',
                    `${tData.name || ''} — reason: ${reason}${refundedCount > 0 ? `, ₹${entryFee} refunded to ${refundedCount} teams` : ''}`);
                // ✅ ফিক্স: loadTournaments() কল সরানো হলো — একই কারণে (duplicate listener এড়াতে)।
            } catch (e) {
                console.error('confirmCancelTournament error:', e);
                showToast('Error: ' + e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.textContent = 'Confirm Cancellation';
            }
        };







