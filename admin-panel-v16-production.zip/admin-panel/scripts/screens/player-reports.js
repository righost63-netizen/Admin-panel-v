        // ══════════════════════════════════════════
        // PLAYER REPORTS — admin moderation (BUILD 15)
        // ══════════════════════════════════════════
        // Collection `playerReports` (user app v7 writes these):
        //   { reporterUid, reporterName, reportedFFUID, reason, details,
        //     tournamentId (nullable), status: 'pending', createdAt }
        //
        // Realtime: ONE onSnapshot (createdAt desc, limit 200), status filter
        // applied client-side — so no composite index is needed.
        // Pending count: a tiny global listener updates the drawer badge
        // (#reportBadge) + the dashboard attention row live, on any screen.
        // Manual: every action is admin-approved. No auto-ban on report create.
        let _repCache = [];
        let _repFilter = 'pending';
        let _repUnsub = null;
        let _repBadgeReg = false;

        const REP_REASON_ICON = {
            'Hacking / Cheating': '🤖',
            'Abusive Behaviour': '🤬',
            'Fake UID': '🪪',
            'Teaming with Opponents': '🤝',
            'Account Sharing': '👥',
            'Other': '📝'
        };
        const REP_STATUS_LABEL = { pending: 'Pending', reviewed: 'Reviewed', actioned: 'Actioned', dismissed: 'Dismissed' };

        function repReasonIcon(reason) {
            return REP_REASON_ICON[reason] || '🚨';
        }

        function getFilteredReports() {
            if (_repFilter === 'all') return _repCache;
            return _repCache.filter(r => (r.status || 'pending') === _repFilter);
        }

        function renderReports() {
            const list = document.getElementById('reportList');
            if (!list) return;
            const rows = getFilteredReports();
            const badge = document.getElementById('reportTotalBadge');
            if (badge) {
                badge.style.display = rows.length ? '' : 'none';
                badge.textContent = rows.length;
            }
            if (!rows.length) {
                list.innerHTML = `<div class="rs-empty"><div class="rs-empty-ic">🛡️</div><h4>No reports</h4><p>${_repFilter === 'pending' ? 'No pending reports. All caught up! 🎉' : 'No ' + esc(_repFilter) + ' reports.'}</p></div>`;
                return;
            }
            list.innerHTML = rows.map(r => {
                const dt = tsToDate(r.createdAt);
                const dateStr = dt ? dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
                const timeStr = dt ? dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';
                const st = r.status || 'pending';
                const canAct = st === 'pending' || st === 'reviewed';
                return `<div class="rep-card">
                    <div class="rep-top">
                        <div class="rep-uid">🪪 ${esc(r.reportedFFUID || '—')}</div>
                        <span class="rep-status rep-st-${st}">${esc(REP_STATUS_LABEL[st] || st)}</span>
                    </div>
                    <div class="rep-reason">${repReasonIcon(r.reason)} ${esc(r.reason || 'Report')}</div>
                    ${r.details ? `<div class="rep-details">${esc(r.details)}</div>` : ''}
                    <div class="rep-meta">👤 ${esc(r.reporterName || 'Player')} • ${dateStr}${timeStr ? ', ' + timeStr : ''}${r.tournamentId ? ' • 🏆 tournament' : ''}</div>
                    ${r.actionNote ? `<div class="rep-note">📝 <b>Action note:</b> ${esc(r.actionNote)}</div>` : ''}
                    ${canAct ? `<div class="rep-actions">
                        <button class="cxs-btn cxs-btn-ghost" onclick="reportReviewed('${r.id}')">👁 Reviewed</button>
                        <button class="cxs-btn cxs-btn-ghost" onclick="reportDismiss('${r.id}')">Dismiss</button>
                        <button class="cxs-btn cxs-btn-danger" onclick="reportTakeAction('${r.id}')">⚡ Take Action</button>
                    </div>` : ''}
                </div>`;
            }).join('');
        }

        window.setReportFilter = function(filter, btn) {
            _repFilter = filter || 'pending';
            document.querySelectorAll('[data-repfilter]').forEach(c => c.classList.remove('active'));
            if (btn) btn.classList.add('active');
            renderReports();
        };

        // ↻ Refresh button: drop + re-attach the realtime listener → latest server data
        window.refreshReports = function() {
            if (typeof _repUnsub === 'function') { try { _repUnsub(); } catch (e) {} _repUnsub = null; }
            attachReportsListener();
            showToast('Refreshing…', 'info');
        };

        function attachReportsListener() {
            const list = document.getElementById('reportList');
            if (list) list.innerHTML = `<div class="rs-skel"></div><div class="rs-skel"></div>`;
            try {
                // orderBy createdAt desc — single-field index auto-created by Firestore
                const q = query(collection(db, 'playerReports'), orderBy('createdAt', 'desc'), limit(200));
                _repUnsub = onSnapshot(q, snap => {
                    _repCache = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                    renderReports();
                }, err => {
                    console.error('reports listener:', err);
                    if (list) list.innerHTML = `<div class="rs-empty"><div class="rs-empty-ic">⚠️</div><h4>Failed to load</h4><p>${esc(err.message || '')}</p></div>`;
                });
            } catch (e) {
                console.error('attachReportsListener:', e);
            }
        }

        // Pending-count badge: registers ONCE per session, works from any screen.
        // Updates drawer #reportBadge + dashboard attention row (live).
        function ensureReportBadgeListener() {
            if (_repBadgeReg) return;
            _repBadgeReg = true;
            try {
                const q = query(collection(db, 'playerReports'), where('status', '==', 'pending'), limit(200));
                onSnapshot(q, snap => {
                    const n = snap.size;
                    const badge = document.getElementById('reportBadge');
                    if (badge) { badge.textContent = n >= 200 ? '200+' : n; badge.style.display = n > 0 ? 'flex' : 'none'; }
                    window._dashPendingReports = n;
                    if (typeof dashRenderAttention === 'function') {
                        try { dashRenderAttention(); } catch (e) {}
                    }
                }, err => console.error('report badge listener:', err));
            } catch (e) { console.error('ensureReportBadgeListener:', e); }
        }

        window.loadPlayerReports = function() {
            ensureReportBadgeListener();
            if (!_repUnsub) attachReportsListener();
            else renderReports();
        };

        async function setReportStatus(id, patch, logLabel) {
            try {
                await updateDoc(doc(db, 'playerReports', id), { ...patch, updatedAt: serverTimestamp() });
                const r = _repCache.find(x => x.id === id);
                logAdminAction(logLabel || 'report_updated', 'player-reports',
                    `FF UID ${r ? r.reportedFFUID : id} → ${patch.status || 'updated'}`);
                showToast('Report updated ✅', 'success');
            } catch (e) {
                console.error('setReportStatus:', e);
                showToast(e.message || 'Failed', 'error');
            }
        }

        window.reportReviewed = function(id) {
            setReportStatus(id, { status: 'reviewed' }, 'report_reviewed');
        };

        window.reportDismiss = function(id) {
            showActionSheet('Dismiss Report', 'This report will be marked dismissed.', [{
                label: 'Dismiss Report',
                style: 'default',
                action: () => setReportStatus(id, { status: 'dismissed' }, 'report_dismissed')
            }]);
        };

        // Resolve Firebase uid from FF UID (for the optional ban step)
        async function resolveUidByFFUID(ffUID) {
            const s = await getDocs(query(collection(db, 'users'), where('ffUID', '==', String(ffUID)), limit(1)));
            return s.empty ? null : { uid: s.docs[0].id, ...s.docs[0].data() };
        }

        // Small note-input overlay (reuses type-confirm card styles)
        function openReportNoteSheet(title, onSave) {
            document.getElementById('repNoteOverlay')?.remove();
            const ov = document.createElement('div');
            ov.className = 'ttc-overlay';
            ov.id = 'repNoteOverlay';
            ov.setAttribute('role', 'dialog');
            ov.setAttribute('aria-modal', 'true');
            ov.innerHTML = `
                <div class="ttc-card">
                    <div class="ttc-hero">
                        <div class="ttc-eyebrow">Player Reports</div>
                        <div class="ttc-title">${esc(title)}</div>
                    </div>
                    <div class="ttc-body">
                        <label class="ttc-type-label" for="repNoteInput">Action note (optional)</label>
                        <textarea class="form-input" id="repNoteInput" rows="3" placeholder="e.g. Warned the player, 1st offence…"
                            style="resize:vertical;min-height:76px;"></textarea>
                        <div class="ttc-actions">
                            <button class="cxs-btn cxs-btn-ghost" id="repNoteCancel" type="button">Cancel</button>
                            <button class="cxs-btn cxs-btn-danger" id="repNoteSave" type="button">Save Action</button>
                        </div>
                    </div>
                </div>`;
            document.body.appendChild(ov);
            const close = () => ov.remove();
            ov.querySelector('#repNoteCancel').addEventListener('click', close);
            ov.addEventListener('click', e => { if (e.target === ov) close(); });
            ov.querySelector('#repNoteSave').addEventListener('click', async ev => {
                ev.target.disabled = true;
                try {
                    await onSave(ov.querySelector('#repNoteInput').value.trim());
                    close();
                } catch (e) {
                    ev.target.disabled = false;
                    showToast(e.message || 'Failed', 'error');
                }
            });
            setTimeout(() => ov.querySelector('#repNoteInput')?.focus(), 60);
        }

        window.reportTakeAction = function(id) {
            const r = _repCache.find(x => x.id === id);
            const ffUID = r ? r.reportedFFUID : '';
            showActionSheet('Take Action', `FF UID ${ffUID || ''} — choose what to do`, [
                {
                    label: '✅ Mark Actioned',
                    style: 'default',
                    action: () => setReportStatus(id, { status: 'actioned', actionedAt: serverTimestamp() }, 'report_actioned')
                },
                {
                    label: '📝 Mark Actioned + Note',
                    style: 'default',
                    action: () => openReportNoteSheet('Action Note', note =>
                        setReportStatus(id, { status: 'actioned', actionedAt: serverTimestamp(), actionNote: note || '' }, 'report_actioned'))
                },
                {
                    label: '🚫 Ban Player + Mark Actioned',
                    style: 'destructive',
                    action: async () => {
                        // আগে Firebase uid বের করো (ffUID → users query)
                        let target = null;
                        try { target = await resolveUidByFFUID(ffUID); }
                        catch (e) { showToast(e.message || 'Lookup failed', 'error'); return; }
                        if (!target) {
                            showToast('No account found for this FF UID', 'error');
                            return;
                        }
                        const uname = target.name || target.displayName || target.email || target.uid;
                        showActionSheet('Ban Player', `${uname} (FF UID ${ffUID}) will be banned from the app.`, [{
                            label: 'Ban Player',
                            style: 'destructive',
                            action: async () => {
                                try {
                                    // NOTE: user app checks `isBanned === true` at login — তাই এই field-ই বসানো হলো
                                    await updateDoc(doc(db, 'users', target.uid), {
                                        isBanned: true,
                                        banReason: `Player report: ${r ? (r.reason || '') : ''}`.slice(0, 200)
                                    });
                                    await setReportStatus(id, { status: 'actioned', actionedAt: serverTimestamp(), actionNote: 'Player banned' }, 'report_ban');
                                    showToast('Player banned 🚫', 'error');
                                } catch (e) {
                                    showToast(e.message || 'Ban failed', 'error');
                                }
                            }
                        }]);
                    }
                }
            ]);
        };
