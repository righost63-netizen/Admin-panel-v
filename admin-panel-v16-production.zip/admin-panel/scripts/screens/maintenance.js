// ── DATABASE CLEANUP MAINTENANCE ──
        // ══════════════════════════════════════════
        // DATABASE CLEANUP MAINTENANCE SYSTEM
        // ══════════════════════════════════════════
        // ✅ ফিক্স: রিয়েল-টাইম ইউজার অ্যাপ মেইনটেন্যান্স মোড টগল ও ডাটাবেজ ক্লিনআপ
        window.openMaintenanceSheet = async function() {
            document.getElementById('maintenanceContainer')?.remove();

            // ফায়ারস্টোর থেকে বর্তমান মেইনটেন্যান্স স্টেট ও মেসেজ লোড করা
            let isMaint = false;
            let maintMsg = "অল্প সময়ের জন্য অ্যাপের রক্ষণাবেক্ষণ কাজ চলছে। কিছুক্ষণের মধ্যে আমরা ফিরে আসছি!";
            try {
                const mSnap = await getDoc(doc(db, 'settings', 'maintenance'));
                if (mSnap.exists()) {
                    isMaint = mSnap.data().isMaintenance || false;
                    maintMsg = mSnap.data().message || maintMsg;
                }
            } catch (e) {
                console.warn('Error loading maintenance state:', e.message);
            }

            const container = document.createElement('div');
            container.id = 'maintenanceContainer';
            container.innerHTML = `
              <div class="sheet-overlay visible mnt-overlay" onclick="document.getElementById('maintenanceContainer').remove()"></div>
              <div class="bottom-sheet visible mnt-sheet" style="max-height:88dvh;">
                <div class="sheet-handle"></div>
                <div class="mnt-hero">
                  <div class="mnt-hero-ic">⚙️</div>
                  <div class="mnt-hero-main">
                    <div class="mnt-hero-title">App Maintenance</div>
                    <div class="mnt-hero-sub">ইউজার প্যানেল লক + ডাটাবেজ ক্লিনআপ টুলস</div>
                  </div>
                  <button class="sheet-close mnt-close" onclick="document.getElementById('maintenanceContainer').remove()" aria-label="Close">✕</button>
                </div>
                <div class="sheet-body">
                  <!-- 🚧 Maintenance mode control card -->
                  <div class="mnt-card">
                    <div class="mnt-card-top">
                      <div class="mnt-ic">🚧</div>
                      <div class="mnt-card-main">
                        <div class="mnt-card-title">Maintenance Mode</div>
                        <div class="mnt-card-sub">অন করলে সাধারণ প্লেয়াররা অ্যাপে প্রবেশ করতে পারবে না।</div>
                      </div>
                      <label class="toggle" aria-label="Maintenance mode">
                        <input type="checkbox" id="maintModeToggle" ${isMaint ? 'checked' : ''} onchange="toggleAppMaintenance(this.checked)">
                        <span class="toggle-slider"></span>
                      </label>
                    </div>
                    <div class="mnt-status-row">
                      <span class="mnt-mode-pill ${isMaint ? 'is-on' : 'is-off'}" id="maintModePill">${isMaint ? '● Maintenance ON' : '● App Live'}</span>
                    </div>
                    <div id="maintMsgGroup" style="display:${isMaint ? 'block' : 'none'}; margin-top:12px;">
                      <label class="form-label" for="maintMsgInput">প্লেয়ারদের দেখানোর নোটিশ বার্তা</label>
                      <div class="mnt-msg-row">
                        <textarea class="form-textarea mnt-msg-input" id="maintMsgInput" placeholder="রক্ষণাবেক্ষণের কাজ চলছে...">${esc(maintMsg)}</textarea>
                        <button class="mnt-save-btn" onclick="saveMaintenanceMessage()">Save</button>
                      </div>
                    </div>
                  </div>

                  <div class="mnt-danger-head">
                    <span class="mnt-danger-ic">⚠️</span>
                    <div>
                      <div class="mnt-danger-title">Danger Zone</div>
                      <div class="mnt-danger-sub">ডিলিট করা ডেটা ফেরত পাওয়া যাবে না — সাবধানে ব্যবহার করুন।</div>
                    </div>
                  </div>

                  <div class="mnt-danger-card">
                    <div class="mnt-danger-row">
                      <div class="mnt-ic">👥</div>
                      <div class="mnt-card-main">
                        <div class="mnt-card-title">Join Requests <span class="mnt-chip">30+ days</span></div>
                        <div class="mnt-card-sub">শুধু Accepted / Rejected রিকোয়েস্ট ডিলিট হবে।</div>
                      </div>
                    </div>
                    <button class="mnt-del-btn" id="cleanJoinBtn" onclick="confirmCleanup('joinRequests','submittedAt','status',['accepted','rejected'],'cleanJoinBtn','join requests')">🗑️ Clean Joins</button>
                  </div>

                  <div class="mnt-danger-card">
                    <div class="mnt-danger-row">
                      <div class="mnt-ic">💸</div>
                      <div class="mnt-card-main">
                        <div class="mnt-card-title">Withdrawal Requests <span class="mnt-chip">30+ days</span></div>
                        <div class="mnt-card-sub">শুধু Approved / Rejected রিকোয়েস্ট ডিলিট হবে।</div>
                      </div>
                    </div>
                    <button class="mnt-del-btn" id="cleanWdBtn" onclick="confirmCleanup('withdrawalRequests','requestedAt','status',['approved','rejected'],'cleanWdBtn','withdrawal requests')">🗑️ Clean Withdrawals</button>
                  </div>

                  <div class="mnt-danger-card">
                    <div class="mnt-danger-row">
                      <div class="mnt-ic">🔔</div>
                      <div class="mnt-card-main">
                        <div class="mnt-card-title">Notification Logs <span class="mnt-chip">30+ days</span></div>
                        <div class="mnt-card-sub">অ্যাডমিন প্যানেলের পাঠানো নোটিফিকেশন লগ ডিলিট হবে।</div>
                      </div>
                    </div>
                    <button class="mnt-del-btn" id="cleanLogBtn" onclick="confirmCleanup('notifLog','sentAt',null,null,'cleanLogBtn','notification logs')">🗑️ Clean Logs</button>
                  </div>
                  <div style="height:8px;"></div>
                </div>
              </div>`;
            document.body.appendChild(container);
        };

        // মেইনটেন্যান্স অন/অফ করার লজিক
        window.toggleAppMaintenance = async function(checked) {
            const msgGroup = document.getElementById('maintMsgGroup');
            if (msgGroup) msgGroup.style.display = checked ? 'block' : 'none';
            // ✅ Mode pill (display-only)
            const pill = document.getElementById('maintModePill');
            if (pill) {
                pill.className = 'mnt-mode-pill' + (checked ? ' is-on' : ' is-off');
                pill.textContent = checked ? '● Maintenance ON' : '● App Live';
            }
            try {
                await setDoc(doc(db, 'settings', 'maintenance'), {
                    isMaintenance: checked
                }, {
                    merge: true
                });
                await touchCache('maintenance'); // FIX: ভুল ক্যাশ কী ('terms') ছিল — maintenance-এর জন্য সঠিক কী
                showToast(checked ? 'App Maintenance Mode Activated 🚧' : 'App is now Live! 🟢', checked ? 'warning' : 'success');
            } catch (e) {
                showToast('Failed to update maintenance: ' + e.message, 'error');
                document.getElementById('maintModeToggle').checked = !checked;
            }
        };

        // মেইনটেন্যান্স মেসেজ আপডেট করার লজিক
        window.saveMaintenanceMessage = async function() {
            const msg = document.getElementById('maintMsgInput').value.trim();
            if (!msg) {
                showToast('Please type a maintenance message', 'warning');
                return;
            }
            try {
                await setDoc(doc(db, 'settings', 'maintenance'), {
                    message: msg
                }, {
                    merge: true
                });
                await touchCache('maintenance'); // FIX: ভুল ক্যাশ কী ছিল
                showToast('Maintenance message updated! ✅', 'success');
            } catch (e) {
                showToast('Failed to save message: ' + e.message, 'error');
            }
        };



