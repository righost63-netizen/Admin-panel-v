// ── DEDICATED ROOM MANAGEMENT ENGINE ──
        // ══════════════════════════════════════════════════════════════
        // DEDICATED ROOM MANAGEMENT ENGINE (SPEC 24 & 48)
        // ══════════════════════════════════════════════════════════════
        // NOTE: পুরনো openRoomManageSheet এখানে ছিল — নিচে SECURE ভার্সনটাই চালু থাকে, তাই ডুপ্লিকেট সরিয়ে দেওয়া হলো।

        window.closeRoomManageSheet = function() {
            hideSheet('roomManageSheet', 'roomManageOverlay');
        };

        function updateRoomBadgeUI(isVisible) {
            const badge = document.getElementById('rm_visible_badge');
            const btnPub = document.getElementById('btnPublishRoom');
            if (isVisible) {
                badge.className = 'rms-status is-live';
                badge.innerHTML = '<i></i>PUBLISHED';
                if (btnPub) btnPub.textContent = '🔄 Re-Publish / Update Room';
            } else {
                badge.className = 'rms-status is-hidden';
                badge.innerHTML = '<i></i>HIDDEN';
                if (btnPub) btnPub.textContent = '📢 Publish Room to Players';
            }
        }

        // NOTE: পুরনো saveRoomCredentialsOnly ও publishRoomCredentials এখানে ছিল —
        // নিচে SECURE ভার্সনগুলোই চালু থাকে, তাই ডুপ্লিকেট সরিয়ে দেওয়া হলো।

        // ── DEDICATED SECURE ROOM MANAGEMENT ──

        // 1. Fetch Room Credentials (Secure)
        window.openRoomManageSheet = async function(tournId, tournName = '') {
            document.getElementById('rm_tournId').value = tournId;
            document.getElementById('rm_tournName').textContent = tournName || 'Tournament';
            document.getElementById('rm_roomId').value = '';
            document.getElementById('rm_roomPass').value = '';

            try {
                // 우선 সিকিউর কালেকশন থেকে ডাটা ফেচ করার চেষ্টা করবে
                const roomSnap = await getDoc(doc(db, 'roomCredentials', tournId));
                let roomId = '',
                    roomPass = '',
                    isVisible = false;

                if (roomSnap.exists()) {
                    const rData = roomSnap.data();
                    roomId = rData.roomId || '';
                    roomPass = rData.roomPassword || '';
                    isVisible = rData.isPublished || rData.roomVisible || false;
                } else {
                    // যদি নতুন কালেকশনে না থাকে, তবে লিগ্যাসি টুর্নামেন্ট ডাটা থেকে নেবে
                    const snap = await getDoc(doc(db, 'tournaments', tournId));
                    if (snap.exists()) {
                        const data = snap.data();
                        roomId = data.roomSettings?.roomId || data.roomId || '';
                        roomPass = data.roomSettings?.roomPassword || data.roomPass || '';
                        isVisible = data.roomSettings?.roomVisible ?? (data.roomVisible || false);
                    }
                }

                document.getElementById('rm_roomId').value = roomId;
                document.getElementById('rm_roomPass').value = roomPass;
                updateRoomBadgeUI(isVisible);
            } catch (e) {
                console.error('openRoomManageSheet error:', e);
            }

            showSheet('roomManageSheet', 'roomManageOverlay');
            // a11y: ESC to close, focus trap, initial focus on Room ID
            if (window.sheetA11y) window.sheetA11y('roomManageSheet', 'roomManageOverlay', 'rm_roomId');
        };

        // 2. Save Credentials without publishing (Secure)
        window.saveRoomCredentialsOnly = async function() {
            const tournId = document.getElementById('rm_tournId').value;
            const roomId = document.getElementById('rm_roomId').value.trim();
            const roomPass = document.getElementById('rm_roomPass').value.trim();

            try {
                // সেভ হবে সিক্রেট কালেকশনে
                await setDoc(doc(db, 'roomCredentials', tournId), {
                    roomId: roomId,
                    roomPassword: roomPass,
                    // FIX: আগে publish করা থাকলে isPublished true-ই থেকে যেত (merge),
                    // ফলে "Save (Keep Hidden)" চাপলেও প্লেয়াররা রুম দেখতে পেত।
                    // এখন hidden সেভ করলে publish flag-ও বন্ধ হয়ে যাবে।
                    isPublished: false,
                    roomVisible: false,
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });

                // পাবলিক টুর্নামেন্ট ডকুমেন্ট থেকে পাসওয়ার্ড রিমুভ করা হবে (Security fix)
                await updateDoc(doc(db, 'tournaments', tournId), {
                    roomSettings: null,
                    roomId: null,
                    roomPass: null,
                    roomVisible: false,
                    roomSet: true, // ✅ BUILD 13: dashboard "room not set" warning-এর জন্য flag
                    updatedAt: serverTimestamp()
                }).catch(() => {});

                showToast('Room credentials saved securely (Hidden) 💾', 'success');
                closeRoomManageSheet();
            } catch (e) {
                showToast('Failed to save: ' + e.message, 'error');
            }
        };

        // 3. Publish Room & Notify
        window.publishRoomCredentials = async function() {
            const tournId = document.getElementById('rm_tournId').value;
            const tournName = document.getElementById('rm_tournName').textContent;
            const roomId = document.getElementById('rm_roomId').value.trim();
            const roomPass = document.getElementById('rm_roomPass').value.trim();

            if (!roomId || !roomPass) {
                showToast('Please enter both Room ID and Password before publishing', 'warning');
                return;
            }

            const btn = document.getElementById('btnPublishRoom');
            btn.disabled = true;
            btn.textContent = 'Publishing...';

            try {
                // সিক্রেট কালেকশনে পাবলিশ স্ট্যাটাস আপডেট
                await setDoc(doc(db, 'roomCredentials', tournId), {
                    roomId: roomId,
                    roomPassword: roomPass,
                    isPublished: true,
                    roomVisible: true,
                    roomPublishedAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });

                // পাবলিক ডকুমেন্টে শুধুমাত্র flag ট্রু করা হবে, পাসওয়ার্ড নয়
                await updateDoc(doc(db, 'tournaments', tournId), {
                    roomSettings: null,
                    roomId: null,
                    roomPass: null,
                    roomVisible: true,
                    roomSet: true, // ✅ BUILD 13: dashboard "room not set" warning-এর জন্য flag
                    updatedAt: serverTimestamp()
                }).catch(() => {});

                // Fetch confirmed participants
                let playerUserIds = [];
                const teamsSnap = await getDocs(query(collection(db, 'tournamentTeams'), where('tournamentId', '==', tournId), where('status', '==', 'confirmed')));

                if (!teamsSnap.empty) {
                    teamsSnap.docs.forEach(d => {
                        const tData = d.data();
                        (tData.players || []).forEach(p => {
                            if (p.userId) playerUserIds.push(p.userId);
                        });
                        if (tData.captainUserId && !playerUserIds.includes(tData.captainUserId)) {
                            playerUserIds.push(tData.captainUserId);
                        }
                    });
                } else {
                    const reqSnap = await getDocs(query(collection(db, 'joinRequests'), where('tournamentId', '==', tournId), where('status', 'in', ['accepted', 'confirmed'])));
                    reqSnap.docs.forEach(d => {
                        const uId = d.data().userId;
                        if (uId) playerUserIds.push(uId);
                    });
                }

                playerUserIds = [...new Set(playerUserIds)];

                if (playerUserIds.length > 0) {
                    const batch = writeBatch(db);
                    playerUserIds.forEach(uId => {
                        const nRef = doc(collection(db, 'users', uId, 'notifications'));
                        batch.set(nRef, {
                            title: '🔑 Room Details Published!',
                            message: `Room ID and Password for "${tournName}" are now available. Check your match slot and join promptly!`,
                            type: 'info',
                            read: false,
                            createdAt: serverTimestamp()
                        });
                    });
                    await batch.commit();

                    sendOneSignalPush('Room Details Published 🔑', `Room ID & Password for "${tournName}" are now live! Check now.`, 'info', playerUserIds)
                        .then(res => {
                            // FIX (BUILD 16): honest toast — in-app notifications গেছে, push-এর সত্যি অবস্থা জানাও
                            if (res && res.ok) showToast(`Room published & ${playerUserIds.length} players notified! 🚀`, 'success');
                            else if (res && (res.skipped === 'app_id' || res.skipped === 'rest_key')) showToast(`Room published ✅ — in-app notifications sent, but push NOT sent (OneSignal key missing) ⚠️`, 'warning');
                            else showToast(`Room published ✅ — in-app notifications sent, but push FAILED: ${(res && res.error) || 'unknown'} ⚠️`, 'error');
                        })
                        .catch(err => console.warn('Push error:', err));
                } else {
                    // কোনো player নেই — শুধু room publish হলো
                    showToast('Room published ✅ (no players to notify yet)', 'success');
                }

                await touchCache('tournaments');
                // FIX (BUILD 16): toast এখন push result-এর .then()-এ হয় (উপরে) — এখানে আর unconditional toast নেই
                closeRoomManageSheet();
            } catch (e) {
                console.error('publishRoomCredentials error:', e);
                showToast('Failed to publish: ' + e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.textContent = '📢 Publish Room to Players';
            }
        };

        // 4. Hide Room
        window.hideRoomCredentials = async function() {
            const tournId = document.getElementById('rm_tournId').value;
            try {
                await setDoc(doc(db, 'roomCredentials', tournId), {
                    isPublished: false,
                    roomVisible: false,
                    updatedAt: serverTimestamp()
                }, {
                    merge: true
                });

                await updateDoc(doc(db, 'tournaments', tournId), {
                    roomSettings: null,
                    roomId: null,
                    roomPass: null,
                    roomVisible: false,
                    updatedAt: serverTimestamp()
                }).catch(() => {});

                await touchCache('tournaments');
                showToast('Room details hidden from players 🔒', 'info');
                updateRoomBadgeUI(false);
                closeRoomManageSheet();
            } catch (e) {
                showToast('Error: ' + e.message, 'error');
            }
        };



